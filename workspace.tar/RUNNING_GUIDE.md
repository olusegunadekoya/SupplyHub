# 🚀 Running SupplyHub on Your PC - Complete Guide

## 📋 Table of Contents
1. [Prerequisites](#prerequisites)
2. [Quick Start (3 Steps)](#quick-start)
3. [One-Click Start Scripts](#one-click-scripts)
4. [What to Expect](#what-to-expect)
5. [Exploring the Demo](#exploring-the-demo)
6. [Troubleshooting](#troubleshooting)
7. [Production Mode](#production-mode)

---

## Prerequisites

### Required Software

**Node.js (v18 or higher)**
- Download from: https://nodejs.org/
- Choose the **LTS (Long Term Support)** version
- npm (Node Package Manager) is included

**Verify Installation:**
```bash
node --version    # Should show v18.x.x or higher
npm --version     # Should show 9.x.x or higher
```

### System Requirements
- **OS:** Windows 10/11, macOS 10.15+, or Linux (Ubuntu 20.04+)
- **RAM:** 4GB minimum (8GB recommended)
- **Disk Space:** 500MB for project + dependencies
- **Browser:** Chrome 90+, Firefox 88+, Safari 14+, or Edge 90+

---

## Quick Start

### Step 1: Open Terminal/Command Prompt

**Windows:**
- Press `Win + R`, type `cmd`, press Enter
- Or search for "Command Prompt" or "PowerShell"

**macOS:**
- Press `Cmd + Space`, type `terminal`, press Enter
- Or open Terminal from Applications

**Linux:**
- Press `Ctrl + Alt + T`
- Or open Terminal from your applications menu

### Step 2: Navigate to Project Folder

```bash
cd path/to/supplyhub
```

Replace `path/to/supplyhub` with the actual path to your project folder.

**Example:**
```bash
# Windows
cd C:\Users\YourName\Documents\supplyhub

# macOS/Linux
cd ~/Documents/supplyhub
```

### Step 3: Install Dependencies

```bash
npm install
```

**What happens:**
- Downloads all required packages (React, Vite, Dexie, etc.)
- Creates a `node_modules` folder
- Takes 1-3 minutes depending on your internet speed

**Expected output:**
```
added 250 packages in 45s
```

### Step 4: Start the Development Server

```bash
npm run dev
```

**Expected output:**
```
  VITE v5.0.0  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
```

### Step 5: Open Your Browser

The app should automatically open at: **http://localhost:5173**

If it doesn't open automatically:
1. Open your web browser
2. Copy and paste: `http://localhost:5173`
3. Press Enter

**You should see the SupplyHub Dashboard!** 🎉

---

## One-Click Start Scripts

For even easier startup, use the provided scripts:

### Windows Users
**Double-click:** `start-demo.bat`

The script will:
- ✅ Check if Node.js is installed
- ✅ Install dependencies (if needed)
- ✅ Start the development server
- ✅ Open the app automatically

### macOS/Linux Users
**Make script executable (first time only):**
```bash
chmod +x start-demo.sh
```

**Then run:**
```bash
./start-demo.sh
```

---

## What to Expect

### First Launch

1. **Loading Screen** (2-3 seconds)
   - Shows "Initializing database..."
   - Database is being created and seeded with demo data

2. **Dashboard** (automatic redirect)
   - You'll see the main dashboard with KPIs
   - Pre-loaded with demo data for Müller Components GmbH

### Demo Data Included

The app comes pre-loaded with:

**🏢 Company**
- Müller Components GmbH (Munich, Germany)
- Subdomain: mueller-components.supplyhub.io

**👥 Users (4)**
- Hans Müller (Owner)
- Anna Weber (Admin)
- Klaus Fischer (Editor)
- Maria Schmidt (Viewer - invited)

**📦 Products (3)**
- Industrial Grade Steel Bearings
- Precision CNC Machining Service
- Custom Rubber Seals & Gaskets

**👨‍🔧 Technical Experts (6)**
- Thomas Weber (CNC Specialist - Germany)
- Maria Rossi (Quality Consultant - Italy)
- James Mitchell (Materials Engineer - USA)
- Hiroshi Tanaka (Lean Expert - Japan)
- Sophie Laurent (Automation Engineer - France)
- Klaus Bauer (Supply Chain - Germany)

**📊 Quality Data**
- 12 months of quality metrics
- 4 inspections
- 3 NCR reports
- 4 CAPA actions
- 3 scorecards (Grades A, A, B)

**📄 Documents**
- 5 quality documents
- 3 certifications

---

## Exploring the Demo

### Navigation Menu (Left Sidebar)

**Overview Section:**
1. **Dashboard** - Main overview with KPIs
2. **Products & Services** - Browse product catalog
3. **Quality Assurance** - Quality metrics, inspections, NCRs, CAPAs
4. **Manpower Sourcing** - Technical expert directory
5. **Certifications** - Compliance documents
6. **Messages** - Chat with platform coordinator
7. **Company Profile** - Edit company information

**Web Presence Section:**
8. **Subdomain Site** - Customize your site header/footer
9. **Content Manager** - Manage pages and banners

**Communication Section:**
10. **Email Services** - Send emails with templates

**Administration Section:**
11. **Control Panel** - User management, activity logs
12. **Database & Server** - Live database stats
13. **Development Manual** - Complete documentation

### Recommended Exploration Path

1. **Start with Dashboard** - Get an overview
2. **Browse Products** - See the product catalog
3. **Check Quality Assurance** - View metrics and scorecards
4. **Explore Manpower Sourcing** - Browse technical experts
5. **Read Development Manual** - Learn about the architecture

### Interactive Features to Try

**Products Page:**
- Click on a product to view details
- Try the grid/list view toggle
- Use the search and filter functions

**Quality Assurance:**
- Switch between tabs (Overview, Inspections, NCR, CAPA, Scorecards, Documents)
- View the trend charts
- Check the radar chart for performance breakdown

**Manpower Sourcing:**
- Filter experts by region (Local/Regional/International)
- Click on an expert to see full profile
- View skills, certifications, and ratings

**Subdomain Site Builder:**
- Change header/footer colors
- Switch between desktop/mobile preview
- See live changes in the preview

**Development Manual:**
- Navigate through chapters
- View code examples
- Print/Save as PDF

---

## Troubleshooting

### Issue: "npm: command not found"

**Cause:** Node.js is not installed

**Solution:**
1. Download Node.js from https://nodejs.org/
2. Install the LTS version
3. Restart your terminal
4. Try `npm install` again

### Issue: Port 5173 Already in Use

**Error Message:**
```
Error: Port 5173 is already in use
```

**Solutions:**

**Option 1: Use a different port**
```bash
npm run dev -- --port 3000
```
Then open: http://localhost:3000

**Option 2: Kill the process using port 5173**

Windows:
```bash
# Find the process
netstat -ano | findstr :5173
# Kill it (replace PID with the actual number)
taskkill /PID <PID> /F
```

macOS/Linux:
```bash
# Find the process
lsof -ti:5173
# Kill it
kill -9 $(lsof -ti:5173)
```

### Issue: Blank White Page

**Possible Causes:**
1. Browser cache
2. JavaScript errors
3. Database initialization failed

**Solutions:**

1. **Hard refresh the page:**
   - Windows/Linux: `Ctrl + Shift + R`
   - macOS: `Cmd + Shift + R`

2. **Clear browser cache:**
   - Open DevTools (F12)
   - Right-click the refresh button
   - Select "Empty Cache and Hard Reload"

3. **Check browser console:**
   - Press F12 to open DevTools
   - Go to Console tab
   - Look for red error messages
   - Take a screenshot if you need help

4. **Clear IndexedDB:**
   - Open DevTools (F12)
   - Go to Application tab (Chrome) or Storage tab (Firefox)
   - Expand "IndexedDB" on the left
   - Right-click "SupplyHubDB"
   - Select "Delete"
   - Refresh the page

### Issue: "Cannot find module" Errors

**Cause:** Dependencies not installed correctly

**Solution:**
```bash
# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Reinstall
npm install
```

Windows (Command Prompt):
```bash
rmdir /s /q node_modules
del package-lock.json
npm install
```

Windows (PowerShell):
```bash
Remove-Item -Recurse -Force node_modules
Remove-Item package-lock.json
npm install
```

### Issue: Build Fails

**Check Node.js version:**
```bash
node --version
```

If version is less than 18:
1. Download latest LTS from https://nodejs.org/
2. Install (it will replace the old version)
3. Restart terminal
4. Try again

### Issue: Slow Performance

**Solutions:**
1. Close other browser tabs
2. Clear browser cache
3. Use Chrome or Edge (best performance)
4. Disable browser extensions

---

## Production Mode

### Build for Production

```bash
npm run build
```

**Output:**
- Creates a `dist/` folder
- Optimized and minified files
- Ready for deployment

### Preview Production Build

```bash
npm run preview
```

Opens at: **http://localhost:4173**

### Deploy to Static Hosting

**Option 1: Vercel (Recommended)**
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

**Option 2: Netlify**
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod
```

**Option 3: GitHub Pages**
1. Push code to GitHub
2. Enable GitHub Pages in repository settings
3. Set source to "GitHub Actions"
4. Use the provided workflow

### Docker Deployment

**Build the image:**
```bash
docker build -t supplyhub .
```

**Run the container:**
```bash
docker run -p 8080:80 supplyhub
```

Access at: **http://localhost:8080**

---

## Data Persistence

### How It Works

- All data is stored in your **browser's IndexedDB**
- Data persists across page refreshes
- Data is **local to your browser** (not shared)
- No server or internet connection required after initial load

### What Happens If...

**You refresh the page:**
- ✅ Data is preserved
- ✅ You stay on the same page

**You close the browser:**
- ✅ Data is preserved
- ✅ Open the app again to see your data

**You clear browser data:**
- ❌ All data is lost
- ❌ Demo data will be re-seeded on next load

**You use a different browser:**
- ❌ Data is not shared between browsers
- ✅ Each browser has its own data

**You use a different computer:**
- ❌ Data is not synced
- ✅ Each device has its own data

### Resetting Demo Data

To start fresh with demo data:

1. Open DevTools (F12)
2. Go to Application tab
3. Expand "IndexedDB"
4. Right-click "SupplyHubDB"
5. Select "Delete"
6. Refresh the page

The database will be re-created with fresh demo data.

---

## Next Steps

### For Users
1. ✅ Explore all modules
2. ✅ Try adding/editing products
3. ✅ Customize your subdomain site
4. ✅ Read the Development Manual

### For Developers
1. ✅ Read the Development Manual (`/manual`)
2. ✅ Study the architecture (Chapter 2)
3. ✅ Review the Extension Guide (Chapter 6)
4. ✅ Try adding a new module

### For Production Deployment
1. ✅ Review deployment options (Chapter 5)
2. ✅ Set up a backend server
3. ✅ Implement authentication
4. ✅ Configure database (PostgreSQL recommended)
5. ✅ Set up monitoring and backups

---

## Getting Help

### Documentation
- **Development Manual:** Accessible at `/manual` in the app
- **README.md:** Complete project documentation
- **QUICKSTART.md:** Quick reference guide

### Common Questions

**Q: Do I need internet to run the app?**
A: Only for the first load. After that, it works offline.

**Q: Can multiple people use the same demo?**
A: Each browser has its own data. Share the URL, but data is not shared.

**Q: How do I save my changes?**
A: Changes are automatically saved to IndexedDB. No manual save needed.

**Q: Can I export my data?**
A: Not in the demo. Production would have export features.

**Q: Is this ready for production?**
A: No. This is a frontend demo. Production requires a backend server.

### Support
1. Check the Development Manual first
2. Review troubleshooting section above
3. Check browser console for errors
4. Verify Node.js version (18+)

---

## Summary

### Quick Commands

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Type checking
npm run typecheck
```

### URLs

- **Development:** http://localhost:5173
- **Production Preview:** http://localhost:4173

### Key Files

- `README.md` - Complete documentation
- `QUICKSTART.md` - Quick reference
- `start-demo.bat` - Windows start script
- `start-demo.sh` - Mac/Linux start script
- `/manual` - Development Manual (in-app)

---

## 🎉 You're Ready!

You now have everything you need to run SupplyHub on your PC.

**Start the app:**
```bash
npm run dev
```

**Open your browser:**
```
http://localhost:5173
```

**Enjoy exploring!** 🚀

---

*Last updated: 2024*
*SupplyHub v1.0*
