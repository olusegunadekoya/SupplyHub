import { db, generateId } from '../db/database';
import { eventBus } from './events';

// ============================================================================
// API SERVICE LAYER - Simulates REST API with realistic behavior
// In production, these would be HTTP calls to a real backend server
// ============================================================================

// Simulate network latency (50-200ms)
const simulateLatency = () => new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 150));

// API Error class
export class APIError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
    this.name = 'APIError';
  }
}

// Current tenant context (in real app, this comes from JWT/auth)
let currentSupplierId: string | null = null;

export function setCurrentSupplier(supplierId: string) {
  currentSupplierId = supplierId;
}

export function getCurrentSupplierId(): string {
  if (!currentSupplierId) throw new APIError(401, 'UNAUTHORIZED', 'No supplier context');
  return currentSupplierId;
}

// ============================================================================
// SUPPLIERS API
// ============================================================================
export const SuppliersAPI = {
  async getCurrent() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const supplier = await db.suppliers.where('supplierId').equals(supplierId).first();
    if (!supplier) throw new APIError(404, 'NOT_FOUND', 'Supplier not found');
    return supplier;
  },

  async update(data: Partial<any>) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const supplier = await db.suppliers.where('supplierId').equals(supplierId).first();
    if (!supplier || !supplier.id) throw new APIError(404, 'NOT_FOUND', 'Supplier not found');
    
    await db.suppliers.update(supplier.id, { ...data, updatedAt: new Date().toISOString() });
    
    eventBus.emit('supplier:updated', { supplierId, changes: data });
    await ProductsAPI.logActivity('supplier.updated', 'supplier', supplierId, data);
    
    return await this.getCurrent();
  },

  async register(data: any) {
    await simulateLatency();
    const supplierId = `sup-${generateId().substring(0, 8)}`;
    const subdomain = data.companyName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30);
    
    // Check subdomain availability
    const existing = await db.subdomainRoutes.where('subdomain').equals(subdomain).first();
    if (existing) throw new APIError(409, 'SUBDOMAIN_TAKEN', 'Subdomain already exists');

    const now = new Date().toISOString();
    await db.suppliers.add({
      supplierId,
      subdomain,
      ...data,
      status: 'pending',
      brandColor: '#c06d23',
      logoText: data.companyName.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase(),
      plan: 'free',
      storageUsed: 0,
      storageLimit: 1_000_000_000,
      registeredAt: now,
    });

    await db.subdomainRoutes.add({
      subdomain,
      supplierId,
      active: false,
      sslEnabled: false,
      createdAt: now,
    });

    eventBus.emit('supplier:registered', { supplierId, subdomain });
    return { supplierId, subdomain };
  },
};

// ============================================================================
// PRODUCTS API
// ============================================================================
export const ProductsAPI = {
  async list(filters?: { status?: string; category?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let collection = db.products.where('supplierId').equals(supplierId);
    
    const products = await collection.toArray();
    
    let filtered = products;
    if (filters?.status) filtered = filtered.filter(p => p.status === filters.status);
    if (filters?.category) filtered = filtered.filter(p => p.category === filters.category);
    
    return filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async get(productId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const product = await db.products.where('productId').equals(productId).first();
    if (!product || product.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Product not found');
    return product;
  },

  async create(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const productId = generateId();
    const now = new Date().toISOString();
    
    const product = {
      productId,
      supplierId,
      ...data,
      characteristics: JSON.stringify(data.characteristics || []),
      specifications: JSON.stringify(data.specifications || {}),
      images: JSON.stringify(data.images || []),
      status: 'under_review',
      viewCount: 0,
      inquiryCount: 0,
      createdAt: now,
      updatedAt: now,
    };
    
    await db.products.add(product);
    eventBus.emit('product:created', { supplierId, productId });
    await this.logActivity('product.created', 'product', productId, { name: data.name });
    return product;
  },

  async update(productId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const product = await db.products.where('productId').equals(productId).first();
    if (!product || product.supplierId !== supplierId || !product.id) throw new APIError(404, 'NOT_FOUND', 'Product not found');
    
    const updateData = { ...data, updatedAt: new Date().toISOString() };
    if (data.characteristics) updateData.characteristics = JSON.stringify(data.characteristics);
    if (data.specifications) updateData.specifications = JSON.stringify(data.specifications);
    if (data.images) updateData.images = JSON.stringify(data.images);
    
    await db.products.update(product.id, updateData);
    eventBus.emit('product:updated', { supplierId, productId, changes: data });
    await this.logActivity('product.updated', 'product', productId, data);
    return await this.get(productId);
  },

  async delete(productId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const product = await db.products.where('productId').equals(productId).first();
    if (!product || product.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Product not found');
    
    await db.products.delete(product.id!);
    eventBus.emit('product:deleted', { supplierId, productId });
    await this.logActivity('product.deleted', 'product', productId, { name: product.name });
  },

  async logActivity(action: string, entityType: string, entityId: string, details: any) {
    const supplierId = getCurrentSupplierId();
    await db.activityLogs.add({
      logId: generateId(),
      supplierId,
      userId: 'current-user',
      userName: 'Current User',
      action,
      entityType,
      entityId,
      details: JSON.stringify(details),
      ipAddress: '127.0.0.1',
      userAgent: navigator.userAgent,
      createdAt: new Date().toISOString(),
    });
  },
};

// ============================================================================
// CERTIFICATIONS API
// ============================================================================
export const CertificationsAPI = {
  async list() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.certifications.where('supplierId').equals(supplierId).toArray();
  },

  async create(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const certId = generateId();
    const cert = {
      certId,
      supplierId,
      ...data,
      fileUrl: `/files/${data.fileName}`,
      fileSize: data.fileSize || 0,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    await db.certifications.add(cert);
    eventBus.emit('certification:created', { supplierId, certId });
    await ProductsAPI.logActivity('certification.uploaded', 'certification', certId, { name: data.name });
    return cert;
  },

  async delete(certId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const cert = await db.certifications.where('certId').equals(certId).first();
    if (!cert || cert.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Certification not found');
    await db.certifications.delete(cert.id!);
    eventBus.emit('certification:deleted', { supplierId, certId });
  },
};

// ============================================================================
// MESSAGES API
// ============================================================================
export const MessagesAPI = {
  async list() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.messages.where('supplierId').equals(supplierId).sortBy('timestamp');
  },

  async send(content: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const messageId = generateId();
    const message = {
      messageId,
      supplierId,
      senderType: 'supplier' as const,
      senderId: 'current-user',
      senderName: 'Current User',
      content,
      timestamp: new Date().toISOString(),
      read: true,
    };
    await db.messages.add(message);
    eventBus.emit('message:sent', { supplierId, messageId });
    
    // Simulate coordinator reply
    setTimeout(async () => {
      const reply = {
        messageId: generateId(),
        supplierId,
        senderType: 'coordinator' as const,
        senderId: 'coord-001',
        senderName: 'Sarah Mitchell',
        content: 'Thank you for your message. We\'ve received it and will review shortly. Our team typically responds within 24 business hours.',
        timestamp: new Date().toISOString(),
        read: false,
      };
      await db.messages.add(reply);
      eventBus.emit('message:received', { supplierId, messageId: reply.messageId });
    }, 2000);
    
    return message;
  },

  async markAllRead() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const messages = await db.messages.where('supplierId').equals(supplierId).filter(m => !m.read).toArray();
    for (const msg of messages) {
      if (msg.id) await db.messages.update(msg.id, { read: true });
    }
  },
};

// ============================================================================
// CMS API (Pages, Banners, Menu)
// ============================================================================
export const CMSAPI = {
  async listPages() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.pages.where('supplierId').equals(supplierId).toArray();
  },

  async createPage(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const pageId = generateId();
    const now = new Date().toISOString();
    const page = {
      pageId,
      supplierId,
      ...data,
      viewCount: 0,
      createdAt: now,
      updatedAt: now,
    };
    await db.pages.add(page);
    eventBus.emit('page:created', { supplierId, pageId });
    await ProductsAPI.logActivity('page.created', 'page', pageId, { title: data.title });
    return page;
  },

  async updatePage(pageId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const page = await db.pages.where('pageId').equals(pageId).first();
    if (!page || page.supplierId !== supplierId || !page.id) throw new APIError(404, 'NOT_FOUND', 'Page not found');
    await db.pages.update(page.id, { ...data, updatedAt: new Date().toISOString() });
    eventBus.emit('page:updated', { supplierId, pageId, changes: data });
    return await db.pages.where('pageId').equals(pageId).first();
  },

  async deletePage(pageId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const page = await db.pages.where('pageId').equals(pageId).first();
    if (!page || page.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Page not found');
    await db.pages.delete(page.id!);
    eventBus.emit('page:deleted', { supplierId, pageId });
  },

  async listBanners() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.banners.where('supplierId').equals(supplierId).toArray();
  },

  async createBanner(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const banner = { bannerId: generateId(), supplierId, ...data, createdAt: new Date().toISOString() };
    await db.banners.add(banner);
    return banner;
  },

  async updateBanner(bannerId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const banner = await db.banners.where('bannerId').equals(bannerId).first();
    if (!banner || banner.supplierId !== supplierId || !banner.id) throw new APIError(404, 'NOT_FOUND', 'Banner not found');
    await db.banners.update(banner.id, data);
    return await db.banners.where('bannerId').equals(bannerId).first();
  },

  async deleteBanner(bannerId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const banner = await db.banners.where('bannerId').equals(bannerId).first();
    if (!banner || banner.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Banner not found');
    await db.banners.delete(banner.id!);
  },

  async listMenuItems() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const items = await db.menuItems.where('supplierId').equals(supplierId).toArray();
    return items.sort((a, b) => a.order - b.order);
  },
};

// ============================================================================
// EMAIL API
// ============================================================================
export const EmailAPI = {
  async listTemplates() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.emailTemplates.where('supplierId').equals(supplierId).toArray();
  },

  async createTemplate(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const now = new Date().toISOString();
    const template = {
      templateId: generateId(),
      supplierId,
      ...data,
      variables: JSON.stringify(data.variables || []),
      createdAt: now,
      updatedAt: now,
    };
    await db.emailTemplates.add(template);
    return template;
  },

  async deleteTemplate(templateId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const template = await db.emailTemplates.where('templateId').equals(templateId).first();
    if (!template || template.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Template not found');
    await db.emailTemplates.delete(template.id!);
  },

  async send(data: { to: string; subject: string; body: string; templateId?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const supplier = await db.suppliers.where('supplierId').equals(supplierId).first();
    const emailId = generateId();
    const now = new Date().toISOString();
    
    const email = {
      emailId,
      supplierId,
      fromAddress: `info@${supplier?.subdomain || 'supplier'}.supplyhub.io`,
      toAddress: data.to,
      subject: data.subject,
      body: data.body,
      templateId: data.templateId,
      status: 'sent' as const,
      retryCount: 0,
      sentAt: now,
      createdAt: now,
    };
    
    await db.sentEmails.add(email);
    eventBus.emit('email:sent', { supplierId, emailId, to: data.to });
    await ProductsAPI.logActivity('email.sent', 'email', emailId, { to: data.to, subject: data.subject });
    
    // Simulate delivery
    setTimeout(async () => {
      const record = await db.sentEmails.where('emailId').equals(emailId).first();
      if (record && record.id) {
        await db.sentEmails.update(record.id, { status: 'delivered', deliveredAt: new Date().toISOString() });
        eventBus.emit('email:delivered', { supplierId, emailId });
      }
    }, 1500);
    
    return email;
  },

  async listSent() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const emails = await db.sentEmails.where('supplierId').equals(supplierId).toArray();
    return emails.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
};

// ============================================================================
// SITE CONFIG API
// ============================================================================
export const SiteConfigAPI = {
  async get() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const config = await db.siteConfigs.where('supplierId').equals(supplierId).first();
    if (!config) throw new APIError(404, 'NOT_FOUND', 'Site config not found');
    return config;
  },

  async update(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const config = await db.siteConfigs.where('supplierId').equals(supplierId).first();
    if (!config || !config.id) throw new APIError(404, 'NOT_FOUND', 'Site config not found');
    
    const updateData = { ...data, updatedAt: new Date().toISOString() };
    if (data.socialLinks && !Array.isArray(data.socialLinks)) {
      // Already stringified
    } else if (data.socialLinks) {
      updateData.socialLinks = JSON.stringify(data.socialLinks);
    }
    
    await db.siteConfigs.update(config.id, updateData);
    eventBus.emit('site:updated', { supplierId, changes: data });
    await ProductsAPI.logActivity('site.updated', 'site', supplierId, data);
    return await this.get();
  },
};

// ============================================================================
// USERS API
// ============================================================================
export const UsersAPI = {
  async list() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.users.where('supplierId').equals(supplierId).toArray();
  },

  async invite(data: { name: string; email: string; role: 'owner' | 'admin' | 'editor' | 'viewer' }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const userId = generateId();
    const user = {
      userId,
      supplierId,
      name: data.name,
      email: data.email,
      role: data.role,
      passwordHash: 'pending_setup',
      status: 'invited' as const,
      twoFactorEnabled: false,
      createdAt: new Date().toISOString(),
    };
    await db.users.add(user);
    eventBus.emit('user:invited', { supplierId, userId, email: data.email });
    await ProductsAPI.logActivity('user.invited', 'user', userId, { email: data.email, role: data.role });
    return user;
  },

  async update(userId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const user = await db.users.where('userId').equals(userId).first();
    if (!user || user.supplierId !== supplierId || !user.id) throw new APIError(404, 'NOT_FOUND', 'User not found');
    await db.users.update(user.id, data);
    return await db.users.where('userId').equals(userId).first();
  },

  async delete(userId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const user = await db.users.where('userId').equals(userId).first();
    if (!user || user.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'User not found');
    if (user.role === 'owner') throw new APIError(403, 'FORBIDDEN', 'Cannot delete owner');
    await db.users.delete(user.id!);
  },
};

// ============================================================================
// ACTIVITY LOG API
// ============================================================================
export const ActivityAPI = {
  async list(limit = 50) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const logs = await db.activityLogs.where('supplierId').equals(supplierId).toArray();
    return logs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, limit);
  },
};

// ============================================================================
// SUBDOMAIN ROUTING API (Web Server Simulation)
// ============================================================================
export const SubdomainAPI = {
  async resolve(subdomain: string) {
    await simulateLatency();
    const route = await db.subdomainRoutes.where('subdomain').equals(subdomain).first();
    if (!route || !route.active) throw new APIError(404, 'SUBDOMAIN_NOT_FOUND', 'Subdomain not found or inactive');
    
    const supplier = await db.suppliers.where('supplierId').equals(route.supplierId).first();
    if (!supplier || supplier.status !== 'approved') throw new APIError(403, 'SUPPLIER_NOT_APPROVED', 'Supplier not approved');
    
    return { route, supplier };
  },

  async getStatus() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const route = await db.subdomainRoutes.where('supplierId').equals(supplierId).first();
    if (!route) throw new APIError(404, 'NOT_FOUND', 'No subdomain route found');
    return route;
  },
};

// ============================================================================
// WEBHOOK API
// ============================================================================
export const WebhookAPI = {
  async list() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.webhooks.where('supplierId').equals(supplierId).toArray();
  },

  async create(data: { url: string; events: string[] }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const webhook = {
      webhookId: generateId(),
      supplierId,
      ...data,
      events: JSON.stringify(data.events),
      secret: generateId(),
      active: true,
      createdAt: new Date().toISOString(),
    };
    await db.webhooks.add(webhook);
    return webhook;
  },

  async trigger(eventType: string, payload: any) {
    const supplierId = getCurrentSupplierId();
    const webhooks = await db.webhooks.where('supplierId').equals(supplierId).filter(w => w.active).toArray();
    
    for (const webhook of webhooks) {
      const events: string[] = JSON.parse(webhook.events);
      if (events.includes(eventType) || events.includes('*')) {
        // Simulate webhook delivery
        console.log(`[WEBHOOK] Delivering ${eventType} to ${webhook.url}`, payload);
        if (webhook.id) {
          await db.webhooks.update(webhook.id, { 
            lastTriggeredAt: new Date().toISOString(),
            lastResponseStatus: 200,
          });
        }
      }
    }
  },
};

// ============================================================================
// QUALITY ASSURANCE API
// ============================================================================
export const QualityAPI = {
  async getMetrics(periodType: 'monthly' | 'quarterly' | 'annual' = 'monthly', limit = 12) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const metrics = await db.qualityMetrics
      .where('supplierId').equals(supplierId)
      .and(m => m.periodType === periodType)
      .toArray();
    return metrics
      .sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime())
      .slice(0, limit);
  },

  async getLatestMetrics() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const metrics = await db.qualityMetrics
      .where('supplierId').equals(supplierId)
      .and(m => m.periodType === 'monthly')
      .toArray();
    const sorted = metrics.sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime());
    return sorted[0] || null;
  },

  async addMetric(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const metric = {
      metricId: generateId(),
      supplierId,
      ...data,
      recordedAt: new Date().toISOString(),
    };
    await db.qualityMetrics.add(metric);
    eventBus.emit('quality:metric_added', { supplierId, metricId: metric.metricId });
    return metric;
  },

  async getInspections(filters?: { status?: string; type?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let inspections = await db.inspections.where('supplierId').equals(supplierId).toArray();
    if (filters?.status) inspections = inspections.filter(i => i.status === filters.status);
    if (filters?.type) inspections = inspections.filter(i => i.type === filters.type);
    return inspections.sort((a, b) => new Date(b.scheduledDate).getTime() - new Date(a.scheduledDate).getTime());
  },

  async getInspection(inspectionId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const inspection = await db.inspections.where('inspectionId').equals(inspectionId).first();
    if (!inspection || inspection.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Inspection not found');
    return inspection;
  },

  async createInspection(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const now = new Date().toISOString();
    const inspection = {
      inspectionId: generateId(),
      supplierId,
      ...data,
      findings: JSON.stringify(data.findings || []),
      correctiveActions: JSON.stringify(data.correctiveActions || []),
      attachments: JSON.stringify(data.attachments || []),
      status: 'scheduled',
      conclusion: 'pending',
      createdAt: now,
      updatedAt: now,
    };
    await db.inspections.add(inspection);
    eventBus.emit('quality:inspection_created', { supplierId, inspectionId: inspection.inspectionId });
    await ProductsAPI.logActivity('inspection.created', 'inspection', inspection.inspectionId, { title: data.title });
    return inspection;
  },

  async updateInspection(inspectionId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const inspection = await db.inspections.where('inspectionId').equals(inspectionId).first();
    if (!inspection || inspection.supplierId !== supplierId || !inspection.id) throw new APIError(404, 'NOT_FOUND', 'Inspection not found');
    const updateData = { ...data, updatedAt: new Date().toISOString() };
    if (data.findings) updateData.findings = JSON.stringify(data.findings);
    if (data.correctiveActions) updateData.correctiveActions = JSON.stringify(data.correctiveActions);
    if (data.attachments) updateData.attachments = JSON.stringify(data.attachments);
    await db.inspections.update(inspection.id, updateData);
    return await this.getInspection(inspectionId);
  },

  async getNCRReports(filters?: { status?: string; severity?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let reports = await db.ncrReports.where('supplierId').equals(supplierId).toArray();
    if (filters?.status) reports = reports.filter(r => r.status === filters.status);
    if (filters?.severity) reports = reports.filter(r => r.severity === filters.severity);
    return reports.sort((a, b) => new Date(b.reportedDate).getTime() - new Date(a.reportedDate).getTime());
  },

  async getNCRReport(ncrId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const report = await db.ncrReports.where('ncrId').equals(ncrId).first();
    if (!report || report.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'NCR report not found');
    return report;
  },

  async createNCRReport(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const now = new Date().toISOString();
    const count = await db.ncrReports.where('supplierId').equals(supplierId).count();
    const ncrNumber = `NCR-${new Date().getFullYear()}-${String(count + 1).padStart(3, '0')}`;
    const report = {
      ncrId: generateId(),
      supplierId,
      ncrNumber,
      ...data,
      status: 'open',
      createdAt: now,
      updatedAt: now,
    };
    await db.ncrReports.add(report);
    eventBus.emit('quality:ncr_created', { supplierId, ncrId: report.ncrId });
    await ProductsAPI.logActivity('ncr.created', 'ncr', report.ncrId, { ncrNumber, title: data.title });
    return report;
  },

  async updateNCRReport(ncrId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const report = await db.ncrReports.where('ncrId').equals(ncrId).first();
    if (!report || report.supplierId !== supplierId || !report.id) throw new APIError(404, 'NOT_FOUND', 'NCR report not found');
    await db.ncrReports.update(report.id, { ...data, updatedAt: new Date().toISOString() });
    return await this.getNCRReport(ncrId);
  },

  async getCAPAActions(filters?: { status?: string; priority?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let actions = await db.capaActions.where('supplierId').equals(supplierId).toArray();
    if (filters?.status) actions = actions.filter(a => a.status === filters.status);
    if (filters?.priority) actions = actions.filter(a => a.priority === filters.priority);
    return actions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async createCAPAAction(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const now = new Date().toISOString();
    const count = await db.capaActions.where('supplierId').equals(supplierId).count();
    const capaNumber = `CAPA-${new Date().getFullYear()}-${String(count + 1).padStart(3, '0')}`;
    const action = {
      capaId: generateId(),
      supplierId,
      capaNumber,
      ...data,
      status: 'open',
      createdAt: now,
      updatedAt: now,
    };
    await db.capaActions.add(action);
    eventBus.emit('quality:capa_created', { supplierId, capaId: action.capaId });
    return action;
  },

  async updateCAPAAction(capaId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const action = await db.capaActions.where('capaId').equals(capaId).first();
    if (!action || action.supplierId !== supplierId || !action.id) throw new APIError(404, 'NOT_FOUND', 'CAPA action not found');
    await db.capaActions.update(action.id, { ...data, updatedAt: new Date().toISOString() });
    return action;
  },

  async getScorecards(limit = 10) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const scorecards = await db.scorecards.where('supplierId').equals(supplierId).toArray();
    return scorecards.sort((a, b) => new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime()).slice(0, limit);
  },

  async getLatestScorecard() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const scorecards = await db.scorecards.where('supplierId').equals(supplierId).toArray();
    const sorted = scorecards.sort((a, b) => new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime());
    return sorted[0] || null;
  },

  async getQualityDocuments(filters?: { status?: string; type?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let docs = await db.qualityDocuments.where('supplierId').equals(supplierId).toArray();
    if (filters?.status) docs = docs.filter(d => d.status === filters.status);
    if (filters?.type) docs = docs.filter(d => d.type === filters.type);
    return docs.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  },

  async createQualityDocument(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const now = new Date().toISOString();
    const doc = {
      docId: generateId(),
      supplierId,
      ...data,
      status: data.status || 'draft',
      createdAt: now,
      updatedAt: now,
    };
    await db.qualityDocuments.add(doc);
    return doc;
  },

  async getQualitySummary() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const [metrics, inspections, ncrs, capas, scorecards] = await Promise.all([
      db.qualityMetrics.where('supplierId').equals(supplierId).toArray(),
      db.inspections.where('supplierId').equals(supplierId).toArray(),
      db.ncrReports.where('supplierId').equals(supplierId).toArray(),
      db.capaActions.where('supplierId').equals(supplierId).toArray(),
      db.scorecards.where('supplierId').equals(supplierId).toArray(),
    ]);

    const latestMetrics = metrics.sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime())[0];
    const openNCRs = ncrs.filter(n => n.status !== 'closed').length;
    const openCAPAs = capas.filter(c => !['closed', 'verified'].includes(c.status)).length;
    const overdueCAPAs = capas.filter(c => c.status !== 'closed' && new Date(c.dueDate) < new Date()).length;

    return {
      latestMetrics,
      totalInspections: inspections.length,
      completedInspections: inspections.filter(i => i.status === 'completed').length,
      scheduledInspections: inspections.filter(i => i.status === 'scheduled').length,
      totalNCRs: ncrs.length,
      openNCRs,
      closedNCRs: ncrs.filter(n => n.status === 'closed').length,
      totalCAPAs: capas.length,
      openCAPAs,
      overdueCAPAs,
      completedCAPAs: capas.filter(c => ['completed', 'verified', 'closed'].includes(c.status)).length,
      latestScorecard: scorecards.sort((a, b) => new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime())[0] || null,
    };
  },
};

// ============================================================================
// MANPOWER SOURCING API
// ============================================================================
export const ManpowerAPI = {
  async getExperts(filters?: { region?: string; availability?: string; skill?: string }) {
    await simulateLatency();
    let experts = await db.experts.toArray();
    if (filters?.region) experts = experts.filter(e => e.region === filters.region);
    if (filters?.availability) experts = experts.filter(e => e.availability === filters.availability);
    return experts.sort((a, b) => b.rating - a.rating);
  },

  async getExpert(expertId: string) {
    await simulateLatency();
    const expert = await db.experts.where('expertId').equals(expertId).first();
    if (!expert) throw new APIError(404, 'NOT_FOUND', 'Expert not found');
    return expert;
  },

  async getExpertSkills() {
    await simulateLatency();
    return await db.expertSkills.toArray();
  },

  async getSourcingRequests(filters?: { status?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let requests = await db.sourcingRequests.where('supplierId').equals(supplierId).toArray();
    if (filters?.status) requests = requests.filter(r => r.status === filters.status);
    return requests.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async getSourcingRequest(requestId: string) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const request = await db.sourcingRequests.where('requestId').equals(requestId).first();
    if (!request || request.supplierId !== supplierId) throw new APIError(404, 'NOT_FOUND', 'Request not found');
    return request;
  },

  async createSourcingRequest(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const now = new Date().toISOString();
    const count = await db.sourcingRequests.where('supplierId').equals(supplierId).count();
    const requestNumber = `SR-${new Date().getFullYear()}-${String(count + 1).padStart(3, '0')}`;
    const request = {
      requestId: generateId(),
      supplierId,
      requestNumber,
      ...data,
      status: 'draft',
      candidatesShortlisted: 0,
      candidatesInterviewed: 0,
      createdBy: 'Current User',
      createdAt: now,
      updatedAt: now,
    };
    await db.sourcingRequests.add(request);
    eventBus.emit('sourcing:request_created', { supplierId, requestId: request.requestId });
    return request;
  },

  async updateSourcingRequest(requestId: string, data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const request = await db.sourcingRequests.where('requestId').equals(requestId).first();
    if (!request || request.supplierId !== supplierId || !request.id) throw new APIError(404, 'NOT_FOUND', 'Request not found');
    await db.sourcingRequests.update(request.id, { ...data, updatedAt: new Date().toISOString() });
    return await this.getSourcingRequest(requestId);
  },

  async getContracts(filters?: { status?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let contracts = await db.expertContracts.where('supplierId').equals(supplierId).toArray();
    if (filters?.status) contracts = contracts.filter(c => c.status === filters.status);
    return contracts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async getAssignments(filters?: { status?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let assignments = await db.expertAssignments.where('supplierId').equals(supplierId).toArray();
    if (filters?.status) assignments = assignments.filter(a => a.status === filters.status);
    return assignments.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  },

  async getSourcingSummary() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const [experts, requests, contracts, assignments] = await Promise.all([
      db.experts.toArray(),
      db.sourcingRequests.where('supplierId').equals(supplierId).toArray(),
      db.expertContracts.where('supplierId').equals(supplierId).toArray(),
      db.expertAssignments.where('supplierId').equals(supplierId).toArray(),
    ]);

    return {
      totalExperts: experts.length,
      availableExperts: experts.filter(e => e.availability === 'available').length,
      localExperts: experts.filter(e => e.region === 'local').length,
      internationalExperts: experts.filter(e => e.region === 'international').length,
      openRequests: requests.filter(r => ['open', 'screening', 'shortlisted', 'interview'].includes(r.status)).length,
      activeContracts: contracts.filter(c => c.status === 'active').length,
      activeAssignments: assignments.filter(a => a.status === 'active').length,
      totalSpend: contracts.reduce((sum, c) => sum + c.totalValue, 0),
    };
  },
};

// ============================================================================
// DATABASE STATS API
// ============================================================================
export const DatabaseAPI = {
  async getStats() {
    await simulateLatency();
    return {
      suppliers: await db.suppliers.count(),
      users: await db.users.count(),
      products: await db.products.count(),
      certifications: await db.certifications.count(),
      messages: await db.messages.count(),
      pages: await db.pages.count(),
      banners: await db.banners.count(),
      menuItems: await db.menuItems.count(),
      emailTemplates: await db.emailTemplates.count(),
      sentEmails: await db.sentEmails.count(),
      siteConfigs: await db.siteConfigs.count(),
      webhooks: await db.webhooks.count(),
      activityLogs: await db.activityLogs.count(),
      apiKeys: await db.apiKeys.count(),
      subdomainRoutes: await db.subdomainRoutes.count(),
      qualityMetrics: await db.qualityMetrics.count(),
      inspections: await db.inspections.count(),
      ncrReports: await db.ncrReports.count(),
      capaActions: await db.capaActions.count(),
      scorecards: await db.scorecards.count(),
      qualityDocuments: await db.qualityDocuments.count(),
    };
  },

  async getServerInfo() {
    return {
      version: '1.0.0',
      database: 'IndexedDB (Dexie.js)',
      tables: 15,
      uptime: Math.floor((Date.now() - performance.timing.navigationStart) / 1000),
      lastBackup: new Date().toISOString(),
      storageUsed: await db.suppliers.count() > 0 ? '2.4 MB' : '0 MB',
    };
  },
};
