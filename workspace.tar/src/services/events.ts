// ============================================================================
// EVENT BUS - Real-time event system for multi-tenant platform
// ============================================================================

type EventHandler = (data: any) => void;

class EventBus {
  private handlers: Map<string, Set<EventHandler>> = new Map();

  on(event: string, handler: EventHandler) {
    if (!this.handlers.has(event)) {
      this.handlers.set(event, new Set());
    }
    this.handlers.get(event)!.add(handler);
    
    // Return unsubscribe function
    return () => {
      this.handlers.get(event)?.delete(handler);
    };
  }

  off(event: string, handler: EventHandler) {
    this.handlers.get(event)?.delete(handler);
  }

  emit(event: string, data: any) {
    console.log(`[EVENT] ${event}`, data);
    this.handlers.get(event)?.forEach(handler => {
      try {
        handler(data);
      } catch (error) {
        console.error(`[EVENT] Error in handler for ${event}:`, error);
      }
    });
  }

  once(event: string, handler: EventHandler) {
    const wrapper = (data: any) => {
      handler(data);
      this.off(event, wrapper);
    };
    this.on(event, wrapper);
  }

  clear() {
    this.handlers.clear();
  }
}

export const eventBus = new EventBus();

// Event types
export const EVENTS = {
  // Supplier events
  SUPPLIER_REGISTERED: 'supplier:registered',
  SUPPLIER_UPDATED: 'supplier:updated',
  SUPPLIER_APPROVED: 'supplier:approved',
  
  // Product events
  PRODUCT_CREATED: 'product:created',
  PRODUCT_UPDATED: 'product:updated',
  PRODUCT_DELETED: 'product:deleted',
  
  // Certification events
  CERTIFICATION_CREATED: 'certification:created',
  CERTIFICATION_DELETED: 'certification:deleted',
  
  // Message events
  MESSAGE_SENT: 'message:sent',
  MESSAGE_RECEIVED: 'message:received',
  
  // CMS events
  PAGE_CREATED: 'page:created',
  PAGE_UPDATED: 'page:updated',
  PAGE_DELETED: 'page:deleted',
  
  // Email events
  EMAIL_SENT: 'email:sent',
  EMAIL_DELIVERED: 'email:delivered',
  EMAIL_FAILED: 'email:failed',
  
  // Site events
  SITE_UPDATED: 'site:updated',
  
  // User events
  USER_INVITED: 'user:invited',
  USER_UPDATED: 'user:updated',
  USER_DELETED: 'user:deleted',
  
  // Webhook events
  WEBHOOK_TRIGGERED: 'webhook:triggered',
} as const;
