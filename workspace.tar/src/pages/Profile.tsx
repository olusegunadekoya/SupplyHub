import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Save, Building, MapPin, Globe, Phone, Mail, Users, Calendar, Edit3, CheckCircle, Shield } from 'lucide-react';

export default function Profile() {
  const { supplier, setSupplier } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const [formData, setFormData] = useState({
    companyName: supplier?.companyName || 'Müller Components GmbH',
    contactPerson: supplier?.contactPerson || 'Hans Müller',
    email: supplier?.email || 'hans.mueller@mueller-components.de',
    phone: supplier?.phone || '+49 89 1234 5678',
    address: supplier?.address || 'Industriestraße 42',
    city: supplier?.city || 'Munich',
    country: supplier?.country || 'Germany',
    industry: supplier?.industry || 'Manufacturing & Industrial Components',
    companySize: supplier?.companySize || '51-200',
    description: supplier?.description || 'Müller Components GmbH is a leading manufacturer of precision industrial components, specializing in mechanical parts, seals, and custom machining services. With over 25 years of experience, we serve clients across automotive, aerospace, and general industrial sectors throughout Europe.',
    website: supplier?.website || 'www.mueller-components.de',
    taxId: supplier?.taxId || 'DE123456789',
  });

  const handleSave = () => {
    setSupplier({
      id: '1',
      ...formData,
      status: 'approved',
      registeredAt: '2024-01-10',
      subdomain: 'mueller-components',
      brandColor: '#c06d23',
      logoText: 'MC',
    });
    setIsEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Company Profile</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Manage your company information and profile details</p>
        </div>
        {!isEditing ? (
          <button onClick={() => setIsEditing(true)} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
            <Edit3 className="w-4 h-4" /> Edit Profile
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button onClick={() => setIsEditing(false)} className="px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-slate-warm-50 rounded-lg transition-colors">
              Cancel
            </button>
            <button onClick={handleSave} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
              <Save className="w-4 h-4" /> Save Changes
            </button>
          </div>
        )}
      </div>

      {/* Success message */}
      {saved && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3 animate-fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-600" />
          <p className="text-sm font-medium text-emerald-700">Profile updated successfully!</p>
        </div>
      )}

      {/* Status banner */}
      <div className="bg-gradient-to-r from-emerald-50 to-emerald-100/50 border border-emerald-200 rounded-xl p-5 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
          <Shield className="w-6 h-6 text-emerald-600" />
        </div>
        <div>
          <p className="text-sm font-semibold text-emerald-800">Verified Supplier</p>
          <p className="text-xs text-emerald-600 mt-0.5">Your company profile has been verified. Member since January 2024.</p>
        </div>
      </div>

      {/* Profile card */}
      <div className="bg-white rounded-2xl border border-slate-warm-200 overflow-hidden">
        {/* Cover */}
        <div className="h-32 bg-gradient-to-r from-warm-600 via-warm-500 to-warm-400 relative">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 right-0 w-48 h-48 bg-white rounded-full -translate-y-1/2 translate-x-1/4" />
            <div className="absolute bottom-0 left-1/3 w-32 h-32 bg-white rounded-full translate-y-1/2" />
          </div>
        </div>

        {/* Company info */}
        <div className="px-6 pb-6 -mt-10 relative">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4 mb-6">
            <div className="w-20 h-20 rounded-2xl bg-white border-4 border-white shadow-lg flex items-center justify-center bg-gradient-to-br from-warm-400 to-warm-600">
              <span className="text-2xl font-bold text-white">MC</span>
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-slate-warm-900">{formData.companyName}</h2>
              <p className="text-sm text-slate-warm-500">{formData.industry}</p>
            </div>
          </div>

          {/* Form / Display */}
          <div className="space-y-6">
            {/* About */}
            <div>
              <h3 className="text-sm font-semibold text-slate-warm-700 mb-3 flex items-center gap-2">
                <Building className="w-4 h-4" /> About the Company
              </h3>
              {isEditing ? (
                <textarea
                  rows={4}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-3 bg-slate-warm-50 border border-slate-warm-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none"
                />
              ) : (
                <p className="text-sm text-slate-warm-600 leading-relaxed bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">{formData.description}</p>
              )}
            </div>

            {/* Details grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">
                <label className="text-xs font-medium text-slate-warm-500 uppercase tracking-wider">Contact Person</label>
                {isEditing ? (
                  <input value={formData.contactPerson} onChange={e => setFormData({ ...formData, contactPerson: e.target.value })}
                    className="w-full mt-1.5 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
                ) : (
                  <p className="text-sm font-medium text-slate-warm-800 mt-1.5 flex items-center gap-2"><Users className="w-4 h-4 text-slate-warm-400" />{formData.contactPerson}</p>
                )}
              </div>

              <div className="bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">
                <label className="text-xs font-medium text-slate-warm-500 uppercase tracking-wider">Email</label>
                {isEditing ? (
                  <input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full mt-1.5 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
                ) : (
                  <p className="text-sm font-medium text-slate-warm-800 mt-1.5 flex items-center gap-2"><Mail className="w-4 h-4 text-slate-warm-400" />{formData.email}</p>
                )}
              </div>

              <div className="bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">
                <label className="text-xs font-medium text-slate-warm-500 uppercase tracking-wider">Phone</label>
                {isEditing ? (
                  <input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full mt-1.5 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
                ) : (
                  <p className="text-sm font-medium text-slate-warm-800 mt-1.5 flex items-center gap-2"><Phone className="w-4 h-4 text-slate-warm-400" />{formData.phone}</p>
                )}
              </div>

              <div className="bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">
                <label className="text-xs font-medium text-slate-warm-500 uppercase tracking-wider">Website</label>
                {isEditing ? (
                  <input value={formData.website} onChange={e => setFormData({ ...formData, website: e.target.value })}
                    className="w-full mt-1.5 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
                ) : (
                  <p className="text-sm font-medium text-slate-warm-800 mt-1.5 flex items-center gap-2"><Globe className="w-4 h-4 text-slate-warm-400" />{formData.website}</p>
                )}
              </div>

              <div className="bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">
                <label className="text-xs font-medium text-slate-warm-500 uppercase tracking-wider">Address</label>
                {isEditing ? (
                  <div className="space-y-2 mt-1.5">
                    <input value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="Street" />
                    <div className="flex gap-2">
                      <input value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })}
                        className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="City" />
                      <input value={formData.country} onChange={e => setFormData({ ...formData, country: e.target.value })}
                        className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="Country" />
                    </div>
                  </div>
                ) : (
                  <p className="text-sm font-medium text-slate-warm-800 mt-1.5 flex items-center gap-2"><MapPin className="w-4 h-4 text-slate-warm-400" />{formData.address}, {formData.city}, {formData.country}</p>
                )}
              </div>

              <div className="bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">
                <label className="text-xs font-medium text-slate-warm-500 uppercase tracking-wider">Company Size</label>
                {isEditing ? (
                  <select value={formData.companySize} onChange={e => setFormData({ ...formData, companySize: e.target.value })}
                    className="w-full mt-1.5 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
                    <option value="1-10">1-10 employees</option>
                    <option value="11-50">11-50 employees</option>
                    <option value="51-200">51-200 employees</option>
                    <option value="201-500">201-500 employees</option>
                    <option value="500+">500+ employees</option>
                  </select>
                ) : (
                  <p className="text-sm font-medium text-slate-warm-800 mt-1.5 flex items-center gap-2"><Users className="w-4 h-4 text-slate-warm-400" />{formData.companySize} employees</p>
                )}
              </div>
            </div>

            {/* Tax ID */}
            <div className="bg-slate-warm-50 rounded-xl p-4 border border-slate-warm-100">
              <label className="text-xs font-medium text-slate-warm-500 uppercase tracking-wider">Tax ID / VAT Number</label>
              {isEditing ? (
                <input value={formData.taxId} onChange={e => setFormData({ ...formData, taxId: e.target.value })}
                  className="w-full mt-1.5 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
              ) : (
                <p className="text-sm font-medium text-slate-warm-800 mt-1.5">{formData.taxId}</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
