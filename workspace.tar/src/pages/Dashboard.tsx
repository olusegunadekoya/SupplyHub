import React from 'react';
import { useApp } from '../context/AppContext';
import { Package, FileCheck, MessageSquare, TrendingUp, Clock, CheckCircle, AlertCircle, ArrowRight, Globe, Mail, ShieldCheck, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const { products, certifications, messages, supplier } = useApp();
  const activeProducts = products.filter(p => p.status === 'active').length;
  const pendingProducts = products.filter(p => p.status === 'under_review').length;
  const verifiedCerts = certifications.filter(c => c.status === 'verified').length;
  const pendingCerts = certifications.filter(c => c.status === 'pending').length;
  const unreadMessages = messages.filter(m => !m.read).length;

  const stats = [
    { label: 'Active Products', value: activeProducts, icon: Package, color: 'from-warm-500 to-warm-600', link: '/products' },
    { label: 'Verified Certifications', value: verifiedCerts, icon: FileCheck, color: 'from-emerald-500 to-emerald-600', link: '/certifications' },
    { label: 'Pending Reviews', value: pendingProducts + pendingCerts, icon: Clock, color: 'from-amber-500 to-amber-600', link: '/products' },
    { label: 'Unread Messages', value: unreadMessages, icon: MessageSquare, color: 'from-blue-500 to-blue-600', link: '/messages' },
  ];

  const recentMessages = messages.slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Welcome banner */}
      <div className="bg-gradient-to-r from-warm-700 via-warm-600 to-warm-500 rounded-2xl p-6 lg:p-8 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-1/4 w-48 h-48 bg-white rounded-full translate-y-1/2" />
        </div>
        <div className="relative">
          <h1 className="text-2xl lg:text-3xl font-bold mb-2">Welcome back, Müller Components</h1>
          <p className="text-warm-100 text-sm lg:text-base max-w-2xl">
            Your supplier profile is active with {activeProducts} products listed. Keep your certifications up to date and respond to coordinator messages promptly to maintain your verified status.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <Link to="/products" className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors backdrop-blur-sm">
              <Package className="w-4 h-4" /> Manage Products
            </Link>
            <Link to="/messages" className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors backdrop-blur-sm">
              <MessageSquare className="w-4 h-4" /> View Messages
            </Link>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <Link key={idx} to={stat.link} className="bg-white rounded-xl border border-slate-warm-200 p-5 hover:shadow-md hover:border-warm-300 transition-all duration-200 group">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-warm-500 mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-slate-warm-900">{stat.value}</p>
              </div>
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                <stat.icon className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-1 text-xs text-slate-warm-400 group-hover:text-warm-600 transition-colors">
              <span>View details</span>
              <ArrowRight className="w-3 h-3" />
            </div>
          </Link>
        ))}
      </div>

      {/* Content grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent products */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center justify-between">
            <h2 className="text-base font-semibold text-slate-warm-800">Recent Products</h2>
            <Link to="/products" className="text-sm text-warm-600 hover:text-warm-700 font-medium">View all</Link>
          </div>
          <div className="divide-y divide-slate-warm-100">
            {products.slice(0, 4).map(product => (
              <div key={product.id} className="px-5 py-4 hover:bg-slate-warm-50 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-medium text-slate-warm-800 truncate">{product.name}</h3>
                    <p className="text-xs text-slate-warm-500 mt-0.5">{product.category} • {product.price}</p>
                  </div>
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                    product.status === 'active' ? 'bg-emerald-50 text-emerald-700' :
                    product.status === 'under_review' ? 'bg-amber-50 text-amber-700' :
                    'bg-slate-warm-100 text-slate-warm-600'
                  }`}>
                    {product.status === 'active' && <CheckCircle className="w-3 h-3 mr-1" />}
                    {product.status === 'under_review' && <Clock className="w-3 h-3 mr-1" />}
                    {product.status === 'active' ? 'Active' : product.status === 'under_review' ? 'Under Review' : 'Draft'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent messages */}
        <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center justify-between">
            <h2 className="text-base font-semibold text-slate-warm-800">Messages</h2>
            <Link to="/messages" className="text-sm text-warm-600 hover:text-warm-700 font-medium">View all</Link>
          </div>
          <div className="divide-y divide-slate-warm-100">
            {recentMessages.map(msg => (
              <div key={msg.id} className={`px-5 py-4 ${!msg.read ? 'bg-warm-50/50' : ''}`}>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-warm-400 to-warm-600 flex items-center justify-center text-white text-xs font-semibold flex-shrink-0">
                    {msg.senderName.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium text-slate-warm-800 truncate">{msg.senderName}</p>
                      {!msg.read && <span className="w-2 h-2 bg-warm-500 rounded-full flex-shrink-0" />}
                    </div>
                    <p className="text-xs text-slate-warm-500 mt-0.5 line-clamp-2">{msg.content}</p>
                    <p className="text-xs text-slate-warm-400 mt-1">
                      {new Date(msg.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="bg-white rounded-xl border border-slate-warm-200 p-5">
        <h2 className="text-base font-semibold text-slate-warm-800 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <Link to="/quality" className="flex items-center gap-3 p-3 rounded-lg border border-slate-warm-200 hover:border-warm-300 hover:bg-warm-50 transition-all group">
            <div className="w-9 h-9 rounded-lg bg-emerald-100 flex items-center justify-center group-hover:bg-emerald-200 transition-colors">
              <Shield className="w-4 h-4 text-emerald-700" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-warm-800">Quality Assurance</p>
              <p className="text-xs text-slate-warm-500">NCRs, CAPAs, inspections</p>
            </div>
          </Link>
          <Link to="/products?action=add" className="flex items-center gap-3 p-3 rounded-lg border border-slate-warm-200 hover:border-warm-300 hover:bg-warm-50 transition-all group">
            <div className="w-9 h-9 rounded-lg bg-warm-100 flex items-center justify-center group-hover:bg-warm-200 transition-colors">
              <Package className="w-4 h-4 text-warm-700" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-warm-800">Add Product</p>
              <p className="text-xs text-slate-warm-500">List a new product</p>
            </div>
          </Link>
          <Link to="/site-builder" className="flex items-center gap-3 p-3 rounded-lg border border-slate-warm-200 hover:border-warm-300 hover:bg-warm-50 transition-all group">
            <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center group-hover:bg-blue-200 transition-colors">
              <Globe className="w-4 h-4 text-blue-700" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-warm-800">Customize Site</p>
              <p className="text-xs text-slate-warm-500">Edit header & footer</p>
            </div>
          </Link>
          <Link to="/email" className="flex items-center gap-3 p-3 rounded-lg border border-slate-warm-200 hover:border-warm-300 hover:bg-warm-50 transition-all group">
            <div className="w-9 h-9 rounded-lg bg-emerald-100 flex items-center justify-center group-hover:bg-emerald-200 transition-colors">
              <Mail className="w-4 h-4 text-emerald-700" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-warm-800">Send Email</p>
              <p className="text-xs text-slate-warm-500">Use templates</p>
            </div>
          </Link>
          <Link to="/control-panel" className="flex items-center gap-3 p-3 rounded-lg border border-slate-warm-200 hover:border-warm-300 hover:bg-warm-50 transition-all group">
            <div className="w-9 h-9 rounded-lg bg-purple-100 flex items-center justify-center group-hover:bg-purple-200 transition-colors">
              <ShieldCheck className="w-4 h-4 text-purple-700" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-warm-800">Control Panel</p>
              <p className="text-xs text-slate-warm-500">Admin & users</p>
            </div>
          </Link>
        </div>
      </div>

      {/* Platform Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link to="/site-builder" className="bg-gradient-to-br from-warm-50 to-cream-100 border border-warm-200 rounded-xl p-5 hover:shadow-md transition-all group">
          <div className="w-10 h-10 rounded-lg bg-warm-100 flex items-center justify-center mb-3 group-hover:bg-warm-200 transition-colors">
            <Globe className="w-5 h-5 text-warm-700" />
          </div>
          <h3 className="text-sm font-semibold text-slate-warm-800">Your Subdomain Site</h3>
          <p className="text-xs text-slate-warm-500 mt-1">mueller-components.supplyhub.io — Customize header, footer, and branding.</p>
        </Link>
        <Link to="/content" className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 border border-emerald-200 rounded-xl p-5 hover:shadow-md transition-all group">
          <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center mb-3 group-hover:bg-emerald-200 transition-colors">
            <FileCheck className="w-5 h-5 text-emerald-700" />
          </div>
          <h3 className="text-sm font-semibold text-slate-warm-800">Content Management</h3>
          <p className="text-xs text-slate-warm-500 mt-1">3 published pages, 2 active banners. Manage content for your site.</p>
        </Link>
        <Link to="/email" className="bg-gradient-to-br from-blue-50 to-blue-100/50 border border-blue-200 rounded-xl p-5 hover:shadow-md transition-all group">
          <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center mb-3 group-hover:bg-blue-200 transition-colors">
            <Mail className="w-5 h-5 text-blue-700" />
          </div>
          <h3 className="text-sm font-semibold text-slate-warm-800">Email Services</h3>
          <p className="text-xs text-slate-warm-500 mt-1">3 templates ready. 4 emails sent this week with 76% read rate.</p>
        </Link>
      </div>
    </div>
  );
}
