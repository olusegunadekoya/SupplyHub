import React, { useState } from 'react';
import { BookOpen, Download, Printer, ChevronRight, Server, Database, Code, Shield, Users, Package, Globe, Mail, FileText, Settings, Layers, Zap, GitBranch, Terminal, Folder, AlertCircle, CheckCircle, Lightbulb } from 'lucide-react';

export default function DevelopmentManual() {
  const [activeSection, setActiveSection] = useState('overview');

  const sections = [
    { id: 'overview', label: 'Overview', icon: BookOpen },
    { id: 'architecture', label: 'Architecture', icon: Layers },
    { id: 'database', label: 'Database', icon: Database },
    { id: 'api', label: 'API Layer', icon: Terminal },
    { id: 'deployment', label: 'Deployment', icon: Server },
    { id: 'extension', label: 'Extension Guide', icon: GitBranch },
    { id: 'modules', label: 'Module Reference', icon: Folder },
    { id: 'best-practices', label: 'Best Practices', icon: Lightbulb },
  ];

  const handlePrint = () => window.print();

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900 flex items-center gap-2">
            <BookOpen className="w-7 h-7 text-warm-600" />
            Development Manual
          </h1>
          <p className="text-sm text-slate-warm-500 mt-1">SupplyHub Platform — Deployment & Extension Guide</p>
        </div>
        <div className="flex gap-2 print:hidden">
          <button onClick={handlePrint} className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-warm-200 text-slate-warm-700 rounded-lg text-sm font-medium hover:bg-slate-warm-50 transition-colors">
            <Printer className="w-4 h-4" /> Print / Save PDF
          </button>
          <button onClick={handlePrint} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
            <Download className="w-4 h-4" /> Export Manual
          </button>
        </div>
      </div>

      {/* Table of Contents */}
      <div className="bg-white rounded-xl border border-slate-warm-200 p-6 print:break-after-page">
        <h2 className="text-lg font-bold text-slate-warm-900 mb-4">Table of Contents</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {sections.map((section, idx) => (
            <button key={section.id} onClick={() => setActiveSection(section.id)}
              className="flex items-center gap-3 p-3 rounded-lg border border-slate-warm-200 hover:border-warm-300 hover:bg-warm-50 transition-all text-left group">
              <div className="w-8 h-8 rounded-lg bg-warm-100 flex items-center justify-center group-hover:bg-warm-200 transition-colors">
                <section.icon className="w-4 h-4 text-warm-700" />
              </div>
              <div>
                <p className="text-xs text-slate-warm-400">Chapter {idx + 1}</p>
                <p className="text-sm font-medium text-slate-warm-800">{section.label}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Manual Content */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="p-6 lg:p-8 prose prose-sm max-w-none">
          {activeSection === 'overview' && <OverviewSection />}
          {activeSection === 'architecture' && <ArchitectureSection />}
          {activeSection === 'database' && <DatabaseSection />}
          {activeSection === 'api' && <APISection />}
          {activeSection === 'deployment' && <DeploymentSection />}
          {activeSection === 'extension' && <ExtensionSection />}
          {activeSection === 'modules' && <ModulesSection />}
          {activeSection === 'best-practices' && <BestPracticesSection />}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between print:hidden">
        <button
          onClick={() => {
            const idx = sections.findIndex(s => s.id === activeSection);
            if (idx > 0) setActiveSection(sections[idx - 1].id);
          }}
          disabled={activeSection === sections[0].id}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-warm-200 text-slate-warm-700 rounded-lg text-sm font-medium hover:bg-slate-warm-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          ← Previous
        </button>
        <span className="text-xs text-slate-warm-500">
          {sections.findIndex(s => s.id === activeSection) + 1} / {sections.length}
        </span>
        <button
          onClick={() => {
            const idx = sections.findIndex(s => s.id === activeSection);
            if (idx < sections.length - 1) setActiveSection(sections[idx + 1].id);
          }}
          disabled={activeSection === sections[sections.length - 1].id}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Next →
        </button>
      </div>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="text-2xl font-bold text-slate-warm-900 mb-4 pb-2 border-b border-slate-warm-200">{children}</h2>;
}

function SubTitle({ children }: { children: React.ReactNode }) {
  return <h3 className="text-lg font-semibold text-slate-warm-800 mt-6 mb-2">{children}</h3>;
}

function CodeBlock({ children, title }: { children: React.ReactNode; title?: string }) {
  return (
    <div className="my-4 rounded-lg overflow-hidden border border-slate-warm-200">
      {title && <div className="bg-slate-warm-800 text-slate-warm-200 px-4 py-2 text-xs font-mono">{title}</div>}
      <pre className="bg-slate-warm-900 text-emerald-300 p-4 text-xs overflow-x-auto font-mono">{children}</pre>
    </div>
  );
}

function InfoBox({ type = 'info', children }: { type?: 'info' | 'warning' | 'success'; children: React.ReactNode }) {
  const colors = {
    info: 'bg-blue-50 border-blue-200 text-blue-800',
    warning: 'bg-amber-50 border-amber-200 text-amber-800',
    success: 'bg-emerald-50 border-emerald-200 text-emerald-800',
  };
  const icons = { info: AlertCircle, warning: AlertCircle, success: CheckCircle };
  const Icon = icons[type];
  return (
    <div className={`my-4 p-4 rounded-lg border ${colors[type]} flex items-start gap-3`}>
      <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
      <div className="text-sm">{children}</div>
    </div>
  );
}

function OverviewSection() {
  return (
    <div>
      <SectionTitle>1. Overview</SectionTitle>
      <p className="text-slate-warm-700 leading-relaxed">
        <strong>SupplyHub</strong> is a comprehensive B2B Supplier Relationship Portal designed to manage the entire lifecycle of supplier partnerships. Built as a multi-tenant platform, it enables each supplier to operate on a dedicated subdomain with full control over their web presence, content, communications, and quality management.
      </p>

      <SubTitle>1.1 Key Features</SubTitle>
      <ul className="list-disc pl-6 space-y-2 text-slate-warm-700">
        <li><strong>Multi-Tenant Architecture:</strong> Each supplier gets an isolated subdomain (e.g., <code className="bg-slate-warm-100 px-1 rounded">supplier-name.supplyhub.io</code>)</li>
        <li><strong>Web Server & CMS:</strong> Suppliers control header, footer, branding, pages, and navigation</li>
        <li><strong>Email Services:</strong> Template-based email with delivery tracking and analytics</li>
        <li><strong>Quality Assurance:</strong> NCRs, CAPAs, inspections, scorecards, document control</li>
        <li><strong>Manpower Sourcing:</strong> Technical expert directory (local & international)</li>
        <li><strong>Control Panel:</strong> User management, roles, activity logs, security settings</li>
        <li><strong>Real Database:</strong> IndexedDB with 20+ tables, full CRUD API, event bus</li>
      </ul>

      <SubTitle>1.2 Technology Stack</SubTitle>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
        <div className="bg-slate-warm-50 rounded-lg p-4 border border-slate-warm-200">
          <h4 className="font-semibold text-slate-warm-800 mb-2">Frontend</h4>
          <ul className="text-sm text-slate-warm-700 space-y-1">
            <li>• React 18 + TypeScript</li>
            <li>• Vite (build tool)</li>
            <li>• Tailwind CSS 4</li>
            <li>• React Router 6</li>
            <li>• Recharts (data visualization)</li>
            <li>• Lucide React (icons)</li>
          </ul>
        </div>
        <div className="bg-slate-warm-50 rounded-lg p-4 border border-slate-warm-200">
          <h4 className="font-semibold text-slate-warm-800 mb-2">Backend (Simulated)</h4>
          <ul className="text-sm text-slate-warm-700 space-y-1">
            <li>• Dexie.js (IndexedDB wrapper)</li>
            <li>• REST-style API services</li>
            <li>• Event bus (pub/sub)</li>
            <li>• Multi-tenant isolation</li>
            <li>• Schema versioning</li>
            <li>• Activity logging</li>
          </ul>
        </div>
      </div>

      <SubTitle>1.3 Target Audience</SubTitle>
      <p className="text-slate-warm-700">This manual is intended for:</p>
      <ul className="list-disc pl-6 space-y-1 text-slate-warm-700 mt-2">
        <li>Developers extending the platform with new modules</li>
        <li>System administrators deploying to production</li>
        <li>Platform coordinators managing supplier onboarding</li>
        <li>Technical leads evaluating the architecture</li>
      </ul>
    </div>
  );
}

function ArchitectureSection() {
  return (
    <div>
      <SectionTitle>2. Architecture</SectionTitle>
      <p className="text-slate-warm-700 leading-relaxed">
        SupplyHub follows a layered architecture with clear separation of concerns. The frontend communicates with a simulated backend through a service layer that can be swapped for real HTTP calls in production.
      </p>

      <SubTitle>2.1 Layer Diagram</SubTitle>
      <CodeBlock title="Architecture Layers">
{`┌─────────────────────────────────────────────────────┐
│  PRESENTATION LAYER (React Components)              │
│  - Pages, Layout, Modals                            │
│  - Tailwind CSS styling                             │
├─────────────────────────────────────────────────────┤
│  STATE LAYER (React Context + Dexie Live Queries)   │
│  - AppContext (global state)                        │
│  - useLiveQuery (real-time DB updates)              │
├─────────────────────────────────────────────────────┤
│  SERVICE LAYER (API Abstraction)                    │
│  - SuppliersAPI, ProductsAPI, QualityAPI...         │
│  - Simulates REST with latency                      │
│  - Tenant isolation via supplierId                  │
├─────────────────────────────────────────────────────┤
│  DATA LAYER (Dexie.js / IndexedDB)                  │
│  - 20+ tables with indexes                          │
│  - Schema versioning                                │
│  - Transaction support                              │
├─────────────────────────────────────────────────────┤
│  EVENT LAYER (Event Bus)                            │
│  - Pub/Sub for real-time updates                    │
│  - Webhook dispatch                                 │
│  - Activity logging                                 │
└─────────────────────────────────────────────────────┘`}
      </CodeBlock>

      <SubTitle>2.2 Multi-Tenant Data Isolation</SubTitle>
      <p className="text-slate-warm-700">
        Every database query is scoped to the current supplier's <code className="bg-slate-warm-100 px-1 rounded">supplierId</code>. This ensures complete data isolation between tenants.
      </p>
      <CodeBlock title="Tenant Isolation Pattern">
{`// All API calls use getCurrentSupplierId()
export const ProductsAPI = {
  async list() {
    const supplierId = getCurrentSupplierId();
    return await db.products
      .where('supplierId').equals(supplierId)
      .toArray();
  }
};`}
      </CodeBlock>

      <SubTitle>2.3 Subdomain Routing</SubTitle>
      <p className="text-slate-warm-700">
        The <code className="bg-slate-warm-100 px-1 rounded">subdomain_routes</code> table maps subdomains to suppliers. In production, this would be handled by a reverse proxy (nginx, Cloudflare Workers).
      </p>
      <CodeBlock title="Subdomain Resolution">
{`// Resolve subdomain to supplier
const route = await db.subdomainRoutes
  .where('subdomain').equals('mueller-components')
  .first();

const supplier = await db.suppliers
  .where('supplierId').equals(route.supplierId)
  .first();`}
      </CodeBlock>
    </div>
  );
}

function DatabaseSection() {
  return (
    <div>
      <SectionTitle>3. Database</SectionTitle>
      <p className="text-slate-warm-700 leading-relaxed">
        The platform uses <strong>IndexedDB</strong> via <strong>Dexie.js</strong> as the database. This provides persistent, structured storage in the browser with support for indexes, transactions, and schema versioning.
      </p>

      <SubTitle>3.1 Table Overview</SubTitle>
      <div className="overflow-x-auto my-4">
        <table className="w-full text-sm border border-slate-warm-200 rounded-lg overflow-hidden">
          <thead className="bg-slate-warm-50">
            <tr>
              <th className="text-left px-3 py-2 font-semibold text-slate-warm-700 border-b">Table</th>
              <th className="text-left px-3 py-2 font-semibold text-slate-warm-700 border-b">Purpose</th>
              <th className="text-left px-3 py-2 font-semibold text-slate-warm-700 border-b">Key Indexes</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-warm-100">
            {[
              ['suppliers', 'Tenant root table', 'supplierId, subdomain, email'],
              ['users', 'Portal users with roles', 'userId, supplierId, email'],
              ['products', 'Product catalog', 'productId, supplierId, category'],
              ['certifications', 'Compliance documents', 'certId, supplierId, status'],
              ['messages', 'Coordinator messaging', 'messageId, supplierId, timestamp'],
              ['pages', 'CMS pages', 'pageId, supplierId, slug'],
              ['banners', 'Promotional banners', 'bannerId, supplierId, position'],
              ['menu_items', 'Navigation config', 'menuItemId, supplierId, order'],
              ['email_templates', 'Reusable templates', 'templateId, supplierId, type'],
              ['sent_emails', 'Email delivery tracking', 'emailId, supplierId, status'],
              ['site_configs', 'Site customization', 'supplierId (unique)'],
              ['webhooks', 'Event subscriptions', 'webhookId, supplierId'],
              ['activity_logs', 'Audit trail', 'logId, supplierId, action'],
              ['api_keys', 'API authentication', 'keyId, supplierId, prefix'],
              ['subdomain_routes', 'Subdomain mapping', 'subdomain (unique)'],
              ['quality_metrics', 'Quality KPIs', 'metricId, supplierId, period'],
              ['inspections', 'Inspection records', 'inspectionId, supplierId, status'],
              ['ncr_reports', 'Non-conformance reports', 'ncrId, ncrNumber, status'],
              ['capa_actions', 'Corrective actions', 'capaId, capaNumber, priority'],
              ['scorecards', 'Performance evaluations', 'scorecardId, supplierId, grade'],
              ['quality_documents', 'Controlled documents', 'docId, docNumber, status'],
              ['experts', 'Technical experts', 'expertId, region, availability'],
              ['expert_skills', 'Skills catalog', 'skillId, category, name'],
              ['sourcing_requests', 'Expert requests', 'requestId, requestNumber, status'],
              ['expert_contracts', 'Expert contracts', 'contractId, contractNumber'],
              ['expert_assignments', 'Active assignments', 'assignmentId, expertId, status'],
            ].map(([table, purpose, indexes], idx) => (
              <tr key={idx} className="hover:bg-slate-warm-50">
                <td className="px-3 py-2 font-mono text-xs text-warm-700">{table}</td>
                <td className="px-3 py-2 text-slate-warm-600">{purpose}</td>
                <td className="px-3 py-2 font-mono text-xs text-slate-warm-500">{indexes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SubTitle>3.2 Schema Versioning</SubTitle>
      <p className="text-slate-warm-700">
        Dexie supports schema migrations. When adding new tables or indexes, increment the version number.
      </p>
      <CodeBlock title="Adding a New Table">
{`// In src/db/database.ts
this.version(2).stores({
  // Existing tables...
  suppliers: '++id, &supplierId, &subdomain',
  
  // New table
  newTable: '++id, &uniqueId, supplierId, status',
});`}
      </CodeBlock>

      <SubTitle>3.3 Seeding Data</SubTitle>
      <p className="text-slate-warm-700">
        The <code className="bg-slate-warm-100 px-1 rounded">src/db/seed.ts</code> file populates initial data. It checks if data exists before seeding to avoid duplicates.
      </p>
      <CodeBlock title="Seed Pattern">
{`export async function seedDatabase(): Promise<void> {
  const count = await db.suppliers.count();
  if (count > 0) return; // Already seeded
  
  // Add initial data...
  await db.suppliers.add({ ... });
}`}
      </CodeBlock>
    </div>
  );
}

function APISection() {
  return (
    <div>
      <SectionTitle>4. API Layer</SectionTitle>
      <p className="text-slate-warm-700 leading-relaxed">
        The API layer in <code className="bg-slate-warm-100 px-1 rounded">src/services/api.ts</code> provides REST-style services that simulate a real backend. Each service handles CRUD operations, validation, and event emission.
      </p>

      <SubTitle>4.1 Service Structure</SubTitle>
      <CodeBlock title="API Service Pattern">
{`export const ProductsAPI = {
  // List with filters
  async list(filters?: { status?: string }) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    let products = await db.products
      .where('supplierId').equals(supplierId)
      .toArray();
    if (filters?.status) {
      products = products.filter(p => p.status === filters.status);
    }
    return products;
  },

  // Create with validation
  async create(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const product = {
      productId: generateId(),
      supplierId,
      ...data,
      status: 'under_review',
      createdAt: new Date().toISOString(),
    };
    await db.products.add(product);
    eventBus.emit('product:created', { supplierId, productId: product.productId });
    return product;
  },

  // Update with tenant check
  async update(productId: string, data: any) {
    const supplierId = getCurrentSupplierId();
    const product = await db.products
      .where('productId').equals(productId).first();
    if (!product || product.supplierId !== supplierId) {
      throw new APIError(404, 'NOT_FOUND', 'Product not found');
    }
    await db.products.update(product.id!, data);
    return product;
  },
};`}
      </CodeBlock>

      <SubTitle>4.2 Event Bus</SubTitle>
      <p className="text-slate-warm-700">
        The event bus enables real-time updates and webhook dispatch. Subscribe to events in components:
      </p>
      <CodeBlock title="Event Subscription">
{`import { eventBus, EVENTS } from '../services/events';

useEffect(() => {
  const unsubscribe = eventBus.on(EVENTS.PRODUCT_CREATED, (data) => {
    console.log('New product created:', data);
    // Refresh data, show notification, etc.
  });
  
  return unsubscribe; // Cleanup on unmount
}, []);`}
      </CodeBlock>

      <SubTitle>4.3 Error Handling</SubTitle>
      <CodeBlock title="API Error Pattern">
{`export class APIError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string
  ) {
    super(message);
  }
}

// Usage
throw new APIError(404, 'NOT_FOUND', 'Product not found');
throw new APIError(403, 'FORBIDDEN', 'Insufficient permissions');
throw new APIError(409, 'CONFLICT', 'Subdomain already exists');`}
      </CodeBlock>
    </div>
  );
}

function DeploymentSection() {
  return (
    <div>
      <SectionTitle>5. Deployment</SectionTitle>
      <p className="text-slate-warm-700 leading-relaxed">
        This section covers deploying SupplyHub from development to production, including environment setup, build process, and production considerations.
      </p>

      <SubTitle>5.1 Development Setup</SubTitle>
      <CodeBlock title="Terminal">
{`# Clone the repository
git clone https://github.com/your-org/supplyhub.git
cd supplyhub

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview`}
      </CodeBlock>

      <SubTitle>5.2 Production Build</SubTitle>
      <CodeBlock title="Build Output">
{`dist/
├── index.html          # Entry point
├── assets/
│   ├── index-[hash].js # Bundled JavaScript
│   └── index-[hash].css # Bundled CSS
└── public/             # Static assets`}
      </CodeBlock>

      <SubTitle>5.3 Hosting Options</SubTitle>
      <div className="space-y-3 my-4">
        <div className="bg-slate-warm-50 rounded-lg p-4 border border-slate-warm-200">
          <h4 className="font-semibold text-slate-warm-800">Option A: Static Hosting (Vercel, Netlify, Cloudflare Pages)</h4>
          <p className="text-sm text-slate-warm-600 mt-1">Deploy the <code>dist/</code> folder. No server required. Data persists in browser IndexedDB.</p>
          <CodeBlock title="vercel.json">
{`{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}`}
          </CodeBlock>
        </div>
        <div className="bg-slate-warm-50 rounded-lg p-4 border border-slate-warm-200">
          <h4 className="font-semibold text-slate-warm-800">Option B: Docker Container</h4>
          <CodeBlock title="Dockerfile">
{`FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80`}
          </CodeBlock>
        </div>
        <div className="bg-slate-warm-50 rounded-lg p-4 border border-slate-warm-200">
          <h4 className="font-semibold text-slate-warm-800">Option C: Production Backend (Node.js)</h4>
          <p className="text-sm text-slate-warm-600 mt-1">Replace IndexedDB with PostgreSQL/MySQL. Swap API services with HTTP calls.</p>
        </div>
      </div>

      <SubTitle>5.4 Environment Variables</SubTitle>
      <CodeBlock title=".env.production">
{`VITE_API_BASE_URL=https://api.supplyhub.io
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_SENTRY_DSN=https://xxx@sentry.io/xxx
VITE_ANALYTICS_ID=G-XXXXXXXXXX`}
      </CodeBlock>

      <SubTitle>5.5 Subdomain Configuration</SubTitle>
      <p className="text-slate-warm-700">
        For real subdomain support, configure a wildcard DNS record and reverse proxy:
      </p>
      <CodeBlock title="DNS & Nginx">
{`# DNS: Wildcard A record
*.supplyhub.io  →  YOUR_SERVER_IP

# Nginx configuration
server {
  listen 80;
  server_name ~^(?<subdomain>.+)\\.supplyhub\\.io$;
  
  # Resolve subdomain to supplier
  # Proxy to appropriate backend
  location / {
    proxy_pass http://localhost:3000;
    proxy_set_header X-Subdomain $subdomain;
  }
}`}
      </CodeBlock>

      <InfoBox type="warning">
        <strong>Production Note:</strong> The current implementation uses browser IndexedDB for data persistence. For production multi-tenant use, replace with a server-side database (PostgreSQL recommended) and implement proper authentication (JWT/OAuth).
      </InfoBox>
    </div>
  );
}

function ExtensionSection() {
  return (
    <div>
      <SectionTitle>6. Extension Guide</SectionTitle>
      <p className="text-slate-warm-700 leading-relaxed">
        This guide walks through adding a new module to the SupplyHub platform. We'll use adding a "Procurement" module as an example.
      </p>

      <SubTitle>6.1 Step 1: Define Database Tables</SubTitle>
      <p className="text-slate-warm-700">Add new interfaces and tables to <code className="bg-slate-warm-100 px-1 rounded">src/db/database.ts</code>:</p>
      <CodeBlock title="src/db/database.ts">
{`// 1. Define interface
export interface DBPurchaseOrder {
  id?: number;
  poId: string;
  supplierId: string;
  poNumber: string;
  vendor: string;
  totalAmount: number;
  status: 'draft' | 'pending' | 'approved' | 'received';
  createdAt: string;
}

// 2. Add to database class
export class SupplyHubDatabase extends Dexie {
  purchaseOrders!: Table<DBPurchaseOrder, number>;
  
  constructor() {
    super('SupplyHubDB');
    this.version(2).stores({
      // ... existing tables
      purchaseOrders: '++id, &poId, supplierId, &poNumber, status',
    });
  }
}`}
      </CodeBlock>

      <SubTitle>6.2 Step 2: Add Seed Data</SubTitle>
      <p className="text-slate-warm-700">Update <code className="bg-slate-warm-100 px-1 rounded">src/db/seed.ts</code>:</p>
      <CodeBlock title="src/db/seed.ts">
{`// Add sample purchase orders
const purchaseOrders: DBPurchaseOrder[] = [
  {
    poId: generateId(),
    supplierId,
    poNumber: 'PO-2024-001',
    vendor: 'SteelWorks AG',
    totalAmount: 15000,
    status: 'approved',
    createdAt: new Date().toISOString(),
  },
];
await db.purchaseOrders.bulkAdd(purchaseOrders);`}
      </CodeBlock>

      <SubTitle>6.3 Step 3: Create API Service</SubTitle>
      <CodeBlock title="src/services/api.ts">
{`export const ProcurementAPI = {
  async listPurchaseOrders() {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    return await db.purchaseOrders
      .where('supplierId').equals(supplierId)
      .toArray();
  },

  async createPurchaseOrder(data: any) {
    await simulateLatency();
    const supplierId = getCurrentSupplierId();
    const po = {
      poId: generateId(),
      supplierId,
      poNumber: \`PO-\${new Date().getFullYear()}-\${Date.now()}\`,
      ...data,
      status: 'draft',
      createdAt: new Date().toISOString(),
    };
    await db.purchaseOrders.add(po);
    eventBus.emit('procurement:po_created', { supplierId, poId: po.poId });
    return po;
  },
};`}
      </CodeBlock>

      <SubTitle>6.4 Step 4: Create Page Component</SubTitle>
      <CodeBlock title="src/pages/Procurement.tsx">
{`import React from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { ProcurementAPI } from '../services/api';

export default function Procurement() {
  const orders = useLiveQuery(
    () => ProcurementAPI.listPurchaseOrders(),
    []
  ) || [];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Procurement</h1>
      <div className="grid gap-4">
        {orders.map(order => (
          <div key={order.poId} className="bg-white rounded-xl border p-4">
            <h3>{order.poNumber}</h3>
            <p>Vendor: {order.vendor}</p>
            <p>Amount: €{order.totalAmount}</p>
          </div>
        ))}
      </div>
    </div>
  );
}`}
      </CodeBlock>

      <SubTitle>6.5 Step 5: Add Route & Navigation</SubTitle>
      <CodeBlock title="src/App.tsx">
{`import Procurement from './pages/Procurement';

// In Routes:
<Route path="/procurement" element={<Procurement />} />`}
      </CodeBlock>
      <CodeBlock title="src/components/Layout.tsx">
{`import { ShoppingCart } from 'lucide-react';

// In navItems:
{ to: '/procurement', icon: ShoppingCart, label: 'Procurement', section: 'Overview' }`}
      </CodeBlock>

      <InfoBox type="success">
        <strong>Done!</strong> Your new module is now integrated. Follow this pattern for any new feature: Database → Seed → API → Page → Route → Navigation.
      </InfoBox>
    </div>
  );
}

function ModulesSection() {
  const modules = [
    { name: 'Dashboard', path: '/', desc: 'Overview with KPIs, recent activity, quick actions' },
    { name: 'Products & Services', path: '/products', desc: 'Product catalog with specifications, characteristics, pricing' },
    { name: 'Quality Assurance', path: '/quality', desc: 'NCRs, CAPAs, inspections, scorecards, document control' },
    { name: 'Certifications', path: '/certifications', desc: 'Upload and manage compliance certifications' },
    { name: 'Messages', path: '/messages', desc: 'Real-time messaging with platform coordinator' },
    { name: 'Company Profile', path: '/profile', desc: 'Supplier company information and details' },
    { name: 'Subdomain Site Builder', path: '/site-builder', desc: 'Customize header, footer, branding for subdomain site' },
    { name: 'Content Manager', path: '/content', desc: 'CMS for pages, banners, navigation menu' },
    { name: 'Email Services', path: '/email', desc: 'Template-based email with delivery tracking' },
    { name: 'Control Panel', path: '/control-panel', desc: 'User management, roles, activity logs, security' },
    { name: 'Manpower Sourcing', path: '/manpower', desc: 'Technical expert directory and sourcing requests' },
    { name: 'Database & Server', path: '/database', desc: 'Live database stats, query console, API docs' },
  ];

  return (
    <div>
      <SectionTitle>7. Module Reference</SectionTitle>
      <p className="text-slate-warm-700 leading-relaxed">
        Complete reference of all modules in the SupplyHub platform.
      </p>
      <div className="overflow-x-auto my-4">
        <table className="w-full text-sm border border-slate-warm-200 rounded-lg overflow-hidden">
          <thead className="bg-slate-warm-50">
            <tr>
              <th className="text-left px-3 py-2 font-semibold text-slate-warm-700 border-b">Module</th>
              <th className="text-left px-3 py-2 font-semibold text-slate-warm-700 border-b">Route</th>
              <th className="text-left px-3 py-2 font-semibold text-slate-warm-700 border-b">Description</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-warm-100">
            {modules.map((mod, idx) => (
              <tr key={idx} className="hover:bg-slate-warm-50">
                <td className="px-3 py-2 font-medium text-slate-warm-800">{mod.name}</td>
                <td className="px-3 py-2 font-mono text-xs text-warm-700">{mod.path}</td>
                <td className="px-3 py-2 text-slate-warm-600">{mod.desc}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function BestPracticesSection() {
  return (
    <div>
      <SectionTitle>8. Best Practices</SectionTitle>

      <SubTitle>8.1 Code Organization</SubTitle>
      <ul className="list-disc pl-6 space-y-2 text-slate-warm-700">
        <li>Keep components focused — one responsibility per file</li>
        <li>Use TypeScript interfaces for all data structures</li>
        <li>Extract reusable UI into <code className="bg-slate-warm-100 px-1 rounded">src/components/</code></li>
        <li>Keep API services in <code className="bg-slate-warm-100 px-1 rounded">src/services/</code></li>
        <li>Use <code className="bg-slate-warm-100 px-1 rounded">useLiveQuery</code> for real-time data</li>
      </ul>

      <SubTitle>8.2 Database Guidelines</SubTitle>
      <ul className="list-disc pl-6 space-y-2 text-slate-warm-700">
        <li>Always scope queries by <code className="bg-slate-warm-100 px-1 rounded">supplierId</code> for tenant isolation</li>
        <li>Use compound indexes for complex queries (e.g., <code className="bg-slate-warm-100 px-1 rounded">[supplierId+status]</code>)</li>
        <li>Version your schema when adding tables/indexes</li>
        <li>Store complex data as JSON strings for flexibility</li>
        <li>Use transactions for multi-table writes</li>
      </ul>

      <SubTitle>8.3 Performance</SubTitle>
      <ul className="list-disc pl-6 space-y-2 text-slate-warm-700">
        <li>Lazy load routes with <code className="bg-slate-warm-100 px-1 rounded">React.lazy()</code></li>
        <li>Debounce search inputs (300ms)</li>
        <li>Use <code className="bg-slate-warm-100 px-1 rounded">useMemo</code> for expensive computations</li>
        <li>Avoid unnecessary re-renders with proper key props</li>
        <li>Limit list rendering with pagination/virtualization</li>
      </ul>

      <SubTitle>8.4 Security</SubTitle>
      <ul className="list-disc pl-6 space-y-2 text-slate-warm-700">
        <li>Never trust client-side data — validate on server</li>
        <li>Hash passwords (bcrypt, argon2) — never store plaintext</li>
        <li>Use HTTPS everywhere in production</li>
        <li>Implement rate limiting on API endpoints</li>
        <li>Sanitize user input to prevent XSS</li>
        <li>Use Content Security Policy headers</li>
      </ul>

      <SubTitle>8.5 Testing</SubTitle>
      <CodeBlock title="Testing Checklist">
{`□ Unit tests for API services
□ Component tests for critical UI
□ Integration tests for user flows
□ Database migration tests
□ Multi-tenant isolation tests
□ Performance benchmarks
□ Security audit (OWASP Top 10)
□ Accessibility audit (WCAG 2.1 AA)`}
      </CodeBlock>

      <SubTitle>8.6 Production Readiness</SubTitle>
      <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 my-4">
        <h4 className="font-semibold text-emerald-800 mb-2">Before Going Live:</h4>
        <ul className="list-disc pl-6 space-y-1 text-sm text-emerald-700">
          <li>Replace IndexedDB with server-side database</li>
          <li>Implement proper authentication (JWT/OAuth)</li>
          <li>Set up monitoring (Sentry, DataDog)</li>
          <li>Configure backups and disaster recovery</li>
          <li>Set up CI/CD pipeline</li>
          <li>Load test with realistic traffic</li>
          <li>Review and harden security</li>
          <li>Document runbooks for operations team</li>
        </ul>
      </div>

      <div className="mt-8 p-6 bg-gradient-to-r from-warm-50 to-cream-100 rounded-xl border border-warm-200 text-center">
        <p className="text-sm text-warm-700 font-medium">
          📘 End of Development Manual
        </p>
        <p className="text-xs text-warm-600 mt-1">
          SupplyHub Platform v1.0 — Last updated: {new Date().toLocaleDateString()}
        </p>
      </div>
    </div>
  );
}
