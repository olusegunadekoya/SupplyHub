import React, { useState } from 'react';
import { useApp, PortalUser } from '../context/AppContext';
import {
  ShieldCheck, Users, Activity, Settings, BarChart3, TrendingUp,
  Plus, Edit3, Trash2, Mail, MoreVertical, Crown, UserCheck, Eye,
  Key, Clock, AlertTriangle, CheckCircle, Download, RefreshCw, Lock, Globe, X
} from 'lucide-react';

export default function ControlPanel() {
  const { portalUsers, products, certifications, sentEmails, pages, addPortalUser, updatePortalUser, deletePortalUser } = useApp();
  const [tab, setTab] = useState<'overview' | 'users' | 'activity' | 'settings'>('overview');
  const [showInviteModal, setShowInviteModal] = useState(false);

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Control Panel</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Administer your supplier portal, users, and settings</p>
        </div>
        {tab === 'users' && (
          <button onClick={() => setShowInviteModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
            <Plus className="w-4 h-4" /> Invite User
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'overview', label: 'Overview', icon: BarChart3 },
          { id: 'users', label: 'Users & Roles', icon: Users },
          { id: 'activity', label: 'Activity Log', icon: Activity },
          { id: 'settings', label: 'Portal Settings', icon: Settings },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              tab === t.id ? 'bg-warm-600 text-white shadow-sm' : 'bg-white border border-slate-warm-200 text-slate-warm-600 hover:bg-slate-warm-50'
            }`}>
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {tab === 'overview' && <OverviewTab />}

      {/* Users Tab */}
      {tab === 'users' && (
        <UsersTab
          users={portalUsers}
          onUpdate={updatePortalUser}
          onDelete={deletePortalUser}
        />
      )}

      {/* Activity Tab */}
      {tab === 'activity' && <ActivityTab />}

      {/* Settings Tab */}
      {tab === 'settings' && <SettingsTab />}

      {showInviteModal && <InviteModal onClose={() => setShowInviteModal(false)} />}
    </div>
  );
}

function OverviewTab() {
  const { products, certifications, sentEmails, pages, portalUsers } = useApp();

  const metrics = [
    { label: 'Total Users', value: portalUsers.length, icon: Users, color: 'from-blue-500 to-blue-600', change: '+2 this month' },
    { label: 'Active Products', value: products.filter(p => p.status === 'active').length, icon: TrendingUp, color: 'from-emerald-500 to-emerald-600', change: '+1 this week' },
    { label: 'Emails Sent (30d)', value: sentEmails.length, icon: Mail, color: 'from-warm-500 to-warm-600', change: '+12% vs last month' },
    { label: 'Published Pages', value: pages.filter(p => p.status === 'published').length, icon: Globe, color: 'from-purple-500 to-purple-600', change: 'All live' },
  ];

  const recentActivity = [
    { action: 'Product updated', detail: 'Industrial Grade Steel Bearings - price updated', time: '2 hours ago', icon: TrendingUp, color: 'text-emerald-600 bg-emerald-100' },
    { action: 'Email sent', detail: 'Order confirmation to orders@techfab.fr', time: '5 hours ago', icon: Mail, color: 'text-blue-600 bg-blue-100' },
    { action: 'Page published', detail: 'Quality Assurance page is now live', time: '1 day ago', icon: Globe, color: 'text-purple-600 bg-purple-100' },
    { action: 'User invited', detail: 'maria.s@mueller-components.de invited as viewer', time: '2 days ago', icon: Users, color: 'text-warm-600 bg-warm-100' },
    { action: 'Certificate uploaded', detail: 'CE Marking - Machinery Directive', time: '3 days ago', icon: CheckCircle, color: 'text-emerald-600 bg-emerald-100' },
    { action: 'Site customization', detail: 'Header color changed to #1a1a1a', time: '4 days ago', icon: Settings, color: 'text-slate-warm-600 bg-slate-warm-100' },
  ];

  return (
    <div className="space-y-6">
      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((m, idx) => (
          <div key={idx} className="bg-white rounded-xl border border-slate-warm-200 p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-warm-500">{m.label}</p>
                <p className="text-2xl font-bold text-slate-warm-900 mt-1">{m.value}</p>
                <p className="text-xs text-emerald-600 mt-1">{m.change}</p>
              </div>
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${m.color} flex items-center justify-center`}>
                <m.icon className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Activity & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center justify-between">
            <h2 className="text-base font-semibold text-slate-warm-800">Recent Activity</h2>
            <button className="text-xs text-warm-600 hover:text-warm-700 font-medium flex items-center gap-1">
              <RefreshCw className="w-3 h-3" /> Refresh
            </button>
          </div>
          <div className="divide-y divide-slate-warm-100">
            {recentActivity.map((item, idx) => (
              <div key={idx} className="px-5 py-3 flex items-start gap-3 hover:bg-slate-warm-50 transition-colors">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${item.color}`}>
                  <item.icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-warm-800">{item.action}</p>
                  <p className="text-xs text-slate-warm-500 mt-0.5 truncate">{item.detail}</p>
                </div>
                <span className="text-xs text-slate-warm-400 flex-shrink-0">{item.time}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-warm-100">
            <h2 className="text-base font-semibold text-slate-warm-800">System Status</h2>
          </div>
          <div className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-warm-600">Subdomain</span>
              <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-700">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" /> Active
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-warm-600">Email Service</span>
              <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-700">
                <span className="w-2 h-2 bg-emerald-500 rounded-full" /> Operational
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-warm-600">SSL Certificate</span>
              <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-700">
                <CheckCircle className="w-3 h-3" /> Valid (287 days)
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-warm-600">Storage Used</span>
              <span className="text-xs font-medium text-slate-warm-700">2.4 GB / 10 GB</span>
            </div>
            <div className="pt-3 border-t border-slate-warm-100">
              <div className="w-full bg-slate-warm-100 rounded-full h-2">
                <div className="bg-warm-500 h-2 rounded-full" style={{ width: '24%' }} />
              </div>
            </div>
            <div className="pt-2">
              <p className="text-xs text-slate-warm-500">Last backup: Today at 03:00 UTC</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function UsersTab({ users, onUpdate, onDelete }: { users: PortalUser[]; onUpdate: (id: string, u: Partial<PortalUser>) => void; onDelete: (id: string) => void }) {
  const roleColors: Record<string, string> = {
    owner: 'bg-warm-100 text-warm-700 border-warm-200',
    admin: 'bg-purple-100 text-purple-700 border-purple-200',
    editor: 'bg-blue-100 text-blue-700 border-blue-200',
    viewer: 'bg-slate-warm-100 text-slate-warm-600 border-slate-warm-200',
  };

  const roleIcons: Record<string, React.ReactNode> = {
    owner: <Crown className="w-3 h-3" />,
    admin: <ShieldCheck className="w-3 h-3" />,
    editor: <Edit3 className="w-3 h-3" />,
    viewer: <Eye className="w-3 h-3" />,
  };

  return (
    <div className="space-y-4">
      <div className="bg-warm-50 border border-warm-200 rounded-xl p-4">
        <p className="text-sm text-warm-700"><strong>Role Permissions:</strong> Owner has full access. Admin can manage users and content. Editor can manage products and pages. Viewer has read-only access.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-warm-100 bg-slate-warm-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider">User</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider">Role</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider hidden md:table-cell">Status</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider hidden lg:table-cell">Last Active</th>
                <th className="text-right px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-warm-100">
              {users.map(user => (
                <tr key={user.id} className="hover:bg-slate-warm-50 transition-colors">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-warm-400 to-warm-600 flex items-center justify-center text-white text-xs font-semibold">
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-warm-800">{user.name}</p>
                        <p className="text-xs text-slate-warm-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${roleColors[user.role]}`}>
                      {roleIcons[user.role]}
                      {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                    </span>
                  </td>
                  <td className="px-5 py-4 hidden md:table-cell">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      user.status === 'active' ? 'bg-emerald-50 text-emerald-700' :
                      user.status === 'invited' ? 'bg-blue-50 text-blue-700' :
                      'bg-red-50 text-red-700'
                    }`}>
                      {user.status === 'active' && <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />}
                      {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-5 py-4 hidden lg:table-cell">
                    <span className="text-xs text-slate-warm-500">
                      {user.lastActive === '—' ? '—' : new Date(user.lastActive).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {user.role !== 'owner' && (
                        <>
                          <button className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button onClick={() => onDelete(user.id)} className="p-2 text-slate-warm-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ActivityTab() {
  const activities = [
    { user: 'Hans Müller', action: 'Updated product pricing', detail: 'Industrial Grade Steel Bearings: €12.50 → €13.00', time: '2024-03-15 09:30', type: 'product' },
    { user: 'Anna Weber', action: 'Sent email', detail: 'Order confirmation to orders@techfab.fr', time: '2024-03-15 08:15', type: 'email' },
    { user: 'Klaus Fischer', action: 'Published page', detail: 'Quality Assurance page is now live', time: '2024-03-14 16:45', type: 'content' },
    { user: 'Hans Müller', action: 'Updated site header', detail: 'Changed header background to #1a1a1a', time: '2024-03-14 14:20', type: 'site' },
    { user: 'Anna Weber', action: 'Uploaded certificate', detail: 'CE Marking - Machinery Directive', time: '2024-03-13 11:00', type: 'cert' },
    { user: 'Hans Müller', action: 'Invited user', detail: 'maria.s@mueller-components.de as viewer', time: '2024-03-12 15:30', type: 'user' },
    { user: 'Klaus Fischer', action: 'Created product', detail: 'Custom Rubber Seals & Gaskets', time: '2024-03-10 10:00', type: 'product' },
    { user: 'Hans Müller', action: 'Updated profile', detail: 'Company description updated', time: '2024-03-08 09:00', type: 'profile' },
  ];

  const typeColors: Record<string, string> = {
    product: 'bg-emerald-100 text-emerald-600',
    email: 'bg-blue-100 text-blue-600',
    content: 'bg-purple-100 text-purple-600',
    site: 'bg-warm-100 text-warm-600',
    cert: 'bg-amber-100 text-amber-600',
    user: 'bg-pink-100 text-pink-600',
    profile: 'bg-slate-warm-100 text-slate-warm-600',
  };

  return (
    <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
      <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center justify-between">
        <h2 className="text-base font-semibold text-slate-warm-800">Activity Log</h2>
        <button className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-warm-600 hover:text-slate-warm-800 bg-slate-warm-50 hover:bg-slate-warm-100 rounded-lg transition-colors">
          <Download className="w-3.5 h-3.5" /> Export
        </button>
      </div>
      <div className="divide-y divide-slate-warm-100">
        {activities.map((item, idx) => (
          <div key={idx} className="px-5 py-4 flex items-start gap-4 hover:bg-slate-warm-50 transition-colors">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${typeColors[item.type]}`}>
              <Activity className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-slate-warm-800">
                <span className="font-medium">{item.user}</span> {item.action}
              </p>
              <p className="text-xs text-slate-warm-500 mt-0.5">{item.detail}</p>
            </div>
            <span className="text-xs text-slate-warm-400 flex-shrink-0 whitespace-nowrap">{item.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsTab() {
  const [twoFactor, setTwoFactor] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState('30');
  const [apiAccess, setApiAccess] = useState(false);

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-warm-100">
          <h2 className="text-base font-semibold text-slate-warm-800">Security Settings</h2>
        </div>
        <div className="p-5 space-y-4">
          <label className="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" checked={twoFactor} onChange={e => setTwoFactor(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded border-slate-warm-300 text-warm-600 focus:ring-warm-500" />
            <div>
              <p className="text-sm font-medium text-slate-warm-800">Two-Factor Authentication</p>
              <p className="text-xs text-slate-warm-500 mt-0.5">Require 2FA for all admin users</p>
            </div>
          </label>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Session Timeout</label>
            <select value={sessionTimeout} onChange={e => setSessionTimeout(e.target.value)}
              className="w-full max-w-xs px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
              <option value="15">15 minutes</option>
              <option value="30">30 minutes</option>
              <option value="60">1 hour</option>
              <option value="480">8 hours</option>
            </select>
          </div>
          <label className="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" checked={apiAccess} onChange={e => setApiAccess(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded border-slate-warm-300 text-warm-600 focus:ring-warm-500" />
            <div>
              <p className="text-sm font-medium text-slate-warm-800">API Access</p>
              <p className="text-xs text-slate-warm-500 mt-0.5">Enable REST API for third-party integrations</p>
            </div>
          </label>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-warm-100">
          <h2 className="text-base font-semibold text-slate-warm-800">API Keys</h2>
        </div>
        <div className="p-5 space-y-3">
          <div className="flex items-center gap-3 p-3 bg-slate-warm-50 border border-slate-warm-200 rounded-lg">
            <Key className="w-4 h-4 text-slate-warm-400" />
            <code className="flex-1 text-xs font-mono text-slate-warm-600">shub_live_pk_••••••••••••••••••••</code>
            <button className="text-xs text-warm-600 hover:text-warm-700 font-medium">Regenerate</button>
          </div>
          <p className="text-xs text-slate-warm-500">Use this key to authenticate API requests. Keep it secret.</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-warm-100">
          <h2 className="text-base font-semibold text-slate-warm-800">Danger Zone</h2>
        </div>
        <div className="p-5 space-y-3">
          <div className="flex items-center justify-between p-3 border border-red-200 rounded-lg bg-red-50/50">
            <div>
              <p className="text-sm font-medium text-red-700">Suspend Account</p>
              <p className="text-xs text-red-500">Temporarily disable your supplier portal</p>
            </div>
            <button className="px-3 py-1.5 text-xs font-medium text-red-600 border border-red-300 rounded-lg hover:bg-red-100 transition-colors">Suspend</button>
          </div>
          <div className="flex items-center justify-between p-3 border border-red-200 rounded-lg bg-red-50/50">
            <div>
              <p className="text-sm font-medium text-red-700">Delete Account</p>
              <p className="text-xs text-red-500">Permanently delete your account and all data</p>
            </div>
            <button className="px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors">Delete</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InviteModal({ onClose }: { onClose: () => void }) {
  const { addPortalUser } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<PortalUser['role']>('viewer');

  const handleInvite = () => {
    if (!name || !email) return;
    addPortalUser({
      id: Date.now().toString(),
      name,
      email,
      role,
      status: 'invited',
      lastActive: '—',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-md w-full animate-fade-in">
        <div className="px-6 py-4 border-b border-slate-warm-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-warm-900">Invite User</h2>
          <button onClick={onClose} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Full Name</label>
            <input value={name} onChange={e => setName(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="John Doe" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Email Address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="user@company.com" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Role</label>
            <select value={role} onChange={e => setRole(e.target.value as any)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
              <option value="admin">Admin - Full access</option>
              <option value="editor">Editor - Manage content</option>
              <option value="viewer">Viewer - Read-only</option>
            </select>
          </div>
          <div className="bg-warm-50 border border-warm-200 rounded-lg p-3">
            <p className="text-xs text-warm-700">An invitation email will be sent to the user with instructions to set up their account.</p>
          </div>
          <div className="flex items-center justify-end gap-3 pt-2">
            <button onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-slate-warm-50 rounded-lg transition-colors">Cancel</button>
            <button onClick={handleInvite} disabled={!name || !email}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
              <Mail className="w-4 h-4" /> Send Invite
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
