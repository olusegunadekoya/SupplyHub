import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Upload, FileText, CheckCircle, Clock, AlertTriangle, Trash2, X, Shield, Download, Calendar, Building } from 'lucide-react';

export default function Certifications() {
  const { certifications, addCertification, deleteCertification } = useApp();
  const [showUploadModal, setShowUploadModal] = useState(false);

  const verified = certifications.filter(c => c.status === 'verified');
  const pending = certifications.filter(c => c.status === 'pending');
  const expired = certifications.filter(c => c.status === 'expired');

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Certifications</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Upload and manage your company certifications and compliance documents</p>
        </div>
        <button
          onClick={() => setShowUploadModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm"
        >
          <Upload className="w-4 h-4" /> Upload Certificate
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-slate-warm-200 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-warm-900">{verified.length}</p>
              <p className="text-xs text-slate-warm-500">Verified</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-warm-200 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
              <Clock className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-warm-900">{pending.length}</p>
              <p className="text-xs text-slate-warm-500">Pending Review</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-warm-200 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-warm-900">{expired.length}</p>
              <p className="text-xs text-slate-warm-500">Expired</p>
            </div>
          </div>
        </div>
      </div>

      {/* Info banner */}
      <div className="bg-warm-50 border border-warm-200 rounded-xl p-4 flex items-start gap-3">
        <Shield className="w-5 h-5 text-warm-600 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-medium text-warm-800">Keep your certifications up to date</p>
          <p className="text-xs text-warm-600 mt-0.5">Verified certifications increase trust with buyers and platform coordinators. Upload renewed certificates before expiry to maintain your verified status.</p>
        </div>
      </div>

      {/* Certifications list */}
      <div className="space-y-3">
        {certifications.map(cert => (
          <div key={cert.id} className="bg-white rounded-xl border border-slate-warm-200 p-5 hover:shadow-md hover:border-warm-300 transition-all duration-200">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              {/* Icon */}
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                cert.status === 'verified' ? 'bg-emerald-100' :
                cert.status === 'pending' ? 'bg-amber-100' : 'bg-red-100'
              }`}>
                <FileText className={`w-6 h-6 ${
                  cert.status === 'verified' ? 'text-emerald-600' :
                  cert.status === 'pending' ? 'text-amber-600' : 'text-red-600'
                }`} />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start sm:items-center flex-col sm:flex-row gap-2 sm:gap-4">
                  <h3 className="text-sm font-semibold text-slate-warm-800">{cert.name}</h3>
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                    cert.status === 'verified' ? 'bg-emerald-50 text-emerald-700' :
                    cert.status === 'pending' ? 'bg-amber-50 text-amber-700' :
                    'bg-red-50 text-red-700'
                  }`}>
                    {cert.status === 'verified' && <CheckCircle className="w-3 h-3 mr-1" />}
                    {cert.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                    {cert.status === 'expired' && <AlertTriangle className="w-3 h-3 mr-1" />}
                    {cert.status.charAt(0).toUpperCase() + cert.status.slice(1)}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-slate-warm-500">
                  <span className="flex items-center gap-1">
                    <Building className="w-3.5 h-3.5" /> {cert.issuer}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> Issued: {new Date(cert.issueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> Expires: {new Date(cert.expiryDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <FileText className="w-3.5 h-3.5 text-slate-warm-400" />
                  <span className="text-xs text-slate-warm-500">{cert.fileName}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <button className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                  <Download className="w-4 h-4" />
                </button>
                <button onClick={() => deleteCertification(cert.id)} className="p-2 text-slate-warm-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {certifications.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl border border-slate-warm-200">
          <FileText className="w-12 h-12 text-slate-warm-300 mx-auto mb-3" />
          <p className="text-slate-warm-600 font-medium">No certifications uploaded</p>
          <p className="text-sm text-slate-warm-400 mt-1">Upload your first certificate to get started</p>
        </div>
      )}

      {/* Upload Modal */}
      {showUploadModal && <UploadModal onClose={() => setShowUploadModal(false)} />}
    </div>
  );
}

function UploadModal({ onClose }: { onClose: () => void }) {
  const { addCertification } = useApp();
  const [formData, setFormData] = useState({
    name: '', issuer: '', issueDate: '', expiryDate: '', fileName: ''
  });
  const [dragOver, setDragOver] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addCertification({
      id: Date.now().toString(),
      name: formData.name,
      issuer: formData.issuer,
      issueDate: formData.issueDate,
      expiryDate: formData.expiryDate,
      fileName: formData.fileName || 'uploaded_certificate.pdf',
      status: 'pending',
    });
    onClose();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) setFormData({ ...formData, fileName: file.name });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="text-lg font-semibold text-slate-warm-900">Upload Certificate</h2>
          <button onClick={onClose} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* File upload area */}
          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
              dragOver ? 'border-warm-400 bg-warm-50' : 'border-slate-warm-200 hover:border-warm-300'
            }`}
          >
            <Upload className={`w-10 h-10 mx-auto mb-3 ${dragOver ? 'text-warm-500' : 'text-slate-warm-300'}`} />
            <p className="text-sm font-medium text-slate-warm-700">
              {formData.fileName || 'Drag & drop your certificate here'}
            </p>
            <p className="text-xs text-slate-warm-400 mt-1">PDF, JPG, PNG up to 10MB</p>
            <label className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-warm-50 text-warm-700 rounded-lg text-sm font-medium cursor-pointer hover:bg-warm-100 transition-colors border border-warm-200">
              <Upload className="w-4 h-4" /> Browse Files
              <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png"
                onChange={e => { const f = e.target.files?.[0]; if (f) setFormData({ ...formData, fileName: f.name }); }} />
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Certificate Name *</label>
            <input required value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., ISO 9001:2015" />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Issuing Body *</label>
            <input required value={formData.issuer} onChange={e => setFormData({ ...formData, issuer: e.target.value })}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., TÜV Rheinland" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Issue Date *</label>
              <input required type="date" value={formData.issueDate} onChange={e => setFormData({ ...formData, issueDate: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Expiry Date *</label>
              <input required type="date" value={formData.expiryDate} onChange={e => setFormData({ ...formData, expiryDate: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-warm-100">
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-slate-warm-50 rounded-lg transition-colors">Cancel</button>
            <button type="submit" className="px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">Upload Certificate</button>
          </div>
        </form>
      </div>
    </div>
  );
}
