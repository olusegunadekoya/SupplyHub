import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/database';
import { ManpowerAPI, getCurrentSupplierId } from '../services/api';
import {
  Users, UserCheck, Globe, MapPin, Star, Clock, DollarSign, Briefcase,
  Search, Filter, Plus, Eye, FileText, Calendar, Award, TrendingUp,
  CheckCircle, AlertCircle, X, Send, Download, Phone, Mail, Linkedin
} from 'lucide-react';

export default function ManpowerSourcing() {
  const [tab, setTab] = useState<'experts' | 'requests' | 'contracts' | 'assignments'>('experts');

  const tabs = [
    { id: 'experts', label: 'Expert Directory', icon: Users },
    { id: 'requests', label: 'Sourcing Requests', icon: Send },
    { id: 'contracts', label: 'Contracts', icon: FileText },
    { id: 'assignments', label: 'Active Assignments', icon: Briefcase },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900 flex items-center gap-2">
            <Users className="w-7 h-7 text-warm-600" />
            Manpower Sourcing
          </h1>
          <p className="text-sm text-slate-warm-500 mt-1">Access technical experts (local & international) for your projects</p>
        </div>
      </div>

      {/* Summary Cards */}
      <SummaryCards />

      {/* Tabs */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="flex border-b border-slate-warm-100 overflow-x-auto">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id as any)}
              className={`flex items-center gap-2 px-4 lg:px-5 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                tab === t.id ? 'border-warm-600 text-warm-700 bg-warm-50/50' : 'border-transparent text-slate-warm-500 hover:text-slate-warm-700'
              }`}>
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
        <div className="p-4 lg:p-6">
          {tab === 'experts' && <ExpertsTab />}
          {tab === 'requests' && <RequestsTab />}
          {tab === 'contracts' && <ContractsTab />}
          {tab === 'assignments' && <AssignmentsTab />}
        </div>
      </div>
    </div>
  );
}

function SummaryCards() {
  const summary = useLiveQuery(() => ManpowerAPI.getSourcingSummary(), []);
  if (!summary) return null;

  const cards = [
    { label: 'Available Experts', value: summary.availableExperts, icon: UserCheck, color: 'from-emerald-500 to-emerald-600', sub: `of ${summary.totalExperts} total` },
    { label: 'Open Requests', value: summary.openRequests, icon: Send, color: 'from-blue-500 to-blue-600', sub: 'Active sourcing' },
    { label: 'Active Contracts', value: summary.activeContracts, icon: FileText, color: 'from-warm-500 to-warm-600', sub: `${summary.activeAssignments} assignments` },
    { label: 'Total Investment', value: `€${(summary.totalSpend / 1000).toFixed(0)}k`, icon: DollarSign, color: 'from-purple-500 to-purple-600', sub: 'Contract value' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card, idx) => (
        <div key={idx} className="bg-white rounded-xl border border-slate-warm-200 p-5 hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between mb-3">
            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${card.color} flex items-center justify-center`}>
              <card.icon className="w-5 h-5 text-white" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-warm-900">{card.value}</p>
          <p className="text-xs text-slate-warm-500 mt-1">{card.label}</p>
          <p className="text-xs text-slate-warm-400 mt-0.5">{card.sub}</p>
        </div>
      ))}
    </div>
  );
}

function ExpertsTab() {
  const experts = useLiveQuery(() => ManpowerAPI.getExperts(), []) || [];
  const skills = useLiveQuery(() => ManpowerAPI.getExpertSkills(), []) || [];
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState<any>(null);
  const [search, setSearch] = useState('');

  const filtered = experts.filter(e => {
    const matchesFilter = filter === 'all' || e.region === filter || (filter === 'available' && e.availability === 'available');
    const matchesSearch = !search || 
      `${e.firstName} ${e.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
      e.title.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const regionColors: Record<string, string> = {
    local: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    regional: 'bg-blue-50 text-blue-700 border-blue-200',
    international: 'bg-purple-50 text-purple-700 border-purple-200',
  };

  const availabilityColors: Record<string, string> = {
    available: 'bg-emerald-100 text-emerald-700',
    engaged: 'bg-amber-100 text-amber-700',
    on_leave: 'bg-slate-warm-100 text-slate-warm-600',
    unavailable: 'bg-red-100 text-red-700',
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search experts by name or title..."
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {['all', 'local', 'regional', 'international', 'available'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                filter === f ? 'bg-warm-600 text-white' : 'bg-slate-warm-100 text-slate-warm-600 hover:bg-slate-warm-200'
              }`}>
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Expert Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(expert => {
          const expertSkills = JSON.parse(expert.skills || '[]');
          const skillNames = skills.filter(s => expertSkills.includes(s.skillId)).map(s => s.name);
          
          return (
            <div key={expert.expertId} onClick={() => setSelected(expert)}
              className="bg-white border border-slate-warm-200 rounded-xl p-5 hover:shadow-lg hover:border-warm-300 transition-all cursor-pointer group">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-warm-400 to-warm-600 flex items-center justify-center text-white text-xl font-bold flex-shrink-0">
                  {expert.firstName[0]}{expert.lastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-semibold text-slate-warm-800 group-hover:text-warm-700 transition-colors">
                      {expert.firstName} {expert.lastName}
                    </h3>
                    {expert.verified && <CheckCircle className="w-4 h-4 text-emerald-500" />}
                  </div>
                  <p className="text-xs text-slate-warm-600 mt-0.5">{expert.title}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium border ${regionColors[expert.region]}`}>
                      {expert.region}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${availabilityColors[expert.availability]}`}>
                      {expert.availability.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 flex items-center gap-4 text-xs text-slate-warm-500">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {expert.location}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {expert.yearsExperience}y exp
                </span>
              </div>

              <div className="mt-3 flex flex-wrap gap-1">
                {skillNames.slice(0, 3).map((skill, idx) => (
                  <span key={idx} className="px-2 py-0.5 bg-warm-50 text-warm-700 rounded text-xs border border-warm-200">
                    {skill}
                  </span>
                ))}
                {skillNames.length > 3 && (
                  <span className="px-2 py-0.5 bg-slate-warm-50 text-slate-warm-600 rounded text-xs">
                    +{skillNames.length - 3}
                  </span>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-warm-100 flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-semibold text-slate-warm-800">{expert.rating}</span>
                  <span className="text-xs text-slate-warm-500">({expert.totalAssignments})</span>
                </div>
                <p className="text-sm font-bold text-warm-700">
                  {expert.currency} {expert.hourlyRate}/hr
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-12 h-12 text-slate-warm-300 mx-auto mb-3" />
          <p className="text-slate-warm-600 font-medium">No experts found</p>
          <p className="text-sm text-slate-warm-400 mt-1">Try adjusting your filters</p>
        </div>
      )}

      {/* Expert Detail Modal */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={() => setSelected(null)} />
          <div className="relative bg-white rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-fade-in">
            <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
              <h2 className="text-lg font-semibold text-slate-warm-900">Expert Profile</h2>
              <button onClick={() => setSelected(null)} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-5">
              <div className="flex items-start gap-4">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-warm-400 to-warm-600 flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
                  {selected.firstName[0]}{selected.lastName[0]}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-bold text-slate-warm-900">{selected.firstName} {selected.lastName}</h3>
                    {selected.verified && <CheckCircle className="w-5 h-5 text-emerald-500" />}
                  </div>
                  <p className="text-sm text-slate-warm-600 mt-0.5">{selected.title}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="flex items-center gap-1 text-xs text-slate-warm-500">
                      <MapPin className="w-3 h-3" /> {selected.location}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-slate-warm-500">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" /> {selected.rating} ({selected.totalAssignments} assignments)
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-xs font-medium text-slate-warm-600 mb-1">About</p>
                <p className="text-sm text-slate-warm-700 bg-slate-warm-50 rounded-lg p-3">{selected.bio}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Experience</p>
                  <p className="text-sm font-medium text-slate-warm-800">{selected.yearsExperience} years</p>
                </div>
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Hourly Rate</p>
                  <p className="text-sm font-medium text-slate-warm-800">{selected.currency} {selected.hourlyRate}</p>
                </div>
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Languages</p>
                  <p className="text-sm font-medium text-slate-warm-800">{JSON.parse(selected.languages || '[]').join(', ')}</p>
                </div>
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Availability</p>
                  <p className="text-sm font-medium text-slate-warm-800 capitalize">{selected.availability.replace('_', ' ')}</p>
                </div>
              </div>

              <div>
                <p className="text-xs font-medium text-slate-warm-600 mb-2">Skills</p>
                <div className="flex flex-wrap gap-2">
                  {skills.filter(s => JSON.parse(selected.skills || '[]').includes(s.skillId)).map(skill => (
                    <span key={skill.skillId} className="px-3 py-1.5 bg-warm-50 text-warm-700 rounded-lg text-xs font-medium border border-warm-200">
                      {skill.name}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-xs font-medium text-slate-warm-600 mb-2">Certifications</p>
                <div className="space-y-1">
                  {JSON.parse(selected.certifications || '[]').map((cert: string, idx: number) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-slate-warm-700">
                      <Award className="w-4 h-4 text-warm-600" />
                      {cert}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-xs font-medium text-slate-warm-600 mb-2">Contact</p>
                <div className="space-y-2">
                  <a href={`mailto:${selected.email}`} className="flex items-center gap-2 text-sm text-warm-700 hover:text-warm-800">
                    <Mail className="w-4 h-4" /> {selected.email}
                  </a>
                  <a href={`tel:${selected.phone}`} className="flex items-center gap-2 text-sm text-warm-700 hover:text-warm-800">
                    <Phone className="w-4 h-4" /> {selected.phone}
                  </a>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-warm-100">
                <button className="flex-1 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
                  Request Expert
                </button>
                <button className="px-4 py-2.5 bg-white border border-slate-warm-200 text-slate-warm-700 rounded-lg text-sm font-medium hover:bg-slate-warm-50 transition-colors">
                  Download CV
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function RequestsTab() {
  const requests = useLiveQuery(() => ManpowerAPI.getSourcingRequests(), []) || [];
  const [filter, setFilter] = useState('all');
  const filtered = filter === 'all' ? requests : requests.filter(r => r.status === filter);

  const statusColors: Record<string, string> = {
    draft: 'bg-slate-warm-100 text-slate-warm-600',
    open: 'bg-blue-50 text-blue-700',
    screening: 'bg-indigo-50 text-indigo-700',
    shortlisted: 'bg-purple-50 text-purple-700',
    interview: 'bg-amber-50 text-amber-700',
    offered: 'bg-emerald-50 text-emerald-700',
    contracted: 'bg-emerald-100 text-emerald-800',
    fulfilled: 'bg-emerald-100 text-emerald-700',
    cancelled: 'bg-red-50 text-red-700',
  };

  const urgencyColors: Record<string, string> = {
    low: 'bg-slate-warm-100 text-slate-warm-600',
    medium: 'bg-blue-50 text-blue-700',
    high: 'bg-amber-50 text-amber-700',
    critical: 'bg-red-50 text-red-700',
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          {['all', 'draft', 'open', 'shortlisted', 'interview', 'contracted'].map(s => (
            <button key={s} onClick={() => setFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filter === s ? 'bg-warm-600 text-white' : 'bg-slate-warm-100 text-slate-warm-600 hover:bg-slate-warm-200'
              }`}>
              {s === 'all' ? 'All' : s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
          <Plus className="w-4 h-4" /> New Request
        </button>
      </div>

      <div className="space-y-3">
        {filtered.map(request => (
          <div key={request.requestId} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-start gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <code className="text-xs font-mono text-warm-700 bg-warm-50 px-2 py-0.5 rounded border border-warm-200">{request.requestNumber}</code>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusColors[request.status]}`}>{request.status}</span>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${urgencyColors[request.urgency]}`}>{request.urgency}</span>
                </div>
                <h3 className="text-sm font-semibold text-slate-warm-800 mt-1.5">{request.title}</h3>
                <p className="text-xs text-slate-warm-500 mt-1 line-clamp-2">{request.description}</p>
                <div className="flex items-center gap-4 mt-2 text-xs text-slate-warm-500">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {request.duration}</span>
                  <span className="flex items-center gap-1"><DollarSign className="w-3 h-3" /> {request.currency} {request.budget.toLocaleString()}</span>
                  <span className="flex items-center gap-1"><Globe className="w-3 h-3" /> {request.region}</span>
                </div>
                <div className="flex items-center gap-3 mt-2 text-xs text-slate-warm-500">
                  <span>{request.candidatesShortlisted} shortlisted</span>
                  <span>•</span>
                  <span>{request.candidatesInterviewed} interviewed</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ContractsTab() {
  const contracts = useLiveQuery(() => ManpowerAPI.getContracts(), []) || [];
  const experts = useLiveQuery(() => ManpowerAPI.getExperts(), []) || [];

  const statusColors: Record<string, string> = {
    draft: 'bg-slate-warm-100 text-slate-warm-600',
    pending: 'bg-amber-50 text-amber-700',
    active: 'bg-emerald-50 text-emerald-700',
    completed: 'bg-blue-50 text-blue-700',
    terminated: 'bg-red-50 text-red-700',
  };

  return (
    <div className="space-y-3">
      {contracts.map(contract => {
        const expert = experts.find(e => e.expertId === contract.expertId);
        return (
          <div key={contract.contractId} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-start gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <code className="text-xs font-mono text-warm-700 bg-warm-50 px-2 py-0.5 rounded border border-warm-200">{contract.contractNumber}</code>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusColors[contract.status]}`}>{contract.status}</span>
                </div>
                <h3 className="text-sm font-semibold text-slate-warm-800 mt-1.5">{contract.title}</h3>
                <p className="text-xs text-slate-warm-500 mt-1">{contract.scope}</p>
                <div className="flex items-center gap-4 mt-2 text-xs text-slate-warm-500">
                  <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {expert ? `${expert.firstName} ${expert.lastName}` : 'Unknown'}</span>
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(contract.startDate).toLocaleDateString()} - {new Date(contract.endDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-4 mt-2 text-xs text-slate-warm-500">
                  <span>{contract.currency} {contract.hourlyRate}/hr × {contract.estimatedHours}h</span>
                  <span className="font-semibold text-warm-700">{contract.currency} {contract.totalValue.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function AssignmentsTab() {
  const assignments = useLiveQuery(() => ManpowerAPI.getAssignments(), []) || [];
  const experts = useLiveQuery(() => ManpowerAPI.getExperts(), []) || [];

  const statusColors: Record<string, string> = {
    planned: 'bg-blue-50 text-blue-700',
    active: 'bg-emerald-50 text-emerald-700',
    on_hold: 'bg-amber-50 text-amber-700',
    completed: 'bg-slate-warm-100 text-slate-warm-600',
    cancelled: 'bg-red-50 text-red-700',
  };

  return (
    <div className="space-y-3">
      {assignments.map(assignment => {
        const expert = experts.find(e => e.expertId === assignment.expertId);
        return (
          <div key={assignment.assignmentId} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-start gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-semibold text-slate-warm-800">{assignment.title}</h3>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusColors[assignment.status]}`}>{assignment.status}</span>
                </div>
                <p className="text-xs text-slate-warm-500 mt-1">
                  {expert ? `${expert.firstName} ${expert.lastName}` : 'Unknown Expert'}
                </p>
                <div className="flex items-center gap-4 mt-2 text-xs text-slate-warm-500">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(assignment.startDate).toLocaleDateString()} - {new Date(assignment.endDate).toLocaleDateString()}</span>
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {assignment.hoursLogged}h logged</span>
                </div>
                {assignment.performanceRating && (
                  <div className="flex items-center gap-1 mt-2">
                    <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                    <span className="text-sm font-semibold text-slate-warm-800">{assignment.performanceRating}</span>
                    <span className="text-xs text-slate-warm-500 ml-2">{assignment.feedback}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
