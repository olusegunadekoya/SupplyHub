import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, ArrowLeft, CheckCircle, Building, User, Mail, Phone, MapPin, Globe, FileText, Shield, Package } from 'lucide-react';

export default function Registration() {
  const { setSupplier, completeRegistration } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '', contactPerson: '', email: '', phone: '',
    address: '', city: '', country: '', industry: '',
    companySize: '', description: '', website: '', taxId: '',
    agreeTerms: false,
  });

  const totalSteps = 4;

  const handleSubmit = () => {
    const subdomain = formData.companyName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'supplier';
    setSupplier({
      id: Date.now().toString(),
      companyName: formData.companyName,
      contactPerson: formData.contactPerson,
      email: formData.email,
      phone: formData.phone,
      address: formData.address,
      city: formData.city,
      country: formData.country,
      industry: formData.industry,
      companySize: formData.companySize,
      description: formData.description,
      website: formData.website,
      taxId: formData.taxId,
      status: 'pending',
      registeredAt: new Date().toISOString(),
      subdomain,
      brandColor: '#c06d23',
      logoText: formData.companyName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase(),
    });
    completeRegistration();
    setSubmitted(true);
  };

  const canProceed = () => {
    switch (step) {
      case 1: return formData.companyName && formData.contactPerson && formData.email;
      case 2: return formData.address && formData.city && formData.country;
      case 3: return formData.industry && formData.companySize;
      case 4: return formData.agreeTerms;
      default: return false;
    }
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto animate-fade-in">
        <div className="bg-white rounded-2xl border border-slate-warm-200 p-8 lg:p-12 text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-bold text-slate-warm-900 mb-3">Registration Submitted!</h1>
          <p className="text-slate-warm-600 mb-2">Thank you for registering with SupplyHub.</p>
          <p className="text-sm text-slate-warm-500 mb-8 max-w-md mx-auto">
            Your application is now under review. Our platform coordinator will verify your information and get back to you within 2-3 business days. You'll receive an email notification once your account is approved.
          </p>
          <div className="bg-warm-50 border border-warm-200 rounded-xl p-4 mb-8 text-left max-w-sm mx-auto">
            <p className="text-xs font-medium text-warm-700 mb-2">What's next?</p>
            <ul className="space-y-2 text-xs text-warm-600">
              <li className="flex items-center gap-2"><span className="w-5 h-5 rounded-full bg-warm-200 text-warm-700 flex items-center justify-center text-xs font-bold">1</span> Application review by coordinator</li>
              <li className="flex items-center gap-2"><span className="w-5 h-5 rounded-full bg-warm-200 text-warm-700 flex items-center justify-center text-xs font-bold">2</span> Email confirmation of approval</li>
              <li className="flex items-center gap-2"><span className="w-5 h-5 rounded-full bg-warm-200 text-warm-700 flex items-center justify-center text-xs font-bold">3</span> Upload certifications & list products</li>
            </ul>
          </div>
          <button onClick={() => navigate('/')} className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
            Go to Dashboard <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-warm-50 border border-warm-200 rounded-full text-xs font-medium text-warm-700 mb-4">
          <Shield className="w-3.5 h-3.5" /> Supplier Registration
        </div>
        <h1 className="text-2xl lg:text-3xl font-bold text-slate-warm-900">Join SupplyHub</h1>
        <p className="text-sm text-slate-warm-500 mt-2">Register your company to start listing products and connecting with buyers</p>
      </div>

      {/* Progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-3">
          {[1, 2, 3, 4].map(s => (
            <div key={s} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                s < step ? 'bg-emerald-500 text-white' :
                s === step ? 'bg-warm-600 text-white ring-4 ring-warm-100' :
                'bg-slate-warm-200 text-slate-warm-500'
              }`}>
                {s < step ? <CheckCircle className="w-4 h-4" /> : s}
              </div>
              {s < 4 && <div className={`w-12 sm:w-20 h-0.5 mx-1 ${s < step ? 'bg-emerald-500' : 'bg-slate-warm-200'}`} />}
            </div>
          ))}
        </div>
        <div className="flex justify-between text-xs text-slate-warm-500">
          <span className="hidden sm:inline">Company Info</span>
          <span className="hidden sm:inline">Location</span>
          <span className="hidden sm:inline">Business Details</span>
          <span className="hidden sm:inline">Confirm</span>
        </div>
      </div>

      {/* Form card */}
      <div className="bg-white rounded-2xl border border-slate-warm-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-warm-100 bg-slate-warm-50">
          <h2 className="text-base font-semibold text-slate-warm-800">
            {step === 1 && 'Company Information'}
            {step === 2 && 'Business Location'}
            {step === 3 && 'Business Details'}
            {step === 4 && 'Review & Submit'}
          </h2>
          <p className="text-xs text-slate-warm-500 mt-0.5">
            {step === 1 && 'Basic details about your company'}
            {step === 2 && 'Where your business is located'}
            {step === 3 && 'Industry and operational information'}
            {step === 4 && 'Review your information before submitting'}
          </p>
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Company Name *</label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
                  <input required value={formData.companyName} onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., Müller Components GmbH" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Contact Person *</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
                    <input required value={formData.contactPerson} onChange={e => setFormData({ ...formData, contactPerson: e.target.value })}
                      className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="Full name" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Email *</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
                    <input required type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="email@company.com" />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Phone</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
                    <input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="+49 ..." />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Website</label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
                    <input value={formData.website} onChange={e => setFormData({ ...formData, website: e.target.value })}
                      className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="www.company.com" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Street Address *</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
                  <input required value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="Street and number" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">City *</label>
                  <input required value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="City" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Country *</label>
                  <select required value={formData.country} onChange={e => setFormData({ ...formData, country: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
                    <option value="">Select country</option>
                    <option>Germany</option><option>Austria</option><option>Switzerland</option>
                    <option>France</option><option>Italy</option><option>Netherlands</option>
                    <option>Spain</option><option>United Kingdom</option><option>Poland</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Tax ID / VAT Number</label>
                <input value={formData.taxId} onChange={e => setFormData({ ...formData, taxId: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., DE123456789" />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Industry *</label>
                <select required value={formData.industry} onChange={e => setFormData({ ...formData, industry: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
                  <option value="">Select industry</option>
                  <option>Manufacturing & Industrial Components</option>
                  <option>Automotive</option>
                  <option>Aerospace & Defense</option>
                  <option>Electronics & Electrical</option>
                  <option>Chemicals & Materials</option>
                  <option>Food & Beverage</option>
                  <option>Medical & Healthcare</option>
                  <option>Construction</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Company Size *</label>
                <select required value={formData.companySize} onChange={e => setFormData({ ...formData, companySize: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
                  <option value="">Select size</option>
                  <option value="1-10">1-10 employees</option>
                  <option value="11-50">11-50 employees</option>
                  <option value="51-200">51-200 employees</option>
                  <option value="201-500">201-500 employees</option>
                  <option value="500+">500+ employees</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Company Description</label>
                <textarea rows={4} value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none" placeholder="Briefly describe your company, products, and services..." />
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-5">
              <div className="bg-slate-warm-50 rounded-xl p-5 border border-slate-warm-200 space-y-3">
                <h3 className="text-sm font-semibold text-slate-warm-700">Registration Summary</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div><span className="text-slate-warm-500">Company:</span> <span className="font-medium text-slate-warm-800">{formData.companyName || '—'}</span></div>
                  <div><span className="text-slate-warm-500">Contact:</span> <span className="font-medium text-slate-warm-800">{formData.contactPerson || '—'}</span></div>
                  <div><span className="text-slate-warm-500">Email:</span> <span className="font-medium text-slate-warm-800">{formData.email || '—'}</span></div>
                  <div><span className="text-slate-warm-500">Location:</span> <span className="font-medium text-slate-warm-800">{formData.city}{formData.country ? `, ${formData.country}` : ''}</span></div>
                  <div><span className="text-slate-warm-500">Industry:</span> <span className="font-medium text-slate-warm-800">{formData.industry || '—'}</span></div>
                  <div><span className="text-slate-warm-500">Size:</span> <span className="font-medium text-slate-warm-800">{formData.companySize ? `${formData.companySize} employees` : '—'}</span></div>
                </div>
              </div>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={formData.agreeTerms} onChange={e => setFormData({ ...formData, agreeTerms: e.target.checked })}
                  className="mt-1 w-4 h-4 rounded border-slate-warm-300 text-warm-600 focus:ring-warm-500" />
                <span className="text-sm text-slate-warm-600">
                  I agree to the <a href="#" className="text-warm-600 hover:underline">Terms of Service</a> and <a href="#" className="text-warm-600 hover:underline">Privacy Policy</a>. I confirm that all information provided is accurate and that my company is authorized to operate in the specified industry.
                </span>
              </label>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="px-6 py-4 border-t border-slate-warm-100 flex items-center justify-between bg-slate-warm-50">
          <button
            onClick={() => setStep(s => Math.max(1, s - 1))}
            disabled={step === 1}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowLeft className="w-4 h-4" /> Previous
          </button>
          <span className="text-xs text-slate-warm-400">Step {step} of {totalSteps}</span>
          {step < totalSteps ? (
            <button
              onClick={() => setStep(s => Math.min(totalSteps, s + 1))}
              disabled={!canProceed()}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!canProceed()}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white rounded-lg text-sm font-medium hover:from-emerald-700 hover:to-emerald-800 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <CheckCircle className="w-4 h-4" /> Submit Application
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
