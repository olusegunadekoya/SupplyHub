import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Send, Paperclip, Search, Check, CheckCheck, User, ArrowLeft } from 'lucide-react';

export default function Messages() {
  const { messages, addMessage, markMessageRead } = useApp();
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const coordinatorMessages = messages.filter(m => m.sender === 'coordinator');
  const supplierMessages = messages.filter(m => m.sender === 'supplier');

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Mark all as read on view
  useEffect(() => {
    messages.filter(m => !m.read).forEach(m => markMessageRead(m.id));
  }, []);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    addMessage({
      id: Date.now().toString(),
      sender: 'supplier',
      senderName: 'Müller Components',
      content: newMessage.trim(),
      timestamp: new Date().toISOString(),
      read: true,
    });
    setNewMessage('');

    // Simulate coordinator reply after delay
    setTimeout(() => {
      addMessage({
        id: (Date.now() + 1).toString(),
        sender: 'coordinator',
        senderName: 'Sarah Mitchell',
        content: 'Thank you for your message. We\'ve received it and will review shortly. Our team typically responds within 24 business hours.',
        timestamp: new Date().toISOString(),
        read: false,
      });
    }, 2000);
  };

  const allMessages = [...messages].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  return (
    <div className="max-w-7xl mx-auto animate-fade-in">
      <div className="bg-white rounded-2xl border border-slate-warm-200 overflow-hidden flex flex-col" style={{ height: 'calc(100vh - 140px)', minHeight: '500px' }}>
        {/* Chat header */}
        <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center gap-4 bg-gradient-to-r from-warm-50 to-white">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-warm-400 to-warm-600 flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
            SM
          </div>
          <div className="flex-1">
            <h2 className="text-sm font-semibold text-slate-warm-800">Platform Coordinator</h2>
            <p className="text-xs text-slate-warm-500">Sarah Mitchell • Typically replies within 24h</p>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
              <input
                type="text"
                placeholder="Search messages..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="pl-9 pr-4 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm w-48 focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400"
              />
            </div>
          </div>
        </div>

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-4 bg-cream-50 scrollbar-thin">
          {/* Welcome message */}
          <div className="text-center py-4">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white rounded-full border border-slate-warm-200 text-xs text-slate-warm-500">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
              Conversation started • Jan 10, 2024
            </div>
          </div>

          {allMessages
            .filter(m => !searchTerm || m.content.toLowerCase().includes(searchTerm.toLowerCase()))
            .map((msg, idx) => {
              const isSupplier = msg.sender === 'supplier';
              const showAvatar = idx === 0 || allMessages[idx - 1]?.sender !== msg.sender;

              return (
                <div key={msg.id} className={`flex gap-3 ${isSupplier ? 'flex-row-reverse' : ''} ${showAvatar ? 'mt-4' : 'mt-1'}`}>
                  {/* Avatar */}
                  {showAvatar ? (
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-semibold ${
                      isSupplier ? 'bg-gradient-to-br from-blue-400 to-blue-600 text-white' : 'bg-gradient-to-br from-warm-400 to-warm-600 text-white'
                    }`}>
                      {isSupplier ? 'MC' : 'SM'}
                    </div>
                  ) : (
                    <div className="w-8 flex-shrink-0" />
                  )}

                  {/* Message bubble */}
                  <div className={`max-w-[75%] ${isSupplier ? 'items-end' : 'items-start'}`}>
                    {showAvatar && (
                      <p className={`text-xs font-medium mb-1 ${isSupplier ? 'text-right text-blue-600' : 'text-warm-600'}`}>
                        {isSupplier ? 'You' : msg.senderName}
                      </p>
                    )}
                    <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                      isSupplier
                        ? 'bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-tr-md'
                        : 'bg-white border border-slate-warm-200 text-slate-warm-700 rounded-tl-md shadow-sm'
                    }`}>
                      {msg.content}
                    </div>
                    <p className={`text-xs text-slate-warm-400 mt-1 ${isSupplier ? 'text-right' : ''}`}>
                      {new Date(msg.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                      {isSupplier && <CheckCheck className="w-3 h-3 inline ml-1 text-warm-500" />}
                    </p>
                  </div>
                </div>
              );
            })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="border-t border-slate-warm-100 p-4 bg-white">
          <form onSubmit={handleSend} className="flex items-end gap-3">
            <button type="button" className="p-2.5 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors flex-shrink-0">
              <Paperclip className="w-5 h-5" />
            </button>
            <div className="flex-1 relative">
              <textarea
                value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(e); } }}
                placeholder="Type your message..."
                rows={1}
                className="w-full px-4 py-3 bg-slate-warm-50 border border-slate-warm-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none"
              />
            </div>
            <button
              type="submit"
              disabled={!newMessage.trim()}
              className="p-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-xl hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
          <p className="text-xs text-slate-warm-400 mt-2 text-center">
            Press Enter to send • Shift+Enter for new line
          </p>
        </div>
      </div>
    </div>
  );
}
