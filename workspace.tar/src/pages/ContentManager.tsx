import React, { useState } from 'react';
import { useApp, CMSPage, CMSBanner } from '../context/AppContext';
import { FileText, Plus, Edit3, Trash2, Eye, EyeOff, Globe, Image, Link2, X, Save, Clock, CheckCircle, LayoutGrid, List } from 'lucide-react';

export default function ContentManager() {
  const { pages, banners, menuItems, addPage, updatePage, deletePage, addBanner, updateBanner, deleteBanner, setMenuItems } = useApp();
  const [tab, setTab] = useState<'pages' | 'banners' | 'menu'>('pages');
  const [editingPage, setEditingPage] = useState<CMSPage | null>(null);
  const [editingBanner, setEditingBanner] = useState<CMSBanner | null>(null);
  const [showPageEditor, setShowPageEditor] = useState(false);
  const [showBannerEditor, setShowBannerEditor] = useState(false);

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Content Manager</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Manage pages, banners, and navigation for your subdomain site</p>
        </div>
        <div className="flex items-center gap-2">
          {tab === 'pages' && (
            <button onClick={() => { setEditingPage(null); setShowPageEditor(true); }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
              <Plus className="w-4 h-4" /> New Page
            </button>
          )}
          {tab === 'banners' && (
            <button onClick={() => { setEditingBanner(null); setShowBannerEditor(true); }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
              <Plus className="w-4 h-4" /> New Banner
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="flex border-b border-slate-warm-100">
          {[
            { id: 'pages', label: 'Pages', icon: FileText, count: pages.length },
            { id: 'banners', label: 'Banners', icon: Image, count: banners.length },
            { id: 'menu', label: 'Navigation Menu', icon: LayoutGrid, count: menuItems.length },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id as any)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-colors ${
                tab === t.id ? 'border-warm-600 text-warm-700 bg-warm-50/50' : 'border-transparent text-slate-warm-500 hover:text-slate-warm-700'
              }`}>
              <t.icon className="w-4 h-4" />
              {t.label}
              <span className="px-1.5 py-0.5 bg-slate-warm-100 text-slate-warm-600 rounded text-xs">{t.count}</span>
            </button>
          ))}
        </div>

        <div className="p-6">
          {/* Pages Tab */}
          {tab === 'pages' && (
            <div className="space-y-3">
              {pages.map(page => (
                <div key={page.id} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-semibold text-slate-warm-800">{page.title}</h3>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                          page.status === 'published' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                        }`}>
                          {page.status === 'published' ? <><CheckCircle className="w-3 h-3" /> Published</> : <><Clock className="w-3 h-3" /> Draft</>}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-slate-warm-500">
                        <span className="font-mono">/{page.slug}</span>
                        <span>•</span>
                        <span>Updated {new Date(page.updatedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                        <span>•</span>
                        <span>{page.author}</span>
                      </div>
                      <p className="text-xs text-slate-warm-500 mt-2 line-clamp-2">{page.content.slice(0, 150)}...</p>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button onClick={() => { setEditingPage(page); setShowPageEditor(true); }}
                        className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button onClick={() => deletePage(page.id)}
                        className="p-2 text-slate-warm-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              {pages.length === 0 && (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-slate-warm-300 mx-auto mb-3" />
                  <p className="text-slate-warm-600 font-medium">No pages yet</p>
                  <p className="text-sm text-slate-warm-400 mt-1">Create your first page to get started</p>
                </div>
              )}
            </div>
          )}

          {/* Banners Tab */}
          {tab === 'banners' && (
            <div className="space-y-3">
              {banners.map(banner => (
                <div key={banner.id} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-semibold text-slate-warm-800">{banner.title}</h3>
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                          banner.position === 'hero' ? 'bg-blue-50 text-blue-700' :
                          banner.position === 'sidebar' ? 'bg-purple-50 text-purple-700' :
                          'bg-slate-warm-100 text-slate-warm-600'
                        }`}>{banner.position}</span>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${banner.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-warm-100 text-slate-warm-500'}`}>
                          {banner.active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-warm-500 mt-1">{banner.subtitle}</p>
                      <p className="text-xs text-slate-warm-400 mt-1">CTA: {banner.ctaText} → {banner.ctaLink}</p>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button onClick={() => updateBanner(banner.id, { active: !banner.active })}
                        className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                        {banner.active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      <button onClick={() => { setEditingBanner(banner); setShowBannerEditor(true); }}
                        className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteBanner(banner.id)}
                        className="p-2 text-slate-warm-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Menu Tab */}
          {tab === 'menu' && (
            <div className="space-y-3">
              <p className="text-sm text-slate-warm-600 mb-4">Configure the navigation menu displayed on your subdomain site. Drag to reorder.</p>
              {menuItems.sort((a, b) => a.order - b.order).map((item, idx) => (
                <div key={item.id} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-warm-100 flex items-center justify-center text-warm-700 text-xs font-bold flex-shrink-0">
                    {idx + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-warm-800">{item.label}</p>
                    <p className="text-xs text-slate-warm-500 font-mono">{item.link}</p>
                  </div>
                  <span className="px-2 py-0.5 bg-slate-warm-100 text-slate-warm-600 rounded text-xs capitalize">{item.type}</span>
                  <button className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button onClick={() => setMenuItems(menuItems.filter(m => m.id !== item.id))}
                    className="p-2 text-slate-warm-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              <button className="w-full py-3 border-2 border-dashed border-slate-warm-200 rounded-xl text-sm font-medium text-slate-warm-500 hover:border-warm-300 hover:text-warm-700 hover:bg-warm-50 transition-colors flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" /> Add Menu Item
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Page Editor Modal */}
      {showPageEditor && (
        <PageEditor
          page={editingPage}
          onClose={() => setShowPageEditor(false)}
          onSave={(data) => {
            if (editingPage) {
              updatePage(editingPage.id, data);
            } else {
              addPage({
                id: Date.now().toString(),
                title: data.title || 'Untitled',
                slug: data.slug || 'untitled',
                content: data.content || '',
                status: data.status || 'draft',
                updatedAt: new Date().toISOString().split('T')[0],
                author: 'Hans Müller',
              });
            }
            setShowPageEditor(false);
          }}
        />
      )}

      {/* Banner Editor Modal */}
      {showBannerEditor && (
        <BannerEditor
          banner={editingBanner}
          onClose={() => setShowBannerEditor(false)}
          onSave={(data) => {
            if (editingBanner) {
              updateBanner(editingBanner.id, data);
            } else {
              addBanner({
                id: Date.now().toString(),
                title: data.title || 'New Banner',
                subtitle: data.subtitle || '',
                ctaText: data.ctaText || 'Learn More',
                ctaLink: data.ctaLink || '/',
                active: true,
                position: data.position || 'hero',
              });
            }
            setShowBannerEditor(false);
          }}
        />
      )}
    </div>
  );
}

function PageEditor({ page, onClose, onSave }: { page: CMSPage | null; onClose: () => void; onSave: (data: Partial<CMSPage>) => void }) {
  const [title, setTitle] = useState(page?.title || '');
  const [slug, setSlug] = useState(page?.slug || '');
  const [content, setContent] = useState(page?.content || '');
  const [status, setStatus] = useState<'published' | 'draft'>(page?.status || 'draft');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="text-lg font-semibold text-slate-warm-900">{page ? 'Edit Page' : 'New Page'}</h2>
          <button onClick={onClose} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Page Title</label>
              <input value={title} onChange={e => { setTitle(e.target.value); if (!page) setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-')); }}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="Page title" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Status</label>
              <select value={status} onChange={e => setStatus(e.target.value as any)}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">URL Slug</label>
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-warm-500">/</span>
              <input value={slug} onChange={e => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                className="flex-1 px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Content</label>
            <textarea rows={12} value={content} onChange={e => setContent(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none font-mono" placeholder="Write your page content here..." />
          </div>
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-warm-100">
            <button onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-slate-warm-50 rounded-lg transition-colors">Cancel</button>
            <button onClick={() => onSave({ title, slug, content, status })}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
              <Save className="w-4 h-4" /> Save Page
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function BannerEditor({ banner, onClose, onSave }: { banner: CMSBanner | null; onClose: () => void; onSave: (data: Partial<CMSBanner>) => void }) {
  const [title, setTitle] = useState(banner?.title || '');
  const [subtitle, setSubtitle] = useState(banner?.subtitle || '');
  const [ctaText, setCtaText] = useState(banner?.ctaText || 'Learn More');
  const [ctaLink, setCtaLink] = useState(banner?.ctaLink || '/');
  const [position, setPosition] = useState<'hero' | 'sidebar' | 'footer'>(banner?.position || 'hero');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="text-lg font-semibold text-slate-warm-900">{banner ? 'Edit Banner' : 'New Banner'}</h2>
          <button onClick={onClose} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Title</label>
            <input value={title} onChange={e => setTitle(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Subtitle</label>
            <input value={subtitle} onChange={e => setSubtitle(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">CTA Text</label>
              <input value={ctaText} onChange={e => setCtaText(e.target.value)}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">CTA Link</label>
              <input value={ctaLink} onChange={e => setCtaLink(e.target.value)}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Position</label>
            <select value={position} onChange={e => setPosition(e.target.value as any)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
              <option value="hero">Hero (top of page)</option>
              <option value="sidebar">Sidebar</option>
              <option value="footer">Footer</option>
            </select>
          </div>
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-warm-100">
            <button onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-slate-warm-50 rounded-lg transition-colors">Cancel</button>
            <button onClick={() => onSave({ title, subtitle, ctaText, ctaLink, position })}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
              <Save className="w-4 h-4" /> Save Banner
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
