import React, { useState } from 'react';
import { useApp, EmailTemplate, SentEmail } from '../context/AppContext';
import { Mail, Plus, Send, FileText, Inbox, CheckCircle, Clock, AlertCircle, Eye, Edit3, Trash2, X, Save, Copy, Search, Filter } from 'lucide-react';

export default function EmailService() {
  const { emailTemplates, sentEmails, addEmailTemplate, deleteEmailTemplate, sendEmail } = useApp();
  const [tab, setTab] = useState<'compose' | 'templates' | 'sent' | 'analytics'>('compose');
  const [showTemplateEditor, setShowTemplateEditor] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);

  const stats = {
    sent: sentEmails.length,
    delivered: sentEmails.filter(e => e.status === 'delivered' || e.status === 'read').length,
    read: sentEmails.filter(e => e.status === 'read').length,
    failed: sentEmails.filter(e => e.status === 'failed').length,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Email Services</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Compose emails, manage templates, and track delivery</p>
        </div>
        {tab === 'templates' && (
          <button onClick={() => { setEditingTemplate(null); setShowTemplateEditor(true); }}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
            <Plus className="w-4 h-4" /> New Template
          </button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-warm-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <Send className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-warm-900">{stats.sent}</p>
              <p className="text-xs text-slate-warm-500">Total Sent</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-warm-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-warm-900">{stats.delivered}</p>
              <p className="text-xs text-slate-warm-500">Delivered</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-warm-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-warm-100 flex items-center justify-center">
              <Eye className="w-5 h-5 text-warm-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-warm-900">{stats.read}</p>
              <p className="text-xs text-slate-warm-500">Read</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-warm-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-warm-900">{stats.failed}</p>
              <p className="text-xs text-slate-warm-500">Failed</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="flex border-b border-slate-warm-100 overflow-x-auto">
          {[
            { id: 'compose', label: 'Compose', icon: Send },
            { id: 'templates', label: 'Templates', icon: FileText, count: emailTemplates.length },
            { id: 'sent', label: 'Sent Emails', icon: Inbox, count: sentEmails.length },
            { id: 'analytics', label: 'Analytics', icon: Mail },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id as any)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                tab === t.id ? 'border-warm-600 text-warm-700 bg-warm-50/50' : 'border-transparent text-slate-warm-500 hover:text-slate-warm-700'
              }`}>
              <t.icon className="w-4 h-4" />
              {t.label}
              {t.count !== undefined && <span className="px-1.5 py-0.5 bg-slate-warm-100 text-slate-warm-600 rounded text-xs">{t.count}</span>}
            </button>
          ))}
        </div>

        <div className="p-6">
          {tab === 'compose' && <ComposeTab />}
          {tab === 'templates' && (
            <TemplatesTab
              templates={emailTemplates}
              onEdit={(t) => { setEditingTemplate(t); setShowTemplateEditor(true); }}
              onDelete={deleteEmailTemplate}
            />
          )}
          {tab === 'sent' && <SentTab emails={sentEmails} />}
          {tab === 'analytics' && <AnalyticsTab />}
        </div>
      </div>

      {showTemplateEditor && (
        <TemplateEditor
          template={editingTemplate}
          onClose={() => setShowTemplateEditor(false)}
          onSave={(data) => {
            if (editingTemplate) {
              // Would update in real app
            } else {
              addEmailTemplate({
                id: Date.now().toString(),
                name: data.name || 'New Template',
                subject: data.subject || '',
                body: data.body || '',
                type: data.type || 'custom',
                createdAt: new Date().toISOString().split('T')[0],
              });
            }
            setShowTemplateEditor(false);
          }}
        />
      )}
    </div>
  );
}

function ComposeTab() {
  const { emailTemplates, sendEmail } = useApp();
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [sent, setSent] = useState(false);

  const handleTemplateSelect = (id: string) => {
    setTemplateId(id);
    const template = emailTemplates.find(t => t.id === id);
    if (template) {
      setSubject(template.subject);
      setBody(template.body);
    }
  };

  const handleSend = () => {
    if (!to || !subject) return;
    sendEmail({
      id: Date.now().toString(),
      to,
      subject,
      templateId: templateId || undefined,
      status: 'sent',
      sentAt: new Date().toISOString(),
    });
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setTo('');
      setSubject('');
      setBody('');
      setTemplateId('');
    }, 2000);
  };

  return (
    <div className="space-y-4 max-w-3xl">
      {sent && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3 animate-fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-600" />
          <p className="text-sm font-medium text-emerald-700">Email sent successfully!</p>
        </div>
      )}
      <div>
        <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Use Template</label>
        <select value={templateId} onChange={e => handleTemplateSelect(e.target.value)}
          className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
          <option value="">Start from scratch</option>
          {emailTemplates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">To *</label>
        <input value={to} onChange={e => setTo(e.target.value)}
          className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="recipient@example.com" />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Subject *</label>
        <input value={subject} onChange={e => setSubject(e.target.value)}
          className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="Email subject" />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Body</label>
        <textarea rows={10} value={body} onChange={e => setBody(e.target.value)}
          className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none" placeholder="Write your email..." />
        <p className="text-xs text-slate-warm-400 mt-1">Use {'{{variable}}'} for dynamic content (e.g., {'{{customer_name}}'}, {'{{product_name}}'})</p>
      </div>
      <div className="flex items-center justify-between pt-4 border-t border-slate-warm-100">
        <div className="flex items-center gap-2 text-xs text-slate-warm-500">
          <Mail className="w-4 h-4" />
          <span>From: info@mueller-components.supplyhub.io</span>
        </div>
        <button onClick={handleSend} disabled={!to || !subject}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
          <Send className="w-4 h-4" /> Send Email
        </button>
      </div>
    </div>
  );
}

function TemplatesTab({ templates, onEdit, onDelete }: { templates: EmailTemplate[]; onEdit: (t: EmailTemplate) => void; onDelete: (id: string) => void }) {
  return (
    <div className="space-y-3">
      {templates.map(template => (
        <div key={template.id} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-start gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm font-semibold text-slate-warm-800">{template.name}</h3>
                <span className={`px-2 py-0.5 rounded text-xs font-medium capitalize ${
                  template.type === 'inquiry' ? 'bg-blue-50 text-blue-700' :
                  template.type === 'order' ? 'bg-emerald-50 text-emerald-700' :
                  template.type === 'newsletter' ? 'bg-purple-50 text-purple-700' :
                  'bg-slate-warm-100 text-slate-warm-600'
                }`}>{template.type}</span>
              </div>
              <p className="text-xs text-slate-warm-500 mt-1 font-mono">Subject: {template.subject}</p>
              <p className="text-xs text-slate-warm-500 mt-2 line-clamp-2">{template.body.slice(0, 150)}...</p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <button onClick={() => onEdit(template)} className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                <Edit3 className="w-4 h-4" />
              </button>
              <button className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                <Copy className="w-4 h-4" />
              </button>
              <button onClick={() => onDelete(template.id)} className="p-2 text-slate-warm-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function SentTab({ emails }: { emails: SentEmail[] }) {
  const [search, setSearch] = useState('');
  const filtered = emails.filter(e => e.to.toLowerCase().includes(search.toLowerCase()) || e.subject.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="Search sent emails..." />
      </div>
      <div className="space-y-2">
        {filtered.map(email => (
          <div key={email.id} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-warm-800 truncate">{email.subject}</p>
                <p className="text-xs text-slate-warm-500 mt-0.5">To: {email.to}</p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                  email.status === 'sent' ? 'bg-blue-50 text-blue-700' :
                  email.status === 'delivered' ? 'bg-emerald-50 text-emerald-700' :
                  email.status === 'read' ? 'bg-warm-50 text-warm-700' :
                  'bg-red-50 text-red-700'
                }`}>
                  {email.status === 'sent' && <Clock className="w-3 h-3" />}
                  {email.status === 'delivered' && <CheckCircle className="w-3 h-3" />}
                  {email.status === 'read' && <Eye className="w-3 h-3" />}
                  {email.status === 'failed' && <AlertCircle className="w-3 h-3" />}
                  {email.status.charAt(0).toUpperCase() + email.status.slice(1)}
                </span>
                <span className="text-xs text-slate-warm-400">
                  {new Date(email.sentAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AnalyticsTab() {
  const data = [
    { day: 'Mon', sent: 12, read: 8 },
    { day: 'Tue', sent: 18, read: 14 },
    { day: 'Wed', sent: 15, read: 11 },
    { day: 'Thu', sent: 22, read: 18 },
    { day: 'Fri', sent: 28, read: 21 },
    { day: 'Sat', sent: 8, read: 5 },
    { day: 'Sun', sent: 5, read: 3 },
  ];
  const maxVal = Math.max(...data.map(d => d.sent));

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-slate-warm-800 mb-4">Email Activity (Last 7 Days)</h3>
        <div className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-6">
          <div className="flex items-end gap-3 h-40">
            {data.map((d, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex flex-col gap-1 items-center" style={{ height: '100%' }}>
                  <div className="w-full flex-1 flex items-end gap-0.5">
                    <div className="flex-1 bg-warm-400 rounded-t transition-all" style={{ height: `${(d.sent / maxVal) * 100}%` }} title={`Sent: ${d.sent}`} />
                    <div className="flex-1 bg-emerald-400 rounded-t transition-all" style={{ height: `${(d.read / maxVal) * 100}%` }} title={`Read: ${d.read}`} />
                  </div>
                </div>
                <span className="text-xs text-slate-warm-500 mt-2">{d.day}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-6 mt-4 text-xs">
            <span className="flex items-center gap-2"><span className="w-3 h-3 bg-warm-400 rounded" /> Sent</span>
            <span className="flex items-center gap-2"><span className="w-3 h-3 bg-emerald-400 rounded" /> Read</span>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-warm-50 border border-warm-200 rounded-xl p-4">
          <p className="text-xs text-warm-600 font-medium">Avg. Response Time</p>
          <p className="text-2xl font-bold text-warm-800 mt-1">2.4h</p>
        </div>
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
          <p className="text-xs text-emerald-600 font-medium">Read Rate</p>
          <p className="text-2xl font-bold text-emerald-800 mt-1">76%</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <p className="text-xs text-blue-600 font-medium">Reply Rate</p>
          <p className="text-2xl font-bold text-blue-800 mt-1">42%</p>
        </div>
      </div>
    </div>
  );
}

function TemplateEditor({ template, onClose, onSave }: { template: EmailTemplate | null; onClose: () => void; onSave: (data: Partial<EmailTemplate>) => void }) {
  const [name, setName] = useState(template?.name || '');
  const [subject, setSubject] = useState(template?.subject || '');
  const [body, setBody] = useState(template?.body || '');
  const [type, setType] = useState<EmailTemplate['type']>(template?.type || 'custom');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="text-lg font-semibold text-slate-warm-900">{template ? 'Edit Template' : 'New Template'}</h2>
          <button onClick={onClose} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Template Name</label>
              <input value={name} onChange={e => setName(e.target.value)}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Type</label>
              <select value={type} onChange={e => setType(e.target.value as any)}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
                <option value="inquiry">Inquiry Response</option>
                <option value="order">Order Confirmation</option>
                <option value="newsletter">Newsletter</option>
                <option value="custom">Custom</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Subject Line</label>
            <input value={subject} onChange={e => setSubject(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
            <p className="text-xs text-slate-warm-400 mt-1">Use {'{{variables}}'} for dynamic content</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Email Body</label>
            <textarea rows={10} value={body} onChange={e => setBody(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none" />
          </div>
          <div className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-3">
            <p className="text-xs font-medium text-slate-warm-600 mb-2">Available Variables:</p>
            <div className="flex flex-wrap gap-1.5">
              {['customer_name', 'product_name', 'order_id', 'quantity', 'delivery_date', 'sender_name', 'month'].map(v => (
                <code key={v} className="px-2 py-0.5 bg-white border border-slate-warm-200 rounded text-xs text-warm-700">{'{{' + v + '}}'}</code>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-warm-100">
            <button onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-slate-warm-50 rounded-lg transition-colors">Cancel</button>
            <button onClick={() => onSave({ name, subject, body, type })}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
              <Save className="w-4 h-4" /> Save Template
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
