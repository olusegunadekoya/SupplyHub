import React, { useEffect, useState } from 'react';
import { DatabaseAPI, SubdomainAPI, DatabaseAPI as DbAPI } from '../services/api';
import { db } from '../db/database';
import { Database, Server, Table, Key, Globe, Activity, Zap, Shield, HardDrive, RefreshCw, Code, Terminal } from 'lucide-react';

export default function DatabaseView() {
  const [stats, setStats] = useState<any>(null);
  const [serverInfo, setServerInfo] = useState<any>(null);
  const [subdomain, setSubdomain] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [queryResult, setQueryResult] = useState<any>(null);
  const [query, setQuery] = useState('SELECT * FROM suppliers WHERE supplierId = "sup-mueller-001"');

  const loadData = async () => {
    setLoading(true);
    try {
      const [s, info, sub] = await Promise.all([
        DatabaseAPI.getStats(),
        DatabaseAPI.getServerInfo(),
        SubdomainAPI.getStatus(),
      ]);
      setStats(s);
      setServerInfo(info);
      setSubdomain(sub);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  useEffect(() => { loadData(); }, []);

  const executeQuery = async () => {
    // Simulate query execution
    setQueryResult({
      executing: true,
      startTime: Date.now(),
    });
    
    setTimeout(async () => {
      try {
        let result: any;
        if (query.toLowerCase().includes('suppliers')) {
          result = await db.suppliers.toArray();
        } else if (query.toLowerCase().includes('products')) {
          result = await db.products.toArray();
        } else if (query.toLowerCase().includes('users')) {
          result = await db.users.toArray();
        } else if (query.toLowerCase().includes('activity')) {
          result = await db.activityLogs.toArray();
        } else {
          result = { message: 'Query executed', rows: await db.suppliers.count() };
        }
        setQueryResult({
          executing: false,
          duration: Date.now() - (queryResult?.startTime || Date.now()),
          rows: Array.isArray(result) ? result.length : 1,
          data: Array.isArray(result) ? result.slice(0, 5) : result,
        });
      } catch (err: any) {
        setQueryResult({ executing: false, error: err.message });
      }
    }, 300);
  };

  const tables = [
    { name: 'suppliers', records: stats?.suppliers || 0, description: 'Tenant root table - one row per supplier', indexes: ['supplierId (unique)', 'subdomain (unique)', 'email', 'status'] },
    { name: 'users', records: stats?.users || 0, description: 'Portal users with role-based access', indexes: ['userId (unique)', 'supplierId', 'email', '[supplierId+role]'] },
    { name: 'products', records: stats?.products || 0, description: 'Product catalog per supplier', indexes: ['productId (unique)', 'supplierId', 'category', '[supplierId+status]'] },
    { name: 'certifications', records: stats?.certifications || 0, description: 'Uploaded certifications and compliance docs', indexes: ['certId (unique)', 'supplierId', 'status', 'expiryDate'] },
    { name: 'messages', records: stats?.messages || 0, description: 'Coordinator ↔ supplier messaging', indexes: ['messageId (unique)', 'supplierId', 'timestamp', '[supplierId+read]'] },
    { name: 'pages', records: stats?.pages || 0, description: 'CMS pages for subdomain sites', indexes: ['pageId (unique)', 'supplierId', 'slug', '[supplierId+slug]'] },
    { name: 'banners', records: stats?.banners || 0, description: 'Promotional banners for sites', indexes: ['bannerId (unique)', 'supplierId', 'position', '[supplierId+active]'] },
    { name: 'menu_items', records: stats?.menuItems || 0, description: 'Navigation menu configuration', indexes: ['menuItemId (unique)', 'supplierId', '[supplierId+order]'] },
    { name: 'email_templates', records: stats?.emailTemplates || 0, description: 'Reusable email templates', indexes: ['templateId (unique)', 'supplierId', 'type'] },
    { name: 'sent_emails', records: stats?.sentEmails || 0, description: 'Email delivery tracking', indexes: ['emailId (unique)', 'supplierId', 'status', 'sentAt'] },
    { name: 'site_configs', records: stats?.siteConfigs || 0, description: 'Per-supplier site customization', indexes: ['supplierId (unique)'] },
    { name: 'webhooks', records: stats?.webhooks || 0, description: 'Webhook subscriptions', indexes: ['webhookId (unique)', 'supplierId', '[supplierId+active]'] },
    { name: 'activity_logs', records: stats?.activityLogs || 0, description: 'Audit trail of all actions', indexes: ['logId (unique)', 'supplierId', 'userId', 'action', '[supplierId+createdAt]'] },
    { name: 'api_keys', records: stats?.apiKeys || 0, description: 'API authentication keys', indexes: ['keyId (unique)', 'supplierId', 'prefix'] },
    { name: 'subdomain_routes', records: stats?.subdomainRoutes || 0, description: 'Subdomain → supplier mapping', indexes: ['subdomain (unique)', 'supplierId', 'active'] },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Database & Web Server</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Real-time view of the backend infrastructure, tables, and API</p>
        </div>
        <button onClick={loadData} className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-warm-200 text-slate-warm-700 rounded-lg text-sm font-medium hover:bg-slate-warm-50 transition-colors">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      {/* Server Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <Server className="w-5 h-5" />
            <span className="flex items-center gap-1 text-xs bg-white/20 px-2 py-0.5 rounded-full">
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> Online
            </span>
          </div>
          <p className="text-2xl font-bold">{serverInfo?.uptime || 0}s</p>
          <p className="text-xs text-emerald-100 mt-0.5">Server Uptime</p>
        </div>
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <Database className="w-5 h-5" />
            <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">IndexedDB</span>
          </div>
          <p className="text-2xl font-bold">{serverInfo?.tables || 15}</p>
          <p className="text-xs text-blue-100 mt-0.5">Database Tables</p>
        </div>
        <div className="bg-gradient-to-br from-warm-500 to-warm-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <Globe className="w-5 h-5" />
            <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">Active</span>
          </div>
          <p className="text-2xl font-bold truncate">{subdomain?.subdomain || '—'}</p>
          <p className="text-xs text-warm-100 mt-0.5">Subdomain Route</p>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <HardDrive className="w-5 h-5" />
            <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{serverInfo?.storageUsed || '0 MB'}</span>
          </div>
          <p className="text-2xl font-bold">{stats ? Object.values(stats).reduce((a: number, b: any) => a + (b as number), 0) : 0}</p>
          <p className="text-xs text-purple-100 mt-0.5">Total Records</p>
        </div>
      </div>

      {/* Architecture Diagram */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center gap-2">
          <Code className="w-4 h-4 text-warm-600" />
          <h2 className="text-base font-semibold text-slate-warm-800">System Architecture</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {/* Client */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Zap className="w-4 h-4 text-blue-600" />
                </div>
                <h3 className="text-sm font-semibold text-blue-800">Client Layer</h3>
              </div>
              <ul className="space-y-1.5 text-xs text-blue-700">
                <li>• React + TypeScript</li>
                <li>• Vite (bundler)</li>
                <li>• Tailwind CSS</li>
                <li>• React Router</li>
              </ul>
            </div>

            {/* API */}
            <div className="bg-warm-50 border border-warm-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-warm-100 flex items-center justify-center">
                  <Terminal className="w-4 h-4 text-warm-600" />
                </div>
                <h3 className="text-sm font-semibold text-warm-800">API Layer</h3>
              </div>
              <ul className="space-y-1.5 text-xs text-warm-700">
                <li>• REST-style services</li>
                <li>• Auth middleware</li>
                <li>• Tenant isolation</li>
                <li>• Rate limiting</li>
              </ul>
            </div>

            {/* Database */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <Database className="w-4 h-4 text-emerald-600" />
                </div>
                <h3 className="text-sm font-semibold text-emerald-800">Database</h3>
              </div>
              <ul className="space-y-1.5 text-xs text-emerald-700">
                <li>• IndexedDB (Dexie.js)</li>
                <li>• 15 tables</li>
                <li>• Indexed queries</li>
                <li>• Schema versioning</li>
              </ul>
            </div>

            {/* Events */}
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Activity className="w-4 h-4 text-purple-600" />
                </div>
                <h3 className="text-sm font-semibold text-purple-800">Events</h3>
              </div>
              <ul className="space-y-1.5 text-xs text-purple-700">
                <li>• Pub/Sub bus</li>
                <li>• Webhook dispatch</li>
                <li>• Activity logging</li>
                <li>• Real-time updates</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Tables */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center gap-2">
          <Table className="w-4 h-4 text-warm-600" />
          <h2 className="text-base font-semibold text-slate-warm-800">Database Tables</h2>
          <span className="ml-auto text-xs text-slate-warm-500">{tables.length} tables</span>
        </div>
        <div className="divide-y divide-slate-warm-100">
          {tables.map(table => (
            <div key={table.name} className="px-5 py-3 hover:bg-slate-warm-50 transition-colors">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <code className="text-sm font-mono font-semibold text-warm-700 bg-warm-50 px-2 py-0.5 rounded border border-warm-200">{table.name}</code>
                  <span className="text-xs text-slate-warm-500 hidden md:inline">{table.description}</span>
                </div>
                <div className="flex items-center gap-4 flex-shrink-0">
                  <span className="text-xs text-slate-warm-500">
                    <span className="font-mono font-medium text-slate-warm-700">{table.records}</span> rows
                  </span>
                  <span className="text-xs text-slate-warm-400">
                    {table.indexes.length} indexes
                  </span>
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                {table.indexes.map(idx => (
                  <code key={idx} className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-warm-50 border border-slate-warm-200 rounded text-slate-warm-600">
                    {idx}
                  </code>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Query Console */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-warm-600" />
          <h2 className="text-base font-semibold text-slate-warm-800">Query Console</h2>
          <span className="ml-auto text-xs text-slate-warm-500">Live database queries</span>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-warm-600 mb-1.5">SQL-like Query</label>
            <div className="flex gap-2">
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                className="flex-1 px-3 py-2.5 bg-slate-warm-900 text-emerald-300 border border-slate-warm-700 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-warm-500/20"
                placeholder="SELECT * FROM suppliers..."
              />
              <button onClick={executeQuery} className="px-4 py-2.5 bg-warm-600 text-white rounded-lg text-sm font-medium hover:bg-warm-700 transition-colors">
                Execute
              </button>
            </div>
          </div>
          
          {queryResult && (
            <div className="bg-slate-warm-900 rounded-lg p-4 text-xs font-mono">
              {queryResult.executing ? (
                <p className="text-amber-300">Executing query...</p>
              ) : queryResult.error ? (
                <p className="text-red-400">Error: {queryResult.error}</p>
              ) : (
                <>
                  <p className="text-emerald-400 mb-2">✓ Query executed in {queryResult.duration}ms — {queryResult.rows} row(s) returned</p>
                  <pre className="text-slate-warm-300 overflow-x-auto whitespace-pre-wrap">
                    {JSON.stringify(queryResult.data, null, 2)}
                  </pre>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* API Documentation */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-warm-100 flex items-center gap-2">
          <Shield className="w-4 h-4 text-warm-600" />
          <h2 className="text-base font-semibold text-slate-warm-800">API Endpoints</h2>
        </div>
        <div className="p-5">
          <div className="space-y-2">
            {[
              { method: 'GET', path: '/api/suppliers/current', desc: 'Get current supplier profile' },
              { method: 'PUT', path: '/api/suppliers/current', desc: 'Update supplier profile' },
              { method: 'POST', path: '/api/suppliers/register', desc: 'Register new supplier' },
              { method: 'GET', path: '/api/products', desc: 'List products (filterable)' },
              { method: 'POST', path: '/api/products', desc: 'Create product' },
              { method: 'PUT', path: '/api/products/:id', desc: 'Update product' },
              { method: 'DELETE', path: '/api/products/:id', desc: 'Delete product' },
              { method: 'GET', path: '/api/certifications', desc: 'List certifications' },
              { method: 'POST', path: '/api/certifications', desc: 'Upload certification' },
              { method: 'GET', path: '/api/messages', desc: 'List messages' },
              { method: 'POST', path: '/api/messages', desc: 'Send message' },
              { method: 'GET', path: '/api/cms/pages', desc: 'List CMS pages' },
              { method: 'POST', path: '/api/cms/pages', desc: 'Create page' },
              { method: 'GET', path: '/api/site-config', desc: 'Get site configuration' },
              { method: 'PUT', path: '/api/site-config', desc: 'Update site configuration' },
              { method: 'GET', path: '/api/subdomain/:name', desc: 'Resolve subdomain to supplier' },
              { method: 'POST', path: '/api/email/send', desc: 'Send email' },
              { method: 'GET', path: '/api/email/templates', desc: 'List email templates' },
              { method: 'GET', path: '/api/users', desc: 'List portal users' },
              { method: 'POST', path: '/api/users/invite', desc: 'Invite new user' },
              { method: 'GET', path: '/api/webhooks', desc: 'List webhooks' },
              { method: 'POST', path: '/api/webhooks', desc: 'Create webhook' },
              { method: 'GET', path: '/api/activity', desc: 'Get activity log' },
              { method: 'GET', path: '/api/database/stats', desc: 'Get database statistics' },
            ].map((ep, idx) => (
              <div key={idx} className="flex items-center gap-3 px-3 py-2 hover:bg-slate-warm-50 rounded-lg transition-colors">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold min-w-[50px] text-center ${
                  ep.method === 'GET' ? 'bg-emerald-100 text-emerald-700' :
                  ep.method === 'POST' ? 'bg-blue-100 text-blue-700' :
                  ep.method === 'PUT' ? 'bg-amber-100 text-amber-700' :
                  'bg-red-100 text-red-700'
                }`}>{ep.method}</span>
                <code className="text-xs font-mono text-slate-warm-700 flex-1">{ep.path}</code>
                <span className="text-xs text-slate-warm-500 hidden md:inline">{ep.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
