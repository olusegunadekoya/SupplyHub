import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Globe, Palette, Type, Layout, Eye, Code, Save, CheckCircle, ExternalLink, Copy, RefreshCw, Smartphone, Monitor } from 'lucide-react';

export default function SiteBuilder() {
  const { siteConfig, updateSiteConfig } = useApp();
  const [tab, setTab] = useState<'preview' | 'header' | 'footer' | 'branding' | 'settings'>('preview');
  const [saved, setSaved] = useState(false);
  const [device, setDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [localConfig, setLocalConfig] = useState(siteConfig);

  const subdomain = 'mueller-components';

  const handleSave = () => {
    updateSiteConfig(localConfig);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const tabs = [
    { id: 'preview', label: 'Live Preview', icon: Eye },
    { id: 'header', label: 'Header', icon: Layout },
    { id: 'footer', label: 'Footer', icon: Layout },
    { id: 'branding', label: 'Branding', icon: Palette },
    { id: 'settings', label: 'Site Settings', icon: Code },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Subdomain Site Builder</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Customize your hosted site at <span className="font-mono text-warm-700">{subdomain}.supplyhub.io</span></p>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-warm-200 text-slate-warm-700 rounded-lg text-sm font-medium hover:bg-slate-warm-50 transition-colors">
            <RefreshCw className="w-4 h-4" /> Refresh
          </button>
          <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-warm-200 text-slate-warm-700 rounded-lg text-sm font-medium hover:bg-slate-warm-50 transition-colors">
            <ExternalLink className="w-4 h-4" /> Visit Site
          </button>
          <button onClick={handleSave} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
            {saved ? <><CheckCircle className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" /> Publish Changes</>}
          </button>
        </div>
      </div>

      {/* Subdomain info */}
      <div className="bg-gradient-to-r from-warm-50 to-cream-100 border border-warm-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="w-10 h-10 rounded-lg bg-warm-100 flex items-center justify-center flex-shrink-0">
          <Globe className="w-5 h-5 text-warm-700" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-slate-warm-800">Your dedicated subdomain is live</p>
          <div className="flex items-center gap-2 mt-1">
            <code className="text-xs font-mono bg-white px-2 py-1 rounded border border-warm-200 text-warm-800">{subdomain}.supplyhub.io</code>
            <button className="text-xs text-warm-600 hover:text-warm-700 flex items-center gap-1">
              <Copy className="w-3 h-3" /> Copy
            </button>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
          <span className="text-emerald-700 font-medium">Active</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="flex border-b border-slate-warm-100 overflow-x-auto">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as any)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium whitespace-nowrap transition-colors border-b-2 ${
                tab === t.id
                  ? 'border-warm-600 text-warm-700 bg-warm-50/50'
                  : 'border-transparent text-slate-warm-500 hover:text-slate-warm-700'
              }`}
            >
              <t.icon className="w-4 h-4" /> {t.label}
            </button>
          ))}
        </div>

        <div className="p-6">
          {tab === 'preview' && (
            <div className="space-y-4">
              {/* Device toggle */}
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-warm-600">Preview your site as it appears to visitors</p>
                <div className="flex bg-slate-warm-100 rounded-lg p-1">
                  <button onClick={() => setDevice('desktop')} className={`p-2 rounded ${device === 'desktop' ? 'bg-white shadow-sm text-warm-700' : 'text-slate-warm-500'}`}>
                    <Monitor className="w-4 h-4" />
                  </button>
                  <button onClick={() => setDevice('mobile')} className={`p-2 rounded ${device === 'mobile' ? 'bg-white shadow-sm text-warm-700' : 'text-slate-warm-500'}`}>
                    <Smartphone className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Browser chrome */}
              <div className={`mx-auto transition-all duration-300 ${device === 'mobile' ? 'max-w-sm' : 'w-full'}`}>
                <div className="bg-slate-warm-100 rounded-t-xl px-4 py-2 flex items-center gap-2">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-400" />
                    <div className="w-3 h-3 rounded-full bg-amber-400" />
                    <div className="w-3 h-3 rounded-full bg-emerald-400" />
                  </div>
                  <div className="flex-1 bg-white rounded px-3 py-1 text-xs text-slate-warm-500 font-mono">
                    https://{subdomain}.supplyhub.io
                  </div>
                </div>

                {/* Site preview */}
                <div className="border border-slate-warm-200 rounded-b-xl overflow-hidden bg-white">
                  {/* Header */}
                  <header style={{ backgroundColor: localConfig.headerBg, color: localConfig.headerText }} className="px-6 py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded" style={{ backgroundColor: localConfig.primaryColor }} />
                        <span className="font-semibold">{localConfig.companyName}</span>
                      </div>
                      <nav className="hidden sm:flex items-center gap-4 text-sm">
                        <span>Home</span>
                        <span>Products</span>
                        <span>Services</span>
                        <span>About</span>
                        <span>Contact</span>
                      </nav>
                    </div>
                  </header>

                  {/* Hero */}
                  <div className="px-6 py-12 bg-gradient-to-br from-cream-100 to-warm-50 text-center">
                    <h1 className="text-2xl font-bold text-slate-warm-900 mb-2">{localConfig.companyName}</h1>
                    <p className="text-sm text-slate-warm-600 mb-4">{localConfig.tagline}</p>
                    <button className="px-4 py-2 rounded-lg text-sm font-medium text-white" style={{ backgroundColor: localConfig.primaryColor }}>
                      Request Quote
                    </button>
                  </div>

                  {/* Content */}
                  <div className="px-6 py-8">
                    <h2 className="text-lg font-semibold text-slate-warm-900 mb-3">Featured Products</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {['Steel Bearings', 'CNC Services', 'Rubber Seals'].map(p => (
                        <div key={p} className="p-3 border border-slate-warm-200 rounded-lg">
                          <div className="h-20 bg-slate-warm-100 rounded mb-2" />
                          <p className="text-xs font-medium text-slate-warm-800">{p}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Footer */}
                  <footer style={{ backgroundColor: localConfig.footerBg, color: localConfig.footerText }} className="px-6 py-6 text-xs">
                    <div className="flex flex-col sm:flex-row justify-between gap-4">
                      <div>
                        <p className="font-semibold mb-1">{localConfig.companyName}</p>
                        <p>{localConfig.contactEmail}</p>
                        <p>{localConfig.contactPhone}</p>
                      </div>
                      <div>
                        <p className="font-semibold mb-1">Quick Links</p>
                        <p>Products • Services • Contact</p>
                      </div>
                    </div>
                    <p className="mt-4 pt-4 border-t border-white/10 text-center opacity-75">
                      © 2024 {localConfig.companyName}. Hosted on SupplyHub.
                    </p>
                  </footer>
                </div>
              </div>
            </div>
          )}

          {tab === 'header' && (
            <div className="space-y-5 max-w-2xl">
              <p className="text-sm text-slate-warm-600">Customize your site header. This appears at the top of every page on your subdomain.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Background Color</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={localConfig.headerBg} onChange={e => setLocalConfig({ ...localConfig, headerBg: e.target.value })}
                      className="w-12 h-10 rounded border border-slate-warm-200 cursor-pointer" />
                    <input value={localConfig.headerBg} onChange={e => setLocalConfig({ ...localConfig, headerBg: e.target.value })}
                      className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Text Color</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={localConfig.headerText} onChange={e => setLocalConfig({ ...localConfig, headerText: e.target.value })}
                      className="w-12 h-10 rounded border border-slate-warm-200 cursor-pointer" />
                    <input value={localConfig.headerText} onChange={e => setLocalConfig({ ...localConfig, headerText: e.target.value })}
                      className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono" />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Company Name (in header)</label>
                <input value={localConfig.companyName} onChange={e => setLocalConfig({ ...localConfig, companyName: e.target.value })}
                  className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
              </div>
              <div className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4">
                <p className="text-xs font-medium text-slate-warm-600 mb-2">Preview</p>
                <div style={{ backgroundColor: localConfig.headerBg, color: localConfig.headerText }} className="px-4 py-3 rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded" style={{ backgroundColor: localConfig.primaryColor }} />
                    <span className="font-semibold text-sm">{localConfig.companyName}</span>
                  </div>
                  <div className="hidden sm:flex gap-3 text-xs">
                    <span>Home</span><span>Products</span><span>About</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === 'footer' && (
            <div className="space-y-5 max-w-2xl">
              <p className="text-sm text-slate-warm-600">Customize your site footer. This appears at the bottom of every page.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Background Color</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={localConfig.footerBg} onChange={e => setLocalConfig({ ...localConfig, footerBg: e.target.value })}
                      className="w-12 h-10 rounded border border-slate-warm-200 cursor-pointer" />
                    <input value={localConfig.footerBg} onChange={e => setLocalConfig({ ...localConfig, footerBg: e.target.value })}
                      className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Text Color</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={localConfig.footerText} onChange={e => setLocalConfig({ ...localConfig, footerText: e.target.value })}
                      className="w-12 h-10 rounded border border-slate-warm-200 cursor-pointer" />
                    <input value={localConfig.footerText} onChange={e => setLocalConfig({ ...localConfig, footerText: e.target.value })}
                      className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono" />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Contact Email</label>
                  <input value={localConfig.contactEmail} onChange={e => setLocalConfig({ ...localConfig, contactEmail: e.target.value })}
                    className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Contact Phone</label>
                  <input value={localConfig.contactPhone} onChange={e => setLocalConfig({ ...localConfig, contactPhone: e.target.value })}
                    className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
                </div>
              </div>
              <div className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4">
                <p className="text-xs font-medium text-slate-warm-600 mb-2">Preview</p>
                <div style={{ backgroundColor: localConfig.footerBg, color: localConfig.footerText }} className="px-4 py-3 rounded-lg text-xs">
                  <div className="flex justify-between">
                    <div>
                      <p className="font-semibold">{localConfig.companyName}</p>
                      <p>{localConfig.contactEmail}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">Quick Links</p>
                      <p>Products • Contact</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === 'branding' && (
            <div className="space-y-5 max-w-2xl">
              <p className="text-sm text-slate-warm-600">Define your brand colors and visual identity across your subdomain site.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Primary Color</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={localConfig.primaryColor} onChange={e => setLocalConfig({ ...localConfig, primaryColor: e.target.value })}
                      className="w-12 h-10 rounded border border-slate-warm-200 cursor-pointer" />
                    <input value={localConfig.primaryColor} onChange={e => setLocalConfig({ ...localConfig, primaryColor: e.target.value })}
                      className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Accent Color</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={localConfig.accentColor} onChange={e => setLocalConfig({ ...localConfig, accentColor: e.target.value })}
                      className="w-12 h-10 rounded border border-slate-warm-200 cursor-pointer" />
                    <input value={localConfig.accentColor} onChange={e => setLocalConfig({ ...localConfig, accentColor: e.target.value })}
                      className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono" />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Tagline</label>
                <input value={localConfig.tagline} onChange={e => setLocalConfig({ ...localConfig, tagline: e.target.value })}
                  className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" />
              </div>
              <div className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4">
                <p className="text-xs font-medium text-slate-warm-600 mb-3">Color Preview</p>
                <div className="flex gap-2">
                  <div className="flex-1 h-16 rounded-lg flex items-center justify-center text-white text-xs font-medium" style={{ backgroundColor: localConfig.primaryColor }}>Primary</div>
                  <div className="flex-1 h-16 rounded-lg flex items-center justify-center text-white text-xs font-medium" style={{ backgroundColor: localConfig.accentColor }}>Accent</div>
                </div>
                <div className="mt-3 flex gap-2">
                  <button className="px-4 py-2 rounded-lg text-sm font-medium text-white" style={{ backgroundColor: localConfig.primaryColor }}>Primary Button</button>
                  <button className="px-4 py-2 rounded-lg text-sm font-medium border-2" style={{ borderColor: localConfig.primaryColor, color: localConfig.primaryColor }}>Secondary Button</button>
                </div>
              </div>
            </div>
          )}

          {tab === 'settings' && (
            <div className="space-y-5 max-w-2xl">
              <p className="text-sm text-slate-warm-600">Configure which sections appear on your public subdomain site.</p>
              <div className="space-y-3">
                {[
                  { key: 'showProductCatalog', label: 'Product Catalog', desc: 'Display your product listings on the site' },
                  { key: 'showCertifications', label: 'Certifications', desc: 'Show your verified certifications' },
                  { key: 'showContactForm', label: 'Contact Form', desc: 'Allow visitors to send inquiries' },
                ].map(item => (
                  <label key={item.key} className="flex items-start gap-3 p-4 bg-slate-warm-50 border border-slate-warm-200 rounded-xl cursor-pointer hover:bg-warm-50 transition-colors">
                    <input
                      type="checkbox"
                      checked={(localConfig as any)[item.key]}
                      onChange={e => setLocalConfig({ ...localConfig, [item.key]: e.target.checked } as any)}
                      className="mt-0.5 w-4 h-4 rounded border-slate-warm-300 text-warm-600 focus:ring-warm-500"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-warm-800">{item.label}</p>
                      <p className="text-xs text-slate-warm-500 mt-0.5">{item.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Social Links</label>
                <div className="space-y-2">
                  {localConfig.socialLinks.map((link, idx) => (
                    <div key={idx} className="flex gap-2">
                      <input value={link.platform} readOnly className="w-32 px-3 py-2 bg-slate-warm-100 border border-slate-warm-200 rounded-lg text-sm" />
                      <input value={link.url} onChange={e => {
                        const newLinks = [...localConfig.socialLinks];
                        newLinks[idx] = { ...newLinks[idx], url: e.target.value };
                        setLocalConfig({ ...localConfig, socialLinks: newLinks });
                      }} className="flex-1 px-3 py-2 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
