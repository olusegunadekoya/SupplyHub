import React, { useState } from 'react';
import { useApp, Product } from '../context/AppContext';
import { Plus, Search, Filter, Grid, List, Eye, Edit3, Trash2, MoreVertical, CheckCircle, Clock, FileText, X } from 'lucide-react';

export default function Products() {
  const { products, addProduct, deleteProduct } = useApp();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || p.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900">Products & Services</h1>
          <p className="text-sm text-slate-warm-500 mt-1">Manage your product catalog and service offerings</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm"
        >
          <Plus className="w-4 h-4" /> Add Product
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-warm-400" />
          <input
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 transition-all"
          />
        </div>
        <select
          value={filterStatus}
          onChange={e => setFilterStatus(e.target.value)}
          className="px-4 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm text-slate-warm-700 focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400"
        >
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="under_review">Under Review</option>
          <option value="draft">Draft</option>
        </select>
        <div className="flex bg-white border border-slate-warm-200 rounded-lg overflow-hidden">
          <button
            onClick={() => setViewMode('grid')}
            className={`px-3 py-2.5 ${viewMode === 'grid' ? 'bg-warm-50 text-warm-700' : 'text-slate-warm-500 hover:bg-slate-warm-50'}`}
          >
            <Grid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-2.5 ${viewMode === 'list' ? 'bg-warm-50 text-warm-700' : 'text-slate-warm-500 hover:bg-slate-warm-50'}`}
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Products Grid */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredProducts.map(product => (
            <div key={product.id} className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden hover:shadow-md hover:border-warm-300 transition-all duration-200 group">
              {/* Product image placeholder */}
              <div className="h-40 bg-gradient-to-br from-slate-warm-100 to-slate-warm-50 flex items-center justify-center relative">
                <Package className="w-12 h-12 text-slate-warm-300" />
                <span className={`absolute top-3 right-3 inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                  product.status === 'active' ? 'bg-emerald-100 text-emerald-700' :
                  product.status === 'under_review' ? 'bg-amber-100 text-amber-700' :
                  'bg-slate-warm-100 text-slate-warm-600'
                }`}>
                  {product.status === 'active' ? 'Active' : product.status === 'under_review' ? 'Review' : 'Draft'}
                </span>
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-slate-warm-800 text-sm group-hover:text-warm-700 transition-colors">{product.name}</h3>
                <p className="text-xs text-slate-warm-500 mt-1">{product.category}</p>
                <p className="text-xs text-slate-warm-500 mt-2 line-clamp-2">{product.description}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-sm font-semibold text-warm-700">{product.price}</span>
                  <span className="text-xs text-slate-warm-400">MOQ: {product.minOrderQuantity}</span>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-warm-100 flex items-center gap-2">
                  <button onClick={() => setSelectedProduct(product)} className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-warm-600 hover:text-warm-700 hover:bg-warm-50 rounded-lg transition-colors">
                    <Eye className="w-3.5 h-3.5" /> View
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-warm-600 hover:text-warm-700 hover:bg-warm-50 rounded-lg transition-colors">
                    <Edit3 className="w-3.5 h-3.5" /> Edit
                  </button>
                  <button onClick={() => deleteProduct(product.id)} className="flex items-center justify-center px-3 py-1.5 text-xs font-medium text-red-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-warm-100 bg-slate-warm-50">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider">Product</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider hidden md:table-cell">Category</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider hidden lg:table-cell">Price</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider">Status</th>
                  <th className="text-right px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-warm-100">
                {filteredProducts.map(product => (
                  <tr key={product.id} className="hover:bg-slate-warm-50 transition-colors">
                    <td className="px-5 py-4">
                      <div>
                        <p className="text-sm font-medium text-slate-warm-800">{product.name}</p>
                        <p className="text-xs text-slate-warm-500 mt-0.5 md:hidden">{product.category}</p>
                      </div>
                    </td>
                    <td className="px-5 py-4 hidden md:table-cell">
                      <span className="text-sm text-slate-warm-600">{product.category}</span>
                    </td>
                    <td className="px-5 py-4 hidden lg:table-cell">
                      <span className="text-sm font-medium text-slate-warm-800">{product.price}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                        product.status === 'active' ? 'bg-emerald-50 text-emerald-700' :
                        product.status === 'under_review' ? 'bg-amber-50 text-amber-700' :
                        'bg-slate-warm-100 text-slate-warm-600'
                      }`}>
                        {product.status === 'active' ? 'Active' : product.status === 'under_review' ? 'Review' : 'Draft'}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => setSelectedProduct(product)} className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteProduct(product.id)} className="p-2 text-slate-warm-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {filteredProducts.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl border border-slate-warm-200">
          <Package className="w-12 h-12 text-slate-warm-300 mx-auto mb-3" />
          <p className="text-slate-warm-600 font-medium">No products found</p>
          <p className="text-sm text-slate-warm-400 mt-1">Try adjusting your search or filters</p>
        </div>
      )}

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductDetailModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />
      )}

      {/* Add Product Modal */}
      {showAddModal && <AddProductModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
}

function Package({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16.5 9.4l-9-5.19M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z" />
      <path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12" />
    </svg>
  );
}

function ProductDetailModal({ product, onClose }: { product: Product; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl">
          <h2 className="text-lg font-semibold text-slate-warm-900">Product Details</h2>
          <button onClick={onClose} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-6">
          <div>
            <h3 className="text-xl font-bold text-slate-warm-900">{product.name}</h3>
            <p className="text-sm text-slate-warm-500 mt-1">{product.category}</p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-warm-700 mb-2">Description</h4>
            <p className="text-sm text-slate-warm-600 leading-relaxed">{product.description}</p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-warm-700 mb-2">Characteristics</h4>
            <div className="flex flex-wrap gap-2">
              {product.characteristics.map((char, idx) => (
                <span key={idx} className="px-3 py-1.5 bg-warm-50 text-warm-700 rounded-lg text-xs font-medium border border-warm-200">
                  {char}
                </span>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-warm-700 mb-2">Specifications</h4>
            <div className="bg-slate-warm-50 rounded-lg border border-slate-warm-200 overflow-hidden">
              <table className="w-full">
                <tbody>
                  {Object.entries(product.specifications).map(([key, value], idx) => (
                    <tr key={key} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-warm-50'}>
                      <td className="px-4 py-2.5 text-xs font-medium text-slate-warm-600 w-1/3">{key}</td>
                      <td className="px-4 py-2.5 text-xs text-slate-warm-800">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-warm-50 rounded-lg p-3 border border-warm-200">
              <p className="text-xs text-warm-600 font-medium">Price</p>
              <p className="text-sm font-bold text-warm-800 mt-0.5">{product.price}</p>
            </div>
            <div className="bg-warm-50 rounded-lg p-3 border border-warm-200">
              <p className="text-xs text-warm-600 font-medium">Min. Order</p>
              <p className="text-sm font-bold text-warm-800 mt-0.5">{product.minOrderQuantity}</p>
            </div>
            <div className="bg-warm-50 rounded-lg p-3 border border-warm-200">
              <p className="text-xs text-warm-600 font-medium">Lead Time</p>
              <p className="text-sm font-bold text-warm-800 mt-0.5">{product.leadTime}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AddProductModal({ onClose }: { onClose: () => void }) {
  const { addProduct } = useApp();
  const [formData, setFormData] = useState({
    name: '', category: '', description: '', price: '', minOrderQuantity: '', leadTime: '',
    characteristics: '', specifications: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const specs: Record<string, string> = {};
    formData.specifications.split('\n').forEach(line => {
      const [key, ...vals] = line.split(':');
      if (key && vals.length) specs[key.trim()] = vals.join(':').trim();
    });
    addProduct({
      id: Date.now().toString(),
      name: formData.name,
      category: formData.category,
      description: formData.description,
      characteristics: formData.characteristics.split(',').map(c => c.trim()).filter(Boolean),
      specifications: specs,
      price: formData.price,
      minOrderQuantity: formData.minOrderQuantity,
      leadTime: formData.leadTime,
      images: [],
      status: 'under_review',
      createdAt: new Date().toISOString().split('T')[0],
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="text-lg font-semibold text-slate-warm-900">Add New Product</h2>
          <button onClick={onClose} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Product Name *</label>
              <input required value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., Industrial Steel Bearings" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Category *</label>
              <select required value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400">
                <option value="">Select category</option>
                <option>Mechanical Components</option>
                <option>Electrical Components</option>
                <option>Raw Materials</option>
                <option>Manufacturing Services</option>
                <option>Sealing Solutions</option>
                <option>Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Price *</label>
              <input required value={formData.price} onChange={e => setFormData({ ...formData, price: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., €12.50/unit" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Min. Order Quantity *</label>
              <input required value={formData.minOrderQuantity} onChange={e => setFormData({ ...formData, minOrderQuantity: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., 100 units" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Lead Time *</label>
              <input required value={formData.leadTime} onChange={e => setFormData({ ...formData, leadTime: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., 2-3 weeks" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Description *</label>
              <textarea required rows={3} value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none" placeholder="Describe your product or service..." />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Characteristics <span className="text-slate-warm-400 font-normal">(comma-separated)</span></label>
              <input value={formData.characteristics} onChange={e => setFormData({ ...formData, characteristics: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400" placeholder="e.g., High durability, Corrosion resistant, Lightweight" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-warm-700 mb-1.5">Specifications <span className="text-slate-warm-400 font-normal">(one per line, format: Key: Value)</span></label>
              <textarea rows={4} value={formData.specifications} onChange={e => setFormData({ ...formData, specifications: e.target.value })}
                className="w-full px-3 py-2.5 bg-white border border-slate-warm-200 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-warm-500/20 focus:border-warm-400 resize-none" placeholder={"Material: Chrome Steel\nWeight: 0.5 kg\nDimensions: 50x30x20mm"} />
            </div>
          </div>
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-warm-100">
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-slate-warm-600 hover:text-slate-warm-800 hover:bg-slate-warm-50 rounded-lg transition-colors">Cancel</button>
            <button type="submit" className="px-5 py-2.5 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">Submit for Review</button>
          </div>
        </form>
      </div>
    </div>
  );
}
