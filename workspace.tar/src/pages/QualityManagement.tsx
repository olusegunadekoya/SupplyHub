import React, { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/database';
import { QualityAPI, getCurrentSupplierId } from '../services/api';
import {
  Shield, TrendingUp, TrendingDown, Minus, AlertTriangle, CheckCircle,
  Clock, FileText, ClipboardList, Target, Award, Calendar, Plus,
  Eye, Edit3, X, Save, Filter, Search, AlertCircle, Activity,
  BarChart3, PieChart as PieIcon, FileCheck, Upload, Download
} from 'lucide-react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, RadarChart, Radar,
  PolarGrid, PolarAngleAxis, PolarRadiusAxis, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';

export default function QualityManagement() {
  const [tab, setTab] = useState<'overview' | 'inspections' | 'ncr' | 'capa' | 'scorecards' | 'documents'>('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'inspections', label: 'Inspections', icon: ClipboardList },
    { id: 'ncr', label: 'NCR Reports', icon: AlertTriangle },
    { id: 'capa', label: 'CAPA', icon: Target },
    { id: 'scorecards', label: 'Scorecards', icon: Award },
    { id: 'documents', label: 'Documents', icon: FileCheck },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-warm-900 flex items-center gap-2">
            <Shield className="w-7 h-7 text-warm-600" />
            Quality Assurance
          </h1>
          <p className="text-sm text-slate-warm-500 mt-1">Manage quality metrics, inspections, NCRs, CAPAs, and compliance</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="flex border-b border-slate-warm-100 overflow-x-auto">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id as any)}
              className={`flex items-center gap-2 px-4 lg:px-5 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                tab === t.id ? 'border-warm-600 text-warm-700 bg-warm-50/50' : 'border-transparent text-slate-warm-500 hover:text-slate-warm-700'
              }`}>
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
        <div className="p-4 lg:p-6">
          {tab === 'overview' && <OverviewTab />}
          {tab === 'inspections' && <InspectionsTab />}
          {tab === 'ncr' && <NCRTab />}
          {tab === 'capa' && <CAPATab />}
          {tab === 'scorecards' && <ScorecardsTab />}
          {tab === 'documents' && <DocumentsTab />}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// OVERVIEW TAB
// ============================================================================
function OverviewTab() {
  const supplierId = getCurrentSupplierId();
  const summary = useLiveQuery(() => QualityAPI.getQualitySummary(), []);
  const metrics = useLiveQuery(() => QualityAPI.getMetrics('monthly', 12), []);

  if (!summary) return <div className="text-center py-12 text-slate-warm-500">Loading quality data...</div>;

  const latest = summary.latestMetrics;
  const trendData = metrics ? [...metrics].reverse().map(m => ({
    period: m.period.slice(5),
    defectRate: +m.defectRate.toFixed(2),
    onTimeDelivery: +m.onTimeDelivery.toFixed(1),
    overallScore: +m.overallScore.toFixed(1),
    firstPassYield: +m.firstPassYield.toFixed(1),
  })) : [];

  const kpis = [
    { label: 'Overall Quality Score', value: latest?.overallScore?.toFixed(1) || '—', unit: '/100', icon: Award, color: 'from-emerald-500 to-emerald-600', trend: 'up' },
    { label: 'Defect Rate', value: latest?.defectRate?.toFixed(2) || '—', unit: '%', icon: AlertTriangle, color: 'from-amber-500 to-amber-600', trend: 'down' },
    { label: 'On-Time Delivery', value: latest?.onTimeDelivery?.toFixed(1) || '—', unit: '%', icon: Clock, color: 'from-blue-500 to-blue-600', trend: 'up' },
    { label: 'First Pass Yield', value: latest?.firstPassYield?.toFixed(1) || '—', unit: '%', icon: CheckCircle, color: 'from-purple-500 to-purple-600', trend: 'up' },
  ];

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, idx) => (
          <div key={idx} className="bg-white rounded-xl border border-slate-warm-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${kpi.color} flex items-center justify-center`}>
                <kpi.icon className="w-5 h-5 text-white" />
              </div>
              <span className="flex items-center gap-1 text-xs font-medium text-emerald-600">
                <TrendingUp className="w-3 h-3" /> +2.3%
              </span>
            </div>
            <p className="text-2xl font-bold text-slate-warm-900">{kpi.value}<span className="text-sm font-normal text-slate-warm-500 ml-1">{kpi.unit}</span></p>
            <p className="text-xs text-slate-warm-500 mt-1">{kpi.label}</p>
          </div>
        ))}
      </div>

      {/* Status Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <p className="text-xs text-blue-600 font-medium">Open NCRs</p>
          <p className="text-2xl font-bold text-blue-800 mt-1">{summary.openNCRs}</p>
          <p className="text-xs text-blue-500 mt-0.5">of {summary.totalNCRs} total</p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
          <p className="text-xs text-amber-600 font-medium">Open CAPAs</p>
          <p className="text-2xl font-bold text-amber-800 mt-1">{summary.openCAPAs}</p>
          <p className="text-xs text-amber-500 mt-0.5">{summary.overdueCAPAs} overdue</p>
        </div>
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
          <p className="text-xs text-emerald-600 font-medium">Completed Inspections</p>
          <p className="text-2xl font-bold text-emerald-800 mt-1">{summary.completedInspections}</p>
          <p className="text-xs text-emerald-500 mt-0.5">{summary.scheduledInspections} scheduled</p>
        </div>
        <div className="bg-warm-50 border border-warm-200 rounded-xl p-4">
          <p className="text-xs text-warm-600 font-medium">Latest Grade</p>
          <p className="text-2xl font-bold text-warm-800 mt-1">{summary.latestScorecard?.grade || '—'}</p>
          <p className="text-xs text-warm-500 mt-0.5">{summary.latestScorecard?.period || '—'}</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quality Trend */}
        <div className="bg-white rounded-xl border border-slate-warm-200 p-5">
          <h3 className="text-sm font-semibold text-slate-warm-800 mb-4">Quality Score Trend (12 months)</h3>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#c06d23" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#c06d23" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
              <XAxis dataKey="period" tick={{ fontSize: 11 }} stroke="#999" />
              <YAxis domain={[70, 100]} tick={{ fontSize: 11 }} stroke="#999" />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e5e1db', fontSize: '12px' }} />
              <Area type="monotone" dataKey="overallScore" stroke="#c06d23" fillOpacity={1} fill="url(#colorScore)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Delivery & Defect Trend */}
        <div className="bg-white rounded-xl border border-slate-warm-200 p-5">
          <h3 className="text-sm font-semibold text-slate-warm-800 mb-4">Delivery & Defect Rate</h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
              <XAxis dataKey="period" tick={{ fontSize: 11 }} stroke="#999" />
              <YAxis tick={{ fontSize: 11 }} stroke="#999" />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e5e1db', fontSize: '12px' }} />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Line type="monotone" dataKey="onTimeDelivery" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} name="On-Time %" />
              <Line type="monotone" dataKey="defectRate" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} name="Defect %" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Latest Scorecard Radar */}
      {summary.latestScorecard && (
        <div className="bg-white rounded-xl border border-slate-warm-200 p-5">
          <h3 className="text-sm font-semibold text-slate-warm-800 mb-4">Performance Radar - {summary.latestScorecard.period}</h3>
          <div className="flex flex-col lg:flex-row items-center gap-6">
            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={[
                { subject: 'Quality', value: summary.latestScorecard.qualityScore },
                { subject: 'Delivery', value: summary.latestScorecard.deliveryScore },
                { subject: 'Responsive', value: summary.latestScorecard.responsivenessScore },
                { subject: 'Compliance', value: summary.latestScorecard.complianceScore },
                { subject: 'Innovation', value: summary.latestScorecard.innovationScore },
              ]}>
                <PolarGrid stroke="#e5e1db" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
                <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fontSize: 10 }} />
                <Radar name="Score" dataKey="value" stroke="#c06d23" fill="#c06d23" fillOpacity={0.3} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
            <div className="lg:w-64 space-y-3">
              <div className="text-center lg:text-left">
                <p className="text-xs text-slate-warm-500">Overall Score</p>
                <p className="text-3xl font-bold text-slate-warm-900">{summary.latestScorecard.overallScore}<span className="text-sm text-slate-warm-500">/100</span></p>
                <span className={`inline-block px-3 py-1 rounded-full text-sm font-bold mt-1 ${
                  summary.latestScorecard.grade === 'A' ? 'bg-emerald-100 text-emerald-700' :
                  summary.latestScorecard.grade === 'B' ? 'bg-blue-100 text-blue-700' :
                  'bg-amber-100 text-amber-700'
                }`}>Grade {summary.latestScorecard.grade}</span>
              </div>
              <p className="text-xs text-slate-warm-500 italic">{summary.latestScorecard.comments}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// INSPECTIONS TAB
// ============================================================================
function InspectionsTab() {
  const supplierId = getCurrentSupplierId();
  const inspections = useLiveQuery(() => QualityAPI.getInspections(), []) || [];
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState<any>(null);

  const filtered = filter === 'all' ? inspections : inspections.filter(i => i.status === filter);

  const statusColors: Record<string, string> = {
    scheduled: 'bg-blue-50 text-blue-700 border-blue-200',
    in_progress: 'bg-amber-50 text-amber-700 border-amber-200',
    completed: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    cancelled: 'bg-slate-warm-100 text-slate-warm-600 border-slate-warm-200',
  };

  const conclusionColors: Record<string, string> = {
    pass: 'bg-emerald-100 text-emerald-700',
    conditional_pass: 'bg-amber-100 text-amber-700',
    fail: 'bg-red-100 text-red-700',
    pending: 'bg-slate-warm-100 text-slate-warm-600',
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          {['all', 'scheduled', 'in_progress', 'completed'].map(s => (
            <button key={s} onClick={() => setFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filter === s ? 'bg-warm-600 text-white' : 'bg-slate-warm-100 text-slate-warm-600 hover:bg-slate-warm-200'
              }`}>
              {s === 'all' ? 'All' : s.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </button>
          ))}
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
          <Plus className="w-4 h-4" /> Schedule Inspection
        </button>
      </div>

      <div className="space-y-3">
        {filtered.map(inspection => (
          <div key={inspection.inspectionId} onClick={() => setSelected(inspection)}
            className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors cursor-pointer">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-semibold text-slate-warm-800">{inspection.title}</h3>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${statusColors[inspection.status]}`}>
                    {inspection.status.replace('_', ' ')}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${conclusionColors[inspection.conclusion]}`}>
                    {inspection.conclusion.replace('_', ' ')}
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-warm-500">
                  <span className="capitalize">{inspection.type.replace('_', ' ')} Inspection</span>
                  <span>•</span>
                  <span>{inspection.inspector}</span>
                  <span>•</span>
                  <span>{new Date(inspection.scheduledDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </div>
              </div>
              <button className="p-2 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded-lg transition-colors">
                <Eye className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-warm-950/50 backdrop-blur-sm" onClick={() => setSelected(null)} />
          <div className="relative bg-white rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-fade-in">
            <div className="sticky top-0 bg-white border-b border-slate-warm-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
              <h2 className="text-lg font-semibold text-slate-warm-900">Inspection Details</h2>
              <button onClick={() => setSelected(null)} className="p-2 text-slate-warm-400 hover:text-slate-warm-600 hover:bg-slate-warm-50 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <h3 className="text-base font-semibold text-slate-warm-800">{selected.title}</h3>
                <p className="text-sm text-slate-warm-500 mt-1">{selected.scope}</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Type</p>
                  <p className="text-sm font-medium text-slate-warm-800 capitalize">{selected.type.replace('_', ' ')}</p>
                </div>
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Inspector</p>
                  <p className="text-sm font-medium text-slate-warm-800">{selected.inspector}</p>
                </div>
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Scheduled</p>
                  <p className="text-sm font-medium text-slate-warm-800">{new Date(selected.scheduledDate).toLocaleDateString()}</p>
                </div>
                <div className="bg-slate-warm-50 rounded-lg p-3">
                  <p className="text-xs text-slate-warm-500">Conclusion</p>
                  <p className={`text-sm font-medium capitalize ${
                    selected.conclusion === 'pass' ? 'text-emerald-600' :
                    selected.conclusion === 'fail' ? 'text-red-600' : 'text-amber-600'
                  }`}>{selected.conclusion.replace('_', ' ')}</p>
                </div>
              </div>
              {selected.notes && (
                <div>
                  <p className="text-xs font-medium text-slate-warm-600 mb-1">Notes</p>
                  <p className="text-sm text-slate-warm-700 bg-slate-warm-50 rounded-lg p-3">{selected.notes}</p>
                </div>
              )}
              {JSON.parse(selected.findings || '[]').length > 0 && (
                <div>
                  <p className="text-xs font-medium text-slate-warm-600 mb-2">Findings</p>
                  <div className="space-y-2">
                    {JSON.parse(selected.findings).map((f: any, i: number) => (
                      <div key={i} className="flex items-start gap-2 p-2 bg-slate-warm-50 rounded-lg">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          f.severity === 'pass' ? 'bg-emerald-100 text-emerald-700' :
                          f.severity === 'minor' ? 'bg-amber-100 text-amber-700' :
                          f.severity === 'major' ? 'bg-red-100 text-red-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>{f.severity}</span>
                        <div>
                          <p className="text-xs font-medium text-slate-warm-700">{f.area}</p>
                          <p className="text-xs text-slate-warm-500">{f.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// NCR TAB
// ============================================================================
function NCRTab() {
  const reports = useLiveQuery(() => QualityAPI.getNCRReports(), []) || [];
  const [filter, setFilter] = useState('all');
  const filtered = filter === 'all' ? reports : reports.filter(r => r.status === filter);

  const severityColors: Record<string, string> = {
    minor: 'bg-amber-50 text-amber-700 border-amber-200',
    major: 'bg-orange-50 text-orange-700 border-orange-200',
    critical: 'bg-red-50 text-red-700 border-red-200',
  };

  const statusColors: Record<string, string> = {
    open: 'bg-blue-50 text-blue-700',
    investigating: 'bg-amber-50 text-amber-700',
    corrective_action: 'bg-purple-50 text-purple-700',
    verification: 'bg-indigo-50 text-indigo-700',
    closed: 'bg-emerald-50 text-emerald-700',
  };

  // Severity distribution for pie chart
  const severityData = [
    { name: 'Minor', value: reports.filter(r => r.severity === 'minor').length, color: '#f59e0b' },
    { name: 'Major', value: reports.filter(r => r.severity === 'major').length, color: '#f97316' },
    { name: 'Critical', value: reports.filter(r => r.severity === 'critical').length, color: '#ef4444' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          {['all', 'open', 'investigating', 'corrective_action', 'closed'].map(s => (
            <button key={s} onClick={() => setFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filter === s ? 'bg-warm-600 text-white' : 'bg-slate-warm-100 text-slate-warm-600 hover:bg-slate-warm-200'
              }`}>
              {s === 'all' ? 'All' : s.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </button>
          ))}
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
          <Plus className="w-4 h-4" /> New NCR
        </button>
      </div>

      {/* Severity Distribution */}
      {severityData.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-warm-200 p-4">
          <h3 className="text-sm font-semibold text-slate-warm-800 mb-3">NCR Severity Distribution</h3>
          <div className="flex items-center gap-6">
            <ResponsiveContainer width={120} height={120}>
              <PieChart>
                <Pie data={severityData} cx="50%" cy="50%" innerRadius={30} outerRadius={50} dataKey="value">
                  {severityData.map((entry, idx) => <Cell key={idx} fill={entry.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex gap-4">
              {severityData.map(d => (
                <div key={d.name} className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded" style={{ backgroundColor: d.color }} />
                  <span className="text-xs text-slate-warm-600">{d.name}: <strong>{d.value}</strong></span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {filtered.map(report => (
          <div key={report.ncrId} className="bg-slate-warm-50 border border-slate-warm-200 rounded-xl p-4 hover:border-warm-300 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-start gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <code className="text-xs font-mono text-warm-700 bg-warm-50 px-2 py-0.5 rounded border border-warm-200">{report.ncrNumber}</code>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium border ${severityColors[report.severity]}`}>{report.severity}</span>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusColors[report.status]}`}>
                    {report.status.replace('_', ' ')}
                  </span>
                </div>
                <h3 className="text-sm font-semibold text-slate-warm-800 mt-1.5">{report.title}</h3>
                <p className="text-xs text-slate-warm-500 mt-1 line-clamp-2">{report.description}</p>
                <div className="flex items-center gap-3 mt-2 text-xs text-slate-warm-500">
                  <span>Reported by: {report.reportedBy}</span>
                  <span>•</span>
                  <span>{new Date(report.reportedDate).toLocaleDateString()}</span>
                  <span>•</span>
                  <span>Due: {new Date(report.dueDate).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// CAPA TAB
// ============================================================================
function CAPATab() {
  const actions = useLiveQuery(() => QualityAPI.getCAPAActions(), []) || [];
  const [filter, setFilter] = useState('all');
  const filtered = filter === 'all' ? actions : actions.filter(a => a.status === filter);

  const priorityColors: Record<string, string> = {
    low: 'bg-slate-warm-100 text-slate-warm-600',
    medium: 'bg-blue-50 text-blue-700',
    high: 'bg-amber-50 text-amber-700',
    critical: 'bg-red-50 text-red-700',
  };

  const statusColors: Record<string, string> = {
    open: 'bg-blue-50 text-blue-700',
    in_progress: 'bg-amber-50 text-amber-700',
    completed: 'bg-emerald-50 text-emerald-700',
    verified: 'bg-indigo-50 text-indigo-700',
    closed: 'bg-slate-warm-100 text-slate-warm-600',
    overdue: 'bg-red-50 text-red-700',
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          {['all', 'open', 'in_progress', 'completed', 'verified'].map(s => (
            <button key={s} onClick={() => setFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filter === s ? 'bg-warm-600 text-white' : 'bg-slate-warm-100 text-slate-warm-600 hover:bg-slate-warm-200'
              }`}>
              {s === 'all' ? 'All' : s.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </button>
          ))}
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
          <Plus className="w-4 h-4" /> New CAPA
        </button>
      </div>

      <div className="space-y-3">
        {filtered.map(action => {
          const isOverdue = !['closed', 'verified', 'completed'].includes(action.status) && new Date(action.dueDate) < new Date();
          return (
            <div key={action.capaId} className={`bg-slate-warm-50 border rounded-xl p-4 hover:shadow-sm transition-all ${isOverdue ? 'border-red-200 bg-red-50/30' : 'border-slate-warm-200 hover:border-warm-300'}`}>
              <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <code className="text-xs font-mono text-warm-700 bg-warm-50 px-2 py-0.5 rounded border border-warm-200">{action.capaNumber}</code>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${priorityColors[action.priority]}`}>{action.priority}</span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusColors[isOverdue ? 'overdue' : action.status]}`}>
                      {isOverdue ? 'Overdue' : action.status.replace('_', ' ')}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${action.type === 'corrective' ? 'bg-orange-50 text-orange-700' : 'bg-emerald-50 text-emerald-700'}`}>
                      {action.type}
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold text-slate-warm-800 mt-1.5">{action.title}</h3>
                  <p className="text-xs text-slate-warm-500 mt-1 line-clamp-2">{action.description}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-slate-warm-500">
                    <span>Assigned: {action.assignedTo}</span>
                    <span>•</span>
                    <span>Due: {new Date(action.dueDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================================
// SCORECARDS TAB
// ============================================================================
function ScorecardsTab() {
  const scorecards = useLiveQuery(() => QualityAPI.getScorecards(), []) || [];

  const gradeColors: Record<string, string> = {
    A: 'bg-emerald-100 text-emerald-700 border-emerald-300',
    B: 'bg-blue-100 text-blue-700 border-blue-300',
    C: 'bg-amber-100 text-amber-700 border-amber-300',
    D: 'bg-orange-100 text-orange-700 border-orange-300',
    F: 'bg-red-100 text-red-700 border-red-300',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-warm-600">Periodic performance evaluations based on quality, delivery, compliance, and innovation metrics.</p>
      </div>

      <div className="space-y-4">
        {scorecards.map(sc => (
          <div key={sc.scorecardId} className="bg-white border border-slate-warm-200 rounded-xl p-5 hover:shadow-md transition-shadow">
            <div className="flex flex-col lg:flex-row lg:items-center gap-4">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-xl border-2 flex items-center justify-center ${gradeColors[sc.grade]}`}>
                  <span className="text-2xl font-bold">{sc.grade}</span>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-slate-warm-800">Scorecard - {sc.period}</h3>
                  <p className="text-xs text-slate-warm-500 mt-0.5">Issued {new Date(sc.issuedAt).toLocaleDateString()} by {sc.issuedBy}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-xs font-medium flex items-center gap-1 ${
                      sc.trend === 'improving' ? 'text-emerald-600' :
                      sc.trend === 'declining' ? 'text-red-600' : 'text-slate-warm-500'
                    }`}>
                      {sc.trend === 'improving' && <TrendingUp className="w-3 h-3" />}
                      {sc.trend === 'declining' && <TrendingDown className="w-3 h-3" />}
                      {sc.trend === 'stable' && <Minus className="w-3 h-3" />}
                      {sc.trend}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex-1 grid grid-cols-2 sm:grid-cols-5 gap-3">
                {[
                  { label: 'Quality', value: sc.qualityScore },
                  { label: 'Delivery', value: sc.deliveryScore },
                  { label: 'Responsive', value: sc.responsivenessScore },
                  { label: 'Compliance', value: sc.complianceScore },
                  { label: 'Innovation', value: sc.innovationScore },
                ].map((item, idx) => (
                  <div key={idx} className="text-center">
                    <p className="text-lg font-bold text-slate-warm-800">{item.value}</p>
                    <p className="text-[10px] text-slate-warm-500">{item.label}</p>
                    <div className="w-full bg-slate-warm-100 rounded-full h-1.5 mt-1">
                      <div className={`h-1.5 rounded-full ${item.value >= 90 ? 'bg-emerald-500' : item.value >= 80 ? 'bg-blue-500' : 'bg-amber-500'}`} style={{ width: `${item.value}%` }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="text-center lg:text-right">
                <p className="text-3xl font-bold text-warm-700">{sc.overallScore}</p>
                <p className="text-xs text-slate-warm-500">Overall</p>
              </div>
            </div>
            {sc.comments && <p className="text-xs text-slate-warm-500 mt-3 pt-3 border-t border-slate-warm-100 italic">{sc.comments}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// DOCUMENTS TAB
// ============================================================================
function DocumentsTab() {
  const docs = useLiveQuery(() => QualityAPI.getQualityDocuments(), []) || [];
  const [filter, setFilter] = useState('all');
  const filtered = filter === 'all' ? docs : docs.filter(d => d.status === filter);

  const statusColors: Record<string, string> = {
    draft: 'bg-slate-warm-100 text-slate-warm-600',
    under_review: 'bg-amber-50 text-amber-700',
    approved: 'bg-emerald-50 text-emerald-700',
    obsolete: 'bg-red-50 text-red-700',
  };

  const typeIcons: Record<string, string> = {
    procedure: '📋',
    work_instruction: '🔧',
    form: '📝',
    specification: '📐',
    record: '📊',
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          {['all', 'approved', 'under_review', 'draft', 'obsolete'].map(s => (
            <button key={s} onClick={() => setFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filter === s ? 'bg-warm-600 text-white' : 'bg-slate-warm-100 text-slate-warm-600 hover:bg-slate-warm-200'
              }`}>
              {s === 'all' ? 'All' : s.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </button>
          ))}
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-warm-600 to-warm-700 text-white rounded-lg text-sm font-medium hover:from-warm-700 hover:to-warm-800 transition-all shadow-sm">
          <Upload className="w-4 h-4" /> Upload Document
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-warm-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-warm-100 bg-slate-warm-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase">Document</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase hidden md:table-cell">Type</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase hidden lg:table-cell">Revision</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase">Status</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase hidden lg:table-cell">Next Review</th>
                <th className="text-right px-5 py-3 text-xs font-semibold text-slate-warm-600 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-warm-100">
              {filtered.map(doc => (
                <tr key={doc.docId} className="hover:bg-slate-warm-50 transition-colors">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{typeIcons[doc.type] || '📄'}</span>
                      <div>
                        <p className="text-sm font-medium text-slate-warm-800">{doc.title}</p>
                        <p className="text-xs text-slate-warm-500 font-mono">{doc.docNumber}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 hidden md:table-cell">
                    <span className="text-xs text-slate-warm-600 capitalize">{doc.type.replace('_', ' ')}</span>
                  </td>
                  <td className="px-5 py-3 hidden lg:table-cell">
                    <span className="text-xs font-mono text-slate-warm-700">{doc.revision}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusColors[doc.status]}`}>
                      {doc.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-5 py-3 hidden lg:table-cell">
                    <span className="text-xs text-slate-warm-500">{new Date(doc.nextReviewDate).toLocaleDateString()}</span>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button className="p-1.5 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded transition-colors">
                        <Download className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 text-slate-warm-400 hover:text-warm-600 hover:bg-warm-50 rounded transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
