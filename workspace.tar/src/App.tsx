import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { seedDatabase } from './db/seed';
import { setCurrentSupplier } from './services/api';
import Layout from './components/Layout';
import ServerStatus from './components/ServerStatus';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import Certifications from './pages/Certifications';
import Messages from './pages/Messages';
import Profile from './pages/Profile';
import Registration from './pages/Registration';
import SiteBuilder from './pages/SiteBuilder';
import ContentManager from './pages/ContentManager';
import EmailService from './pages/EmailService';
import ControlPanel from './pages/ControlPanel';
import DatabaseView from './pages/DatabaseView';
import QualityManagement from './pages/QualityManagement';
import ManpowerSourcing from './pages/ManpowerSourcing';
import DevelopmentManual from './pages/DevelopmentManual';

function AppContent() {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      try {
        console.log('[APP] Initializing database...');
        await seedDatabase();
        console.log('[APP] Database ready');
        
        // Set current supplier context (in real app, this comes from auth)
        setCurrentSupplier('sup-mueller-001');
        console.log('[APP] Tenant context set: mueller-components');
        
        setReady(true);
      } catch (err) {
        console.error('[APP] Initialization failed:', err);
        setError('Failed to initialize database. Please refresh the page.');
      }
    };
    init();
  }, []);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cream-50 p-4">
        <div className="bg-white rounded-2xl border border-red-200 p-8 max-w-md text-center">
          <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold text-slate-warm-900 mb-2">Initialization Error</h1>
          <p className="text-sm text-slate-warm-600 mb-4">{error}</p>
          <button onClick={() => window.location.reload()} className="px-4 py-2 bg-warm-600 text-white rounded-lg text-sm font-medium hover:bg-warm-700 transition-colors">
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cream-50">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-warm-100 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <svg className="w-8 h-8 text-warm-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
            </svg>
          </div>
          <p className="text-sm font-medium text-slate-warm-700">Initializing database...</p>
          <p className="text-xs text-slate-warm-500 mt-1">Setting up tables and seeding data</p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/products" element={<Products />} />
          <Route path="/certifications" element={<Certifications />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/site-builder" element={<SiteBuilder />} />
          <Route path="/content" element={<ContentManager />} />
          <Route path="/email" element={<EmailService />} />
          <Route path="/control-panel" element={<ControlPanel />} />
          <Route path="/database" element={<DatabaseView />} />
          <Route path="/quality" element={<QualityManagement />} />
          <Route path="/manpower" element={<ManpowerSourcing />} />
          <Route path="/manual" element={<DevelopmentManual />} />
        </Route>
      </Routes>
      <ServerStatus />
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
