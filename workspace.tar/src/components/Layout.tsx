import React, { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard, Package, FileCheck, MessageSquare,
  UserCircle, Menu, X, ChevronRight, Bell, Settings,
  Globe, FileText, Mail, ShieldCheck, ExternalLink, Database, Shield,
  Users, BookOpen
} from 'lucide-react';

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { messages, siteConfig } = useApp();
  const location = useLocation();
  const unreadCount = messages.filter(m => !m.read).length;
  const subdomain = 'mueller-components';

  const navItems = [
    { to: '/', icon: LayoutDashboard, label: 'Dashboard', section: 'Overview' },
    { to: '/products', icon: Package, label: 'Products & Services', section: 'Overview' },
    { to: '/quality', icon: Shield, label: 'Quality Assurance', section: 'Overview' },
    { to: '/manpower', icon: Users, label: 'Manpower Sourcing', section: 'Overview' },
    { to: '/certifications', icon: FileCheck, label: 'Certifications', section: 'Overview' },
    { to: '/messages', icon: MessageSquare, label: 'Messages', section: 'Overview', badge: unreadCount },
    { to: '/profile', icon: UserCircle, label: 'Company Profile', section: 'Overview' },
    { to: '/site-builder', icon: Globe, label: 'Subdomain Site', section: 'Web Presence' },
    { to: '/content', icon: FileText, label: 'Content Manager', section: 'Web Presence' },
    { to: '/email', icon: Mail, label: 'Email Services', section: 'Communication' },
    { to: '/control-panel', icon: ShieldCheck, label: 'Control Panel', section: 'Administration' },
    { to: '/database', icon: Database, label: 'Database & Server', section: 'Administration' },
    { to: '/manual', icon: BookOpen, label: 'Development Manual', section: 'Administration' },
  ];

  const sections = ['Overview', 'Web Presence', 'Communication', 'Administration'];

  const getPageTitle = () => {
    const path = location.pathname;
    const titles: Record<string, string> = {
      '/': 'Dashboard',
      '/products': 'Products & Services',
      '/certifications': 'Certifications',
      '/messages': 'Messages',
      '/profile': 'Company Profile',
      '/register': 'Supplier Registration',
      '/site-builder': 'Subdomain Site Builder',
      '/content': 'Content Manager',
      '/email': 'Email Services',
      '/control-panel': 'Control Panel',
      '/database': 'Database & Web Server',
      '/quality': 'Quality Assurance',
      '/manpower': 'Manpower Sourcing',
      '/manual': 'Development Manual',
    };
    return titles[path] || '';
  };

  return (
    <div className="min-h-screen bg-cream-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-slate-warm-950/40 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white border-r border-slate-warm-200 flex flex-col transform transition-transform duration-300 ease-in-out ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-slate-warm-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-warm-500 to-warm-700 flex items-center justify-center">
              <Package className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-semibold text-slate-warm-900 tracking-tight">SupplyHub</span>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto lg:hidden text-slate-warm-500 hover:text-slate-warm-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-5 overflow-y-auto scrollbar-thin">
          {sections.map(section => (
            <div key={section}>
              <p className="px-3 mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-warm-400">{section}</p>
              <div className="space-y-0.5">
                {navItems.filter(item => item.section === section).map(item => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setSidebarOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                        isActive
                          ? 'bg-warm-50 text-warm-800 border border-warm-200'
                          : 'text-slate-warm-600 hover:bg-slate-warm-50 hover:text-slate-warm-800'
                      }`
                    }
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="flex-1">{item.label}</span>
                    {item.badge && item.badge > 0 && (
                      <span className="px-2 py-0.5 text-xs font-semibold bg-warm-500 text-white rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </NavLink>
                ))}
              </div>
            </div>
          ))}

          {/* Live site link */}
          <div className="pt-3 border-t border-slate-warm-100">
            <a
              href="#"
              onClick={(e) => { e.preventDefault(); window.open(`#`, '_blank'); }}
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-slate-warm-600 hover:bg-slate-warm-50 hover:text-slate-warm-800 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span className="flex-1 truncate">{subdomain}.supplyhub.io</span>
            </a>
          </div>
        </nav>

        {/* User section */}
        <div className="p-4 border-t border-slate-warm-100">
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-warm-400 to-warm-600 flex items-center justify-center text-white font-semibold text-sm">
              MC
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-warm-800 truncate">Müller Components GmbH</p>
              <p className="text-xs text-slate-warm-500 truncate">Verified Supplier</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-16 bg-white border-b border-slate-warm-200 flex items-center px-4 lg:px-6 gap-4 sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-slate-warm-600 hover:text-slate-warm-800">
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-sm text-slate-warm-500">
            <span>SupplyHub</span>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-slate-warm-800 font-medium">{getPageTitle()}</span>
          </div>

          <div className="ml-auto flex items-center gap-3">
            <a href="#" onClick={(e) => e.preventDefault()} className="hidden md:flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-warm-700 bg-warm-50 border border-warm-200 rounded-lg hover:bg-warm-100 transition-colors">
              <Globe className="w-3.5 h-3.5" />
              {subdomain}.supplyhub.io
            </a>
            <button className="relative p-2 text-slate-warm-500 hover:text-slate-warm-700 hover:bg-slate-warm-50 rounded-lg transition-colors">
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-warm-500 rounded-full" />
              )}
            </button>
            <button className="p-2 text-slate-warm-500 hover:text-slate-warm-700 hover:bg-slate-warm-50 rounded-lg transition-colors">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
