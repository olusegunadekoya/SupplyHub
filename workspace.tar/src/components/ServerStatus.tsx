import React, { useEffect, useState } from 'react';
import { DatabaseAPI } from '../services/api';
import { Database, Server, Activity, Wifi } from 'lucide-react';

export default function ServerStatus() {
  const [stats, setStats] = useState<any>(null);
  const [serverInfo, setServerInfo] = useState<any>(null);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const [s, info] = await Promise.all([
          DatabaseAPI.getStats(),
          DatabaseAPI.getServerInfo(),
        ]);
        setStats(s);
        setServerInfo(info);
      } catch (err) {
        console.error('Failed to load server stats:', err);
      }
    };
    load();
    const interval = setInterval(load, 10000);
    return () => clearInterval(interval);
  }, []);

  const totalRecords = stats ? Object.values(stats).reduce((a: number, b: any) => a + (b as number), 0) : 0;

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 z-40 flex items-center gap-2 px-3 py-2 bg-slate-warm-900 text-white rounded-full shadow-lg hover:bg-slate-warm-800 transition-colors text-xs font-medium"
        title="Server Status"
      >
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
        </span>
        Server Online
      </button>

      {isOpen && (
        <div className="fixed bottom-16 right-4 z-40 w-80 bg-white rounded-xl shadow-2xl border border-slate-warm-200 overflow-hidden animate-fade-in">
          <div className="px-4 py-3 bg-gradient-to-r from-slate-warm-900 to-slate-warm-800 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4" />
                <span className="text-sm font-semibold">Web Server</span>
              </div>
              <span className="flex items-center gap-1 text-xs text-emerald-300">
                <Wifi className="w-3 h-3" /> Connected
              </span>
            </div>
            <p className="text-xs text-slate-warm-300 mt-1">SupplyHub Platform v{serverInfo?.version || '1.0.0'}</p>
          </div>

          <div className="p-4 space-y-3 max-h-96 overflow-y-auto scrollbar-thin">
            {/* Server Info */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-warm-500 uppercase tracking-wider">Server Info</h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-warm-50 rounded p-2">
                  <p className="text-slate-warm-500">Database</p>
                  <p className="font-medium text-slate-warm-800">{serverInfo?.database || 'IndexedDB'}</p>
                </div>
                <div className="bg-slate-warm-50 rounded p-2">
                  <p className="text-slate-warm-500">Tables</p>
                  <p className="font-medium text-slate-warm-800">{serverInfo?.tables || 15}</p>
                </div>
                <div className="bg-slate-warm-50 rounded p-2">
                  <p className="text-slate-warm-500">Uptime</p>
                  <p className="font-medium text-slate-warm-800">{serverInfo?.uptime || 0}s</p>
                </div>
                <div className="bg-slate-warm-50 rounded p-2">
                  <p className="text-slate-warm-500">Storage</p>
                  <p className="font-medium text-slate-warm-800">{serverInfo?.storageUsed || '0 MB'}</p>
                </div>
              </div>
            </div>

            {/* Database Stats */}
            {stats && (
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-slate-warm-500 uppercase tracking-wider flex items-center gap-1">
                  <Database className="w-3 h-3" /> Database Records
                  <span className="ml-auto text-slate-warm-400 normal-case font-normal">{totalRecords} total</span>
                </h4>
                <div className="grid grid-cols-2 gap-1.5">
                  {Object.entries(stats).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between px-2 py-1.5 bg-slate-warm-50 rounded text-xs">
                      <span className="text-slate-warm-600 capitalize truncate">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                      <span className="font-mono font-medium text-slate-warm-800 ml-2">{value as number}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* API Endpoints */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-warm-500 uppercase tracking-wider">API Endpoints</h4>
              <div className="space-y-1 text-xs font-mono">
                <div className="flex items-center gap-2 px-2 py-1 bg-emerald-50 text-emerald-700 rounded">
                  <span className="px-1.5 py-0.5 bg-emerald-100 rounded text-[10px] font-bold">GET</span>
                  <span>/api/suppliers/current</span>
                </div>
                <div className="flex items-center gap-2 px-2 py-1 bg-blue-50 text-blue-700 rounded">
                  <span className="px-1.5 py-0.5 bg-blue-100 rounded text-[10px] font-bold">POST</span>
                  <span>/api/products</span>
                </div>
                <div className="flex items-center gap-2 px-2 py-1 bg-amber-50 text-amber-700 rounded">
                  <span className="px-1.5 py-0.5 bg-amber-100 rounded text-[10px] font-bold">PUT</span>
                  <span>/api/site-config</span>
                </div>
                <div className="flex items-center gap-2 px-2 py-1 bg-emerald-50 text-emerald-700 rounded">
                  <span className="px-1.5 py-0.5 bg-emerald-100 rounded text-[10px] font-bold">GET</span>
                  <span>/api/subdomain/:name</span>
                </div>
                <div className="flex items-center gap-2 px-2 py-1 bg-blue-50 text-blue-700 rounded">
                  <span className="px-1.5 py-0.5 bg-blue-100 rounded text-[10px] font-bold">POST</span>
                  <span>/api/email/send</span>
                </div>
                <div className="flex items-center gap-2 px-2 py-1 bg-emerald-50 text-emerald-700 rounded">
                  <span className="px-1.5 py-0.5 bg-emerald-100 rounded text-[10px] font-bold">GET</span>
                  <span>/api/webhooks</span>
                </div>
              </div>
            </div>

            {/* Multi-tenancy */}
            <div className="bg-warm-50 border border-warm-200 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <Activity className="w-4 h-4 text-warm-600 mt-0.5" />
                <div>
                  <p className="text-xs font-medium text-warm-800">Multi-Tenant Architecture</p>
                  <p className="text-xs text-warm-600 mt-0.5">Each supplier has isolated data keyed by subdomain. All queries are tenant-scoped for data isolation.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
