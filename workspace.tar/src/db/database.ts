import Dexie, { Table } from 'dexie';

// ============================================================================
// DATABASE SCHEMA - SupplyHub Multi-Tenant Platform
// Each supplier has isolated data keyed by supplierId (subdomain)
// ============================================================================

export interface DBSupplier {
  id?: number;
  supplierId: string;           // UUID - primary tenant identifier
  subdomain: string;            // unique subdomain (e.g. "mueller-components")
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  industry: string;
  companySize: string;
  description: string;
  website: string;
  taxId: string;
  status: 'pending' | 'approved' | 'suspended';
  brandColor: string;
  logoText: string;
  plan: 'free' | 'professional' | 'enterprise';
  storageUsed: number;          // bytes
  storageLimit: number;         // bytes
  registeredAt: string;
  approvedAt?: string;
  lastLoginAt?: string;
  updatedAt?: string;
}

export interface DBUser {
  id?: number;
  userId: string;
  supplierId: string;           // FK -> DBSupplier.supplierId
  name: string;
  email: string;
  passwordHash: string;         // in real app, never store plaintext
  role: 'owner' | 'admin' | 'editor' | 'viewer';
  status: 'active' | 'invited' | 'suspended';
  twoFactorEnabled: boolean;
  lastActiveAt?: string;
  createdAt: string;
}

export interface DBProduct {
  id?: number;
  productId: string;
  supplierId: string;
  name: string;
  category: string;
  description: string;
  characteristics: string;      // JSON stringified array
  specifications: string;       // JSON stringified object
  price: string;
  minOrderQuantity: string;
  leadTime: string;
  images: string;               // JSON array of URLs
  status: 'draft' | 'active' | 'under_review';
  viewCount: number;
  inquiryCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface DBCertification {
  id?: number;
  certId: string;
  supplierId: string;
  name: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  fileName: string;
  fileUrl: string;
  fileSize: number;
  status: 'pending' | 'verified' | 'expired';
  verifiedBy?: string;
  verifiedAt?: string;
  createdAt: string;
}

export interface DBMessage {
  id?: number;
  messageId: string;
  supplierId: string;
  senderType: 'supplier' | 'coordinator';
  senderId: string;
  senderName: string;
  content: string;
  timestamp: string;
  read: boolean;
  parentId?: string;            // for threaded replies
}

export interface DBPage {
  id?: number;
  pageId: string;
  supplierId: string;
  title: string;
  slug: string;
  content: string;
  metaDescription: string;
  status: 'published' | 'draft' | 'archived';
  authorId: string;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
  viewCount: number;
}

export interface DBBanner {
  id?: number;
  bannerId: string;
  supplierId: string;
  title: string;
  subtitle: string;
  ctaText: string;
  ctaLink: string;
  active: boolean;
  position: 'hero' | 'sidebar' | 'footer';
  startDate?: string;
  endDate?: string;
  createdAt: string;
}

export interface DBMenuItem {
  id?: number;
  menuItemId: string;
  supplierId: string;
  label: string;
  link: string;
  type: 'page' | 'external' | 'product';
  order: number;
  visible: boolean;
}

export interface DBEmailTemplate {
  id?: number;
  templateId: string;
  supplierId: string;
  name: string;
  subject: string;
  body: string;
  type: 'inquiry' | 'order' | 'newsletter' | 'custom';
  variables: string;            // JSON array
  createdAt: string;
  updatedAt: string;
}

export interface DBSentEmail {
  id?: number;
  emailId: string;
  supplierId: string;
  fromAddress: string;
  toAddress: string;
  subject: string;
  body: string;
  templateId?: string;
  status: 'queued' | 'sent' | 'delivered' | 'failed' | 'read' | 'bounced';
  retryCount: number;
  sentAt?: string;
  deliveredAt?: string;
  readAt?: string;
  errorMessage?: string;
  createdAt: string;
}

export interface DBSiteConfig {
  id?: number;
  supplierId: string;           // 1:1 with supplier
  headerBg: string;
  headerText: string;
  footerBg: string;
  footerText: string;
  primaryColor: string;
  accentColor: string;
  showContactForm: boolean;
  showProductCatalog: boolean;
  showCertifications: boolean;
  companyName: string;
  tagline: string;
  socialLinks: string;          // JSON array
  contactEmail: string;
  contactPhone: string;
  customDomain?: string;
  sslStatus: 'active' | 'provisioning' | 'expired';
  sslExpiresAt?: string;
  updatedAt: string;
}

export interface DBWebhook {
  id?: number;
  webhookId: string;
  supplierId: string;
  url: string;
  events: string;               // JSON array of event types
  secret: string;
  active: boolean;
  lastTriggeredAt?: string;
  lastResponseStatus?: number;
  createdAt: string;
}

export interface DBActivityLog {
  id?: number;
  logId: string;
  supplierId: string;
  userId: string;
  userName: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;              // JSON
  ipAddress: string;
  userAgent: string;
  createdAt: string;
}

export interface DBApiKey {
  id?: number;
  keyId: string;
  supplierId: string;
  name: string;
  keyHash: string;              // hashed, never plaintext
  prefix: string;               // first 8 chars for identification
  permissions: string;          // JSON array
  lastUsedAt?: string;
  expiresAt?: string;
  createdAt: string;
  revokedAt?: string;
}

export interface DBSubdomainRoute {
  id?: number;
  subdomain: string;            // unique index
  supplierId: string;
  active: boolean;
  sslEnabled: boolean;
  customDomain?: string;
  createdAt: string;
}

// ============================================================================
// QUALITY ASSURANCE TABLES
// ============================================================================

export interface DBQualityMetric {
  id?: number;
  metricId: string;
  supplierId: string;
  period: string;               // e.g. "2024-Q1", "2024-03"
  periodType: 'monthly' | 'quarterly' | 'annual';
  defectRate: number;           // percentage
  onTimeDelivery: number;       // percentage
  complianceScore: number;      // 0-100
  responseTime: number;         // average hours
  firstPassYield: number;       // percentage
  customerComplaints: number;
  auditScore: number;           // 0-100
  overallScore: number;         // weighted composite 0-100
  recordedAt: string;
}

export interface DBInspection {
  id?: number;
  inspectionId: string;
  supplierId: string;
  title: string;
  type: 'incoming' | 'in_process' | 'final' | 'audit' | 'surveillance';
  scheduledDate: string;
  completedDate?: string;
  inspector: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
  scope: string;
  findings: string;             // JSON array
  conclusion: 'pass' | 'conditional_pass' | 'fail' | 'pending';
  correctiveActions: string;    // JSON array of action IDs
  attachments: string;          // JSON array of file URLs
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface DBNCRReport {
  id?: number;
  ncrId: string;
  supplierId: string;
  ncrNumber: string;            // e.g. "NCR-2024-001"
  title: string;
  description: string;
  severity: 'minor' | 'major' | 'critical';
  category: 'product' | 'process' | 'documentation' | 'certification' | 'delivery';
  affectedProduct?: string;
  affectedBatch?: string;
  reportedBy: string;
  reportedDate: string;
  dueDate: string;
  status: 'open' | 'investigating' | 'corrective_action' | 'verification' | 'closed';
  rootCause: string;
  correctiveAction: string;
  preventiveAction: string;
  verificationResult: string;
  closedBy?: string;
  closedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DBCAPAAction {
  id?: number;
  capaId: string;
  supplierId: string;
  capaNumber: string;           // e.g. "CAPA-2024-001"
  title: string;
  description: string;
  type: 'corrective' | 'preventive';
  source: 'ncr' | 'audit' | 'complaint' | 'internal';
  sourceRefId?: string;         // Reference to NCR/audit ID
  priority: 'low' | 'medium' | 'high' | 'critical';
  assignedTo: string;
  dueDate: string;
  status: 'open' | 'in_progress' | 'completed' | 'verified' | 'closed' | 'overdue';
  effectivenessCheck: string;
  completedDate?: string;
  verifiedBy?: string;
  verifiedDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DBScorecard {
  id?: number;
  scorecardId: string;
  supplierId: string;
  period: string;               // e.g. "2024-Q1"
  periodType: 'monthly' | 'quarterly' | 'annual';
  qualityScore: number;         // 0-100
  deliveryScore: number;        // 0-100
  responsivenessScore: number;  // 0-100
  complianceScore: number;      // 0-100
  innovationScore: number;      // 0-100
  overallScore: number;         // weighted composite 0-100
  grade: 'A' | 'B' | 'C' | 'D' | 'F';
  trend: 'improving' | 'stable' | 'declining';
  comments: string;
  issuedAt: string;
  issuedBy: string;
}

export interface DBQualityDocument {
  id?: number;
  docId: string;
  supplierId: string;
  title: string;
  docNumber: string;            // e.g. "QP-001"
  type: 'procedure' | 'work_instruction' | 'form' | 'specification' | 'record';
  revision: string;             // e.g. "Rev. 3"
  status: 'draft' | 'under_review' | 'approved' | 'obsolete';
  owner: string;
  approvedBy?: string;
  approvedAt?: string;
  nextReviewDate: string;
  fileUrl: string;
  fileSize: number;
  createdAt: string;
  updatedAt: string;
}

// ============================================================================
// MANPOWER SOURCING TABLES
// ============================================================================

export interface DBExpert {
  id?: number;
  expertId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  photoUrl: string;
  title: string;                // e.g. "Senior Mechanical Engineer"
  bio: string;
  location: string;             // city, country
  region: 'local' | 'regional' | 'international';
  nationality: string;
  languages: string;            // JSON array
  hourlyRate: number;
  currency: string;
  availability: 'available' | 'engaged' | 'on_leave' | 'unavailable';
  yearsExperience: number;
  education: string;            // JSON array of degrees
  certifications: string;       // JSON array
  skills: string;               // JSON array of skill IDs
  rating: number;               // 0-5
  totalAssignments: number;
  verified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DBExpertSkill {
  id?: number;
  skillId: string;
  name: string;
  category: string;             // e.g. "Engineering", "Quality", "Management"
  description: string;
}

export interface DBSourcingRequest {
  id?: number;
  requestId: string;
  requestNumber: string;        // e.g. "SR-2024-001"
  supplierId: string;
  title: string;
  description: string;
  skillsRequired: string;       // JSON array of skill IDs
  experienceRequired: number;   // minimum years
  region: 'local' | 'regional' | 'international' | 'any';
  duration: string;             // e.g. "3 months", "6 weeks"
  startDate: string;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  budget: number;
  currency: string;
  status: 'draft' | 'open' | 'screening' | 'shortlisted' | 'interview' | 'offered' | 'contracted' | 'fulfilled' | 'cancelled';
  candidatesShortlisted: number;
  candidatesInterviewed: number;
  assignedExpertId?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface DBExpertContract {
  id?: number;
  contractId: string;
  contractNumber: string;       // e.g. "CTR-2024-001"
  supplierId: string;
  expertId: string;
  requestId: string;
  title: string;
  scope: string;
  startDate: string;
  endDate: string;
  hourlyRate: number;
  currency: string;
  estimatedHours: number;
  totalValue: number;
  status: 'draft' | 'pending' | 'active' | 'completed' | 'terminated';
  workLocation: string;         // on-site, remote, hybrid
  signedByExpert?: string;
  signedBySupplier?: string;
  signedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DBExpertAssignment {
  id?: number;
  assignmentId: string;
  expertId: string;
  supplierId: string;
  contractId: string;
  title: string;
  startDate: string;
  endDate: string;
  status: 'planned' | 'active' | 'on_hold' | 'completed' | 'cancelled';
  hoursLogged: number;
  performanceRating?: number;
  feedback?: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================================================
// DATABASE CLASS
// ============================================================================

export class SupplyHubDatabase extends Dexie {
  suppliers!: Table<DBSupplier, number>;
  users!: Table<DBUser, number>;
  products!: Table<DBProduct, number>;
  certifications!: Table<DBCertification, number>;
  messages!: Table<DBMessage, number>;
  pages!: Table<DBPage, number>;
  banners!: Table<DBBanner, number>;
  menuItems!: Table<DBMenuItem, number>;
  emailTemplates!: Table<DBEmailTemplate, number>;
  sentEmails!: Table<DBSentEmail, number>;
  siteConfigs!: Table<DBSiteConfig, number>;
  webhooks!: Table<DBWebhook, number>;
  activityLogs!: Table<DBActivityLog, number>;
  apiKeys!: Table<DBApiKey, number>;
  subdomainRoutes!: Table<DBSubdomainRoute, number>;
  // Quality Assurance tables
  qualityMetrics!: Table<DBQualityMetric, number>;
  inspections!: Table<DBInspection, number>;
  ncrReports!: Table<DBNCRReport, number>;
  capaActions!: Table<DBCAPAAction, number>;
  scorecards!: Table<DBScorecard, number>;
  qualityDocuments!: Table<DBQualityDocument, number>;
  // Manpower Sourcing tables
  experts!: Table<DBExpert, number>;
  expertSkills!: Table<DBExpertSkill, number>;
  sourcingRequests!: Table<DBSourcingRequest, number>;
  expertContracts!: Table<DBExpertContract, number>;
  expertAssignments!: Table<DBExpertAssignment, number>;

  constructor() {
    super('SupplyHubDB');

    // Schema versioning - each version defines indexes
    this.version(1).stores({
      suppliers: '++id, &supplierId, &subdomain, email, status, registeredAt',
      users: '++id, &userId, supplierId, email, role, status, [supplierId+role]',
      products: '++id, &productId, supplierId, category, status, createdAt, [supplierId+status]',
      certifications: '++id, &certId, supplierId, status, expiryDate, [supplierId+status]',
      messages: '++id, &messageId, supplierId, senderType, timestamp, read, [supplierId+read]',
      pages: '++id, &pageId, supplierId, slug, status, [supplierId+status], [supplierId+slug]',
      banners: '++id, &bannerId, supplierId, position, active, [supplierId+active]',
      menuItems: '++id, &menuItemId, supplierId, order, [supplierId+order]',
      emailTemplates: '++id, &templateId, supplierId, type, [supplierId+type]',
      sentEmails: '++id, &emailId, supplierId, status, sentAt, [supplierId+status], [supplierId+sentAt]',
      siteConfigs: '++id, &supplierId',
      webhooks: '++id, &webhookId, supplierId, active, [supplierId+active]',
      activityLogs: '++id, &logId, supplierId, userId, action, entityType, createdAt, [supplierId+createdAt], [supplierId+action]',
      apiKeys: '++id, &keyId, supplierId, prefix, [supplierId+revokedAt]',
      subdomainRoutes: '++id, &subdomain, supplierId, active',
      // Quality Assurance
      qualityMetrics: '++id, &metricId, supplierId, period, periodType, [supplierId+period], [supplierId+periodType]',
      inspections: '++id, &inspectionId, supplierId, type, status, scheduledDate, [supplierId+status], [supplierId+type]',
      ncrReports: '++id, &ncrId, supplierId, &ncrNumber, severity, status, category, reportedDate, [supplierId+status], [supplierId+severity]',
      capaActions: '++id, &capaId, supplierId, &capaNumber, type, priority, status, dueDate, [supplierId+status], [supplierId+priority]',
      scorecards: '++id, &scorecardId, supplierId, period, periodType, grade, [supplierId+period], [supplierId+periodType]',
      qualityDocuments: '++id, &docId, supplierId, &docNumber, type, status, [supplierId+status], [supplierId+type]',
      // Manpower Sourcing
      experts: '++id, &expertId, email, region, availability, [region+availability]',
      expertSkills: '++id, &skillId, category, name',
      sourcingRequests: '++id, &requestId, supplierId, &requestNumber, status, urgency, [supplierId+status], [supplierId+urgency]',
      expertContracts: '++id, &contractId, supplierId, expertId, &contractNumber, status, [supplierId+status], [expertId+status]',
      expertAssignments: '++id, &assignmentId, expertId, supplierId, contractId, status, [expertId+status], [supplierId+status]',
    });
  }
}

// Singleton instance
export const db = new SupplyHubDatabase();

// Helper to generate UUIDs
export function generateId(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export function generateApiKey(): { key: string; prefix: string; hash: string } {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let key = 'shub_live_';
  for (let i = 0; i < 40; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return {
    key,
    prefix: key.substring(0, 12),
    hash: btoa(key).substring(0, 32), // simplified hash for demo
  };
}
