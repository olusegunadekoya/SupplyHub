import { db, generateId, generateApiKey, DBSupplier, DBUser, DBProduct, DBCertification, DBMessage, DBPage, DBBanner, DBMenuItem, DBEmailTemplate, DBSentEmail, DBSiteConfig, DBSubdomainRoute, DBApiKey, DBActivityLog, DBQualityMetric, DBInspection, DBNCRReport, DBCAPAAction, DBScorecard, DBQualityDocument, DBExpert, DBExpertSkill, DBSourcingRequest, DBExpertContract, DBExpertAssignment } from './database';

// ============================================================================
// DATABASE SEEDER - Populates initial data for demo
// ============================================================================

export async function seedDatabase(): Promise<void> {
  const count = await db.suppliers.count();
  if (count > 0) return; // Already seeded

  console.log('[DB] Seeding database with initial data...');

  const supplierId = 'sup-mueller-001';
  const now = new Date().toISOString();

  // 1. Seed Supplier
  const supplier: DBSupplier = {
    supplierId,
    subdomain: 'mueller-components',
    companyName: 'Müller Components GmbH',
    contactPerson: 'Hans Müller',
    email: 'hans.mueller@mueller-components.de',
    phone: '+49 89 1234 5678',
    address: 'Industriestraße 42',
    city: 'Munich',
    country: 'Germany',
    industry: 'Manufacturing & Industrial Components',
    companySize: '51-200',
    description: 'Müller Components GmbH is a leading manufacturer of precision industrial components, specializing in mechanical parts, seals, and custom machining services. With over 25 years of experience, we serve clients across automotive, aerospace, and general industrial sectors throughout Europe.',
    website: 'www.mueller-components.de',
    taxId: 'DE123456789',
    status: 'approved',
    brandColor: '#c06d23',
    logoText: 'MC',
    plan: 'professional',
    storageUsed: 2_500_000_000,
    storageLimit: 10_000_000_000,
    registeredAt: '2024-01-10T09:00:00Z',
    approvedAt: '2024-01-10T14:30:00Z',
    lastLoginAt: now,
  };
  await db.suppliers.add(supplier);

  // 2. Seed Users
  const users: DBUser[] = [
    { userId: generateId(), supplierId, name: 'Hans Müller', email: 'hans.mueller@mueller-components.de', passwordHash: 'hashed_pw_1', role: 'owner', status: 'active', twoFactorEnabled: true, lastActiveAt: now, createdAt: '2024-01-10T09:00:00Z' },
    { userId: generateId(), supplierId, name: 'Anna Weber', email: 'anna.weber@mueller-components.de', passwordHash: 'hashed_pw_2', role: 'admin', status: 'active', twoFactorEnabled: true, lastActiveAt: now, createdAt: '2024-01-15T10:00:00Z' },
    { userId: generateId(), supplierId, name: 'Klaus Fischer', email: 'klaus.fischer@mueller-components.de', passwordHash: 'hashed_pw_3', role: 'editor', status: 'active', twoFactorEnabled: false, lastActiveAt: now, createdAt: '2024-02-01T09:00:00Z' },
    { userId: generateId(), supplierId, name: 'Maria Schmidt', email: 'maria.s@mueller-components.de', passwordHash: 'hashed_pw_4', role: 'viewer', status: 'invited', twoFactorEnabled: false, createdAt: '2024-03-12T15:30:00Z' },
  ];
  await db.users.bulkAdd(users);

  // 3. Seed Products
  const products: DBProduct[] = [
    {
      productId: generateId(), supplierId, name: 'Industrial Grade Steel Bearings', category: 'Mechanical Components',
      description: 'High-precision steel bearings designed for heavy-duty industrial applications. Manufactured with premium chrome steel for maximum durability and performance.',
      characteristics: JSON.stringify(['High load capacity', 'Low friction coefficient', 'Corrosion resistant', 'Temperature resistant up to 150°C']),
      specifications: JSON.stringify({ 'Inner Diameter': '25mm', 'Outer Diameter': '52mm', 'Width': '15mm', 'Material': 'Chrome Steel GCr15', 'Precision Class': 'P6', 'Dynamic Load Rating': '16.8 kN' }),
      price: '€12.50', minOrderQuantity: '100 units', leadTime: '2-3 weeks',
      images: JSON.stringify([]), status: 'active', viewCount: 342, inquiryCount: 28,
      createdAt: '2024-01-15T10:00:00Z', updatedAt: now,
    },
    {
      productId: generateId(), supplierId, name: 'Precision CNC Machining Service', category: 'Manufacturing Services',
      description: 'Full-service CNC machining including milling, turning, and multi-axis operations. ISO 9001 certified facility with tight tolerance capabilities.',
      characteristics: JSON.stringify(['Multi-axis capability', 'Tight tolerances (±0.005mm)', 'Various material support', 'Rapid prototyping available']),
      specifications: JSON.stringify({ 'Max Part Size': '500x400x300mm', 'Tolerance': '±0.005mm', 'Surface Finish': 'Ra 0.8μm', 'Materials': 'Aluminum, Steel, Titanium, Brass' }),
      price: 'From €45/hour', minOrderQuantity: '1 piece', leadTime: '5-15 business days',
      images: JSON.stringify([]), status: 'active', viewCount: 518, inquiryCount: 45,
      createdAt: '2024-02-01T10:00:00Z', updatedAt: now,
    },
    {
      productId: generateId(), supplierId, name: 'Custom Rubber Seals & Gaskets', category: 'Sealing Solutions',
      description: 'Custom-manufactured rubber seals and gaskets for automotive, industrial, and marine applications.',
      characteristics: JSON.stringify(['Custom profiles', 'Chemical resistant', 'UV stable options', 'Food-grade available']),
      specifications: JSON.stringify({ 'Materials': 'NBR, EPDM, Silicone, FKM', 'Hardness Range': '30-90 Shore A', 'Temperature Range': '-40°C to +250°C', 'Compliance': 'REACH, RoHS, FDA' }),
      price: 'From €0.15/piece', minOrderQuantity: '500 pieces', leadTime: '3-4 weeks',
      images: JSON.stringify([]), status: 'under_review', viewCount: 127, inquiryCount: 8,
      createdAt: '2024-03-10T10:00:00Z', updatedAt: now,
    },
  ];
  await db.products.bulkAdd(products);

  // 4. Seed Certifications
  const certs: DBCertification[] = [
    { certId: generateId(), supplierId, name: 'ISO 9001:2015', issuer: 'TÜV Rheinland', issueDate: '2023-06-15', expiryDate: '2026-06-14', fileName: 'ISO_9001_Certificate.pdf', fileUrl: '/files/iso9001.pdf', fileSize: 245_000, status: 'verified', verifiedBy: 'Sarah Mitchell', verifiedAt: '2024-01-11T10:00:00Z', createdAt: '2024-01-10T10:00:00Z' },
    { certId: generateId(), supplierId, name: 'ISO 14001:2015', issuer: 'Bureau Veritas', issueDate: '2023-09-01', expiryDate: '2026-08-31', fileName: 'ISO_14001_Certificate.pdf', fileUrl: '/files/iso14001.pdf', fileSize: 198_000, status: 'verified', verifiedBy: 'Sarah Mitchell', verifiedAt: '2024-01-11T10:05:00Z', createdAt: '2024-01-10T10:00:00Z' },
    { certId: generateId(), supplierId, name: 'CE Marking - Machinery Directive', issuer: 'Self-declaration', issueDate: '2024-01-10', expiryDate: '2025-01-09', fileName: 'CE_Declaration.pdf', fileUrl: '/files/ce.pdf', fileSize: 89_000, status: 'pending', createdAt: '2024-01-10T10:00:00Z' },
  ];
  await db.certifications.bulkAdd(certs);

  // 5. Seed Messages
  const messages: DBMessage[] = [
    { messageId: generateId(), supplierId, senderType: 'coordinator', senderId: 'coord-001', senderName: 'Sarah Mitchell', content: 'Welcome to SupplyHub! Your account has been approved. Please complete your company profile and upload your certifications at your earliest convenience.', timestamp: '2024-01-10T09:30:00Z', read: true },
    { messageId: generateId(), supplierId, senderType: 'coordinator', senderId: 'coord-001', senderName: 'Sarah Mitchell', content: 'We noticed your ISO 14001 certificate is about to expire. Please upload the renewed certificate before the expiry date to maintain your verified status.', timestamp: '2024-03-01T14:15:00Z', read: true },
    { messageId: generateId(), supplierId, senderType: 'coordinator', senderId: 'coord-002', senderName: 'David Chen', content: 'Your new product listing "Custom Rubber Seals & Gaskets" is currently under review. We\'ll notify you once the review is complete.', timestamp: '2024-03-12T11:00:00Z', read: false },
  ];
  await db.messages.bulkAdd(messages);

  // 6. Seed CMS Pages
  const pages: DBPage[] = [
    { pageId: generateId(), supplierId, title: 'About Us', slug: 'about', content: 'Müller Components GmbH is a family-owned precision manufacturing company with over 25 years of experience serving the European industrial market. Our state-of-the-art facility in Munich combines traditional craftsmanship with cutting-edge CNC technology.\n\nWe are committed to quality, sustainability, and building long-term partnerships with our clients across automotive, aerospace, and general industrial sectors.', metaDescription: 'Learn about Müller Components GmbH', status: 'published', authorId: users[0].userId, publishedAt: '2024-02-15T10:00:00Z', createdAt: '2024-02-15T10:00:00Z', updatedAt: now, viewCount: 1240 },
    { pageId: generateId(), supplierId, title: 'Quality Assurance', slug: 'quality', content: 'Quality is at the core of everything we do. Our facility is ISO 9001:2015 and ISO 14001:2015 certified, and we maintain rigorous quality control processes at every stage of production.', metaDescription: 'Our quality commitment', status: 'published', authorId: users[0].userId, publishedAt: '2024-03-01T10:00:00Z', createdAt: '2024-03-01T10:00:00Z', updatedAt: now, viewCount: 856 },
    { pageId: generateId(), supplierId, title: 'Sustainability', slug: 'sustainability', content: 'We are committed to sustainable manufacturing practices. Our facility uses 100% renewable energy, and we have reduced our carbon footprint by 40% over the last five years.', metaDescription: 'Our sustainability efforts', status: 'draft', authorId: users[0].userId, createdAt: '2024-03-10T10:00:00Z', updatedAt: now, viewCount: 0 },
  ];
  await db.pages.bulkAdd(pages);

  // 7. Seed Banners
  const banners: DBBanner[] = [
    { bannerId: generateId(), supplierId, title: 'New CNC Capabilities', subtitle: '5-axis machining now available for complex geometries', ctaText: 'Learn More', ctaLink: '/services', active: true, position: 'hero', createdAt: now },
    { bannerId: generateId(), supplierId, title: 'ISO 14001 Certified', subtitle: 'Committed to environmental excellence', ctaText: 'Read More', ctaLink: '/sustainability', active: true, position: 'sidebar', createdAt: now },
  ];
  await db.banners.bulkAdd(banners);

  // 8. Seed Menu Items
  const menuItems: DBMenuItem[] = [
    { menuItemId: generateId(), supplierId, label: 'Home', link: '/', type: 'page', order: 1, visible: true },
    { menuItemId: generateId(), supplierId, label: 'Products', link: '/products', type: 'product', order: 2, visible: true },
    { menuItemId: generateId(), supplierId, label: 'Services', link: '/services', type: 'page', order: 3, visible: true },
    { menuItemId: generateId(), supplierId, label: 'About', link: '/about', type: 'page', order: 4, visible: true },
    { menuItemId: generateId(), supplierId, label: 'Quality', link: '/quality', type: 'page', order: 5, visible: true },
    { menuItemId: generateId(), supplierId, label: 'Contact', link: '/contact', type: 'page', order: 6, visible: true },
  ];
  await db.menuItems.bulkAdd(menuItems);

  // 9. Seed Email Templates
  const templates: DBEmailTemplate[] = [
    { templateId: generateId(), supplierId, name: 'Product Inquiry Response', subject: 'Re: Inquiry about {{product_name}}', body: 'Dear {{customer_name}},\n\nThank you for your interest in {{product_name}}. We would be happy to provide you with a detailed quotation.\n\nBest regards,\n{{sender_name}}\nMüller Components GmbH', type: 'inquiry', variables: JSON.stringify(['customer_name', 'product_name', 'sender_name']), createdAt: '2024-01-20T10:00:00Z', updatedAt: now },
    { templateId: generateId(), supplierId, name: 'Order Confirmation', subject: 'Order Confirmation #{{order_id}}', body: 'Dear {{customer_name}},\n\nWe are pleased to confirm your order #{{order_id}}.\n\nOrder Details:\n- Product: {{product_name}}\n- Quantity: {{quantity}}\n- Estimated Delivery: {{delivery_date}}\n\nBest regards,\nMüller Components GmbH', type: 'order', variables: JSON.stringify(['customer_name', 'order_id', 'product_name', 'quantity', 'delivery_date']), createdAt: '2024-02-05T10:00:00Z', updatedAt: now },
    { templateId: generateId(), supplierId, name: 'Monthly Newsletter', subject: 'Müller Components - {{month}} Update', body: 'Dear valued partner,\n\nHere are the latest updates from Müller Components:\n\n• New product launches\n• Industry insights\n• Company news\n\nVisit our website for more information.\n\nBest regards,\nThe Müller Components Team', type: 'newsletter', variables: JSON.stringify(['month']), createdAt: '2024-02-15T10:00:00Z', updatedAt: now },
  ];
  await db.emailTemplates.bulkAdd(templates);

  // 10. Seed Sent Emails
  const sentEmails: DBSentEmail[] = [
    { emailId: generateId(), supplierId, fromAddress: 'info@mueller-components.supplyhub.io', toAddress: 'procurement@autoworks.de', subject: 'Re: Inquiry about Industrial Grade Steel Bearings', body: '...', templateId: templates[0].templateId, status: 'read', sentAt: '2024-03-14T10:30:00Z', deliveredAt: '2024-03-14T10:30:05Z', readAt: '2024-03-14T11:15:00Z', retryCount: 0, createdAt: '2024-03-14T10:30:00Z' },
    { emailId: generateId(), supplierId, fromAddress: 'info@mueller-components.supplyhub.io', toAddress: 'orders@techfab.fr', subject: 'Order Confirmation #ORD-2024-0847', body: '...', templateId: templates[1].templateId, status: 'delivered', sentAt: '2024-03-13T15:20:00Z', deliveredAt: '2024-03-13T15:20:08Z', retryCount: 0, createdAt: '2024-03-13T15:20:00Z' },
    { emailId: generateId(), supplierId, fromAddress: 'newsletter@mueller-components.supplyhub.io', toAddress: 'subscribers@mueller-components.de', subject: 'Müller Components - March Update', body: '...', templateId: templates[2].templateId, status: 'sent', sentAt: '2024-03-01T09:00:00Z', retryCount: 0, createdAt: '2024-03-01T09:00:00Z' },
    { emailId: generateId(), supplierId, fromAddress: 'info@mueller-components.supplyhub.io', toAddress: 'quality@medtech.it', subject: 'Re: Custom Gasket Specifications', body: '...', status: 'read', sentAt: '2024-03-12T14:45:00Z', deliveredAt: '2024-03-12T14:45:03Z', readAt: '2024-03-12T15:30:00Z', retryCount: 0, createdAt: '2024-03-12T14:45:00Z' },
  ];
  await db.sentEmails.bulkAdd(sentEmails);

  // 11. Seed Site Config
  const siteConfig: DBSiteConfig = {
    supplierId,
    headerBg: '#1a1a1a',
    headerText: '#ffffff',
    footerBg: '#2a2420',
    footerText: '#f5e8d0',
    primaryColor: '#c06d23',
    accentColor: '#9f5320',
    showContactForm: true,
    showProductCatalog: true,
    showCertifications: true,
    companyName: 'Müller Components GmbH',
    tagline: 'Precision Industrial Components Since 1998',
    socialLinks: JSON.stringify([{ platform: 'LinkedIn', url: 'https://linkedin.com/company/mueller-components' }, { platform: 'Twitter', url: 'https://twitter.com/mueller_comp' }]),
    contactEmail: 'info@mueller-components.de',
    contactPhone: '+49 89 1234 5678',
    sslStatus: 'active',
    sslExpiresAt: '2025-01-10T00:00:00Z',
    updatedAt: now,
  };
  await db.siteConfigs.add(siteConfig);

  // 12. Seed API Keys
  const apiKey = generateApiKey();
  const apiKeyRecord: DBApiKey = {
    keyId: generateId(),
    supplierId,
    name: 'Production API Key',
    keyHash: apiKey.hash,
    prefix: apiKey.prefix,
    permissions: JSON.stringify(['read:products', 'write:products', 'read:orders', 'write:orders']),
    createdAt: now,
  };
  await db.apiKeys.add(apiKeyRecord);

  // 13. Seed Subdomain Route
  const route: DBSubdomainRoute = {
    subdomain: 'mueller-components',
    supplierId,
    active: true,
    sslEnabled: true,
    createdAt: now,
  };
  await db.subdomainRoutes.add(route);

  // 14. Seed Activity Logs
  const logs: DBActivityLog[] = [
    { logId: generateId(), supplierId, userId: users[0].userId, userName: 'Hans Müller', action: 'product.updated', entityType: 'product', entityId: products[0].productId, details: JSON.stringify({ field: 'price', oldValue: '€12.00', newValue: '€12.50' }), ipAddress: '185.42.108.22', userAgent: 'Mozilla/5.0', createdAt: '2024-03-15T09:30:00Z' },
    { logId: generateId(), supplierId, userId: users[1].userId, userName: 'Anna Weber', action: 'email.sent', entityType: 'email', entityId: sentEmails[1].emailId, details: JSON.stringify({ to: 'orders@techfab.fr', subject: 'Order Confirmation #ORD-2024-0847' }), ipAddress: '185.42.108.22', userAgent: 'Mozilla/5.0', createdAt: '2024-03-15T08:15:00Z' },
    { logId: generateId(), supplierId, userId: users[2].userId, userName: 'Klaus Fischer', action: 'page.published', entityType: 'page', entityId: pages[1].pageId, details: JSON.stringify({ title: 'Quality Assurance' }), ipAddress: '185.42.108.22', userAgent: 'Mozilla/5.0', createdAt: '2024-03-14T16:45:00Z' },
    { logId: generateId(), supplierId, userId: users[0].userId, userName: 'Hans Müller', action: 'site.header_updated', entityType: 'site', entityId: supplierId, details: JSON.stringify({ field: 'headerBg', newValue: '#1a1a1a' }), ipAddress: '185.42.108.22', userAgent: 'Mozilla/5.0', createdAt: '2024-03-14T14:20:00Z' },
    { logId: generateId(), supplierId, userId: users[1].userId, userName: 'Anna Weber', action: 'certification.uploaded', entityType: 'certification', entityId: certs[2].certId, details: JSON.stringify({ name: 'CE Marking - Machinery Directive' }), ipAddress: '185.42.108.22', userAgent: 'Mozilla/5.0', createdAt: '2024-03-13T11:00:00Z' },
    { logId: generateId(), supplierId, userId: users[0].userId, userName: 'Hans Müller', action: 'user.invited', entityType: 'user', entityId: users[3].userId, details: JSON.stringify({ email: 'maria.s@mueller-components.de', role: 'viewer' }), ipAddress: '185.42.108.22', userAgent: 'Mozilla/5.0', createdAt: '2024-03-12T15:30:00Z' },
  ];
  await db.activityLogs.bulkAdd(logs);

  // ============================================================================
  // QUALITY ASSURANCE DATA
  // ============================================================================

  // 15. Seed Quality Metrics (12 months of data)
  const qualityMetrics: DBQualityMetric[] = [];
  for (let i = 11; i >= 0; i--) {
    const date = new Date();
    date.setMonth(date.getMonth() - i);
    const period = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    qualityMetrics.push({
      metricId: generateId(),
      supplierId,
      period,
      periodType: 'monthly',
      defectRate: 1.2 + Math.random() * 0.8,
      onTimeDelivery: 94 + Math.random() * 4,
      complianceScore: 88 + Math.random() * 8,
      responseTime: 18 + Math.random() * 12,
      firstPassYield: 96 + Math.random() * 3,
      customerComplaints: Math.floor(Math.random() * 4),
      auditScore: 85 + Math.random() * 10,
      overallScore: 87 + Math.random() * 10,
      recordedAt: date.toISOString(),
    });
  }
  await db.qualityMetrics.bulkAdd(qualityMetrics);

  // 16. Seed Inspections
  const inspections: DBInspection[] = [
    {
      inspectionId: generateId(),
      supplierId,
      title: 'Annual ISO 9001 Surveillance Audit',
      type: 'audit',
      scheduledDate: '2024-06-15',
      completedDate: '2024-06-15',
      inspector: 'TÜV Rheinland - Dr. Schmidt',
      status: 'completed',
      scope: 'Full QMS audit including production, quality control, and documentation',
      findings: JSON.stringify([
        { area: 'Document Control', severity: 'minor', description: 'Some work instructions not updated to latest revision' },
        { area: 'Production', severity: 'observation', description: 'Excellent 5S implementation observed' },
      ]),
      conclusion: 'pass',
      correctiveActions: JSON.stringify([]),
      attachments: JSON.stringify(['/files/audit_2024_06.pdf']),
      notes: 'Supplier demonstrates strong commitment to quality management. Minor findings addressed promptly.',
      createdAt: '2024-06-10T09:00:00Z',
      updatedAt: '2024-06-15T17:00:00Z',
    },
    {
      inspectionId: generateId(),
      supplierId,
      title: 'Incoming Material Inspection - Batch #B-2024-0847',
      type: 'incoming',
      scheduledDate: '2024-03-12',
      completedDate: '2024-03-12',
      inspector: 'Anna Weber',
      status: 'completed',
      scope: 'Dimensional and material verification of steel bearings batch',
      findings: JSON.stringify([
        { area: 'Dimensions', severity: 'pass', description: 'All measurements within tolerance' },
        { area: 'Material', severity: 'pass', description: 'Material certificate verified' },
      ]),
      conclusion: 'pass',
      correctiveActions: JSON.stringify([]),
      attachments: JSON.stringify([]),
      notes: 'Batch accepted. All specifications met.',
      createdAt: '2024-03-12T08:00:00Z',
      updatedAt: '2024-03-12T14:00:00Z',
    },
    {
      inspectionId: generateId(),
      supplierId,
      title: 'Final Product Inspection - CNC Machined Parts',
      type: 'final',
      scheduledDate: '2024-03-18',
      completedDate: '2024-03-18',
      inspector: 'Klaus Fischer',
      status: 'completed',
      scope: 'Final inspection of 500 CNC machined aluminum components',
      findings: JSON.stringify([
        { area: 'Surface Finish', severity: 'minor', description: '3 parts out of 500 showed minor surface defects' },
        { area: 'Dimensions', severity: 'pass', description: 'All critical dimensions within spec' },
      ]),
      conclusion: 'conditional_pass',
      correctiveActions: JSON.stringify(['capa-001']),
      attachments: JSON.stringify(['/files/inspection_2024_03_18.pdf']),
      notes: 'Batch conditionally accepted. 3 defective parts quarantined. CAPA initiated for surface finish improvement.',
      createdAt: '2024-03-18T09:00:00Z',
      updatedAt: '2024-03-18T16:00:00Z',
    },
    {
      inspectionId: generateId(),
      supplierId,
      title: 'Process Audit - Rubber Seals Production Line',
      type: 'in_process',
      scheduledDate: '2024-04-05',
      inspector: 'Sarah Mitchell',
      status: 'scheduled',
      scope: 'In-process audit of rubber seal molding and curing process',
      findings: JSON.stringify([]),
      conclusion: 'pending',
      correctiveActions: JSON.stringify([]),
      attachments: JSON.stringify([]),
      notes: 'Scheduled audit to verify process controls for new rubber seal product line.',
      createdAt: '2024-03-20T10:00:00Z',
      updatedAt: '2024-03-20T10:00:00Z',
    },
  ];
  await db.inspections.bulkAdd(inspections);

  // 17. Seed NCR Reports
  const ncrReports: DBNCRReport[] = [
    {
      ncrId: generateId(),
      supplierId,
      ncrNumber: 'NCR-2024-001',
      title: 'Surface Finish Defects on CNC Machined Parts',
      description: 'During final inspection of batch #B-2024-0847, 3 out of 500 aluminum components showed surface finish defects exceeding Ra 1.6μm specification (actual: Ra 2.1μm).',
      severity: 'minor',
      category: 'product',
      affectedProduct: 'Precision CNC Machining Service',
      affectedBatch: 'B-2024-0847',
      reportedBy: 'Klaus Fischer',
      reportedDate: '2024-03-18',
      dueDate: '2024-04-02',
      status: 'corrective_action',
      rootCause: 'Worn cutting tool not replaced according to maintenance schedule. Tool life tracking system not properly implemented.',
      correctiveAction: '1. Replace worn cutting tools immediately\n2. Implement tool life tracking system\n3. Update preventive maintenance schedule\n4. Train operators on tool inspection procedures',
      preventiveAction: 'Monthly tool life audit. Automated alerts when tools approach end of life.',
      verificationResult: '',
      createdAt: '2024-03-18T16:30:00Z',
      updatedAt: '2024-03-25T10:00:00Z',
    },
    {
      ncrId: generateId(),
      supplierId,
      ncrNumber: 'NCR-2024-002',
      title: 'Late Delivery - Order #ORD-2024-0723',
      description: 'Order #ORD-2024-0723 for industrial bearings was delivered 5 days late due to raw material shortage. Customer complaint received.',
      severity: 'major',
      category: 'delivery',
      affectedProduct: 'Industrial Grade Steel Bearings',
      reportedBy: 'Anna Weber',
      reportedDate: '2024-02-28',
      dueDate: '2024-03-14',
      status: 'closed',
      rootCause: 'Single-source supplier for chrome steel experienced production delay. No backup supplier qualified.',
      correctiveAction: '1. Qualify second source supplier for chrome steel\n2. Increase safety stock from 2 weeks to 4 weeks\n3. Implement supplier risk monitoring system',
      preventiveAction: 'Quarterly supplier risk assessment. Dual-source strategy for critical materials.',
      verificationResult: 'Second supplier qualified on 2024-03-10. Safety stock increased. No further delivery delays.',
      closedBy: 'Hans Müller',
      closedAt: '2024-03-15T14:00:00Z',
      createdAt: '2024-02-28T09:00:00Z',
      updatedAt: '2024-03-15T14:00:00Z',
    },
    {
      ncrId: generateId(),
      supplierId,
      ncrNumber: 'NCR-2024-003',
      title: 'Documentation Gap - Work Instructions Not Updated',
      description: 'During ISO 9001 surveillance audit, it was found that 3 work instructions for rubber seal production were not updated to reflect process changes implemented in January 2024.',
      severity: 'minor',
      category: 'documentation',
      reportedBy: 'Dr. Schmidt (TÜV Rheinland)',
      reportedDate: '2024-06-15',
      dueDate: '2024-06-30',
      status: 'open',
      rootCause: '',
      correctiveAction: '',
      preventiveAction: '',
      verificationResult: '',
      createdAt: '2024-06-15T17:00:00Z',
      updatedAt: '2024-06-15T17:00:00Z',
    },
  ];
  await db.ncrReports.bulkAdd(ncrReports);

  // 18. Seed CAPA Actions
  const capaActions: DBCAPAAction[] = [
    {
      capaId: generateId(),
      supplierId,
      capaNumber: 'CAPA-2024-001',
      title: 'Implement Tool Life Tracking System',
      description: 'Develop and implement automated tool life tracking system to prevent surface finish defects caused by worn cutting tools.',
      type: 'corrective',
      source: 'ncr',
      sourceRefId: 'ncr-001',
      priority: 'high',
      assignedTo: 'Klaus Fischer',
      dueDate: '2024-04-15',
      status: 'in_progress',
      effectivenessCheck: '',
      createdAt: '2024-03-20T09:00:00Z',
      updatedAt: '2024-03-25T10:00:00Z',
    },
    {
      capaId: generateId(),
      supplierId,
      capaNumber: 'CAPA-2024-002',
      title: 'Qualify Second Source Supplier for Chrome Steel',
      description: 'Identify, audit, and qualify a second source supplier for chrome steel to mitigate single-source risk.',
      type: 'preventive',
      source: 'ncr',
      sourceRefId: 'ncr-002',
      priority: 'critical',
      assignedTo: 'Hans Müller',
      dueDate: '2024-03-31',
      status: 'verified',
      effectivenessCheck: 'Second supplier (SteelWorks AG) qualified on 2024-03-10. First trial order completed successfully on 2024-03-20. Material quality meets specifications.',
      completedDate: '2024-03-10T16:00:00Z',
      verifiedBy: 'Anna Weber',
      verifiedDate: '2024-03-15T14:00:00Z',
      createdAt: '2024-03-01T09:00:00Z',
      updatedAt: '2024-03-15T14:00:00Z',
    },
    {
      capaId: generateId(),
      supplierId,
      capaNumber: 'CAPA-2024-003',
      title: 'Update Rubber Seal Work Instructions',
      description: 'Update 3 work instructions for rubber seal production to reflect January 2024 process changes.',
      type: 'corrective',
      source: 'audit',
      sourceRefId: 'inspection-001',
      priority: 'medium',
      assignedTo: 'Anna Weber',
      dueDate: '2024-06-30',
      status: 'open',
      effectivenessCheck: '',
      createdAt: '2024-06-16T09:00:00Z',
      updatedAt: '2024-06-16T09:00:00Z',
    },
    {
      capaId: generateId(),
      supplierId,
      capaNumber: 'CAPA-2024-004',
      title: 'Implement Monthly Tool Life Audit Program',
      description: 'Establish monthly audit program to verify tool life management and prevent surface finish issues.',
      type: 'preventive',
      source: 'internal',
      priority: 'medium',
      assignedTo: 'Klaus Fischer',
      dueDate: '2024-05-01',
      status: 'completed',
      effectivenessCheck: 'First monthly audit completed on 2024-04-30. All tools within life limits. No surface finish defects detected in April production.',
      completedDate: '2024-04-30T16:00:00Z',
      createdAt: '2024-03-25T10:00:00Z',
      updatedAt: '2024-04-30T16:00:00Z',
    },
  ];
  await db.capaActions.bulkAdd(capaActions);

  // 19. Seed Scorecards
  const scorecards: DBScorecard[] = [
    {
      scorecardId: generateId(),
      supplierId,
      period: '2024-Q1',
      periodType: 'quarterly',
      qualityScore: 92,
      deliveryScore: 88,
      responsivenessScore: 94,
      complianceScore: 96,
      innovationScore: 85,
      overallScore: 91,
      grade: 'A',
      trend: 'improving',
      comments: 'Strong performance across all categories. Delivery score impacted by single-source material issue in February. Corrective actions implemented and verified. Quality metrics show consistent improvement.',
      issuedAt: '2024-04-10T10:00:00Z',
      issuedBy: 'Sarah Mitchell',
    },
    {
      scorecardId: generateId(),
      supplierId,
      period: '2023-Q4',
      periodType: 'quarterly',
      qualityScore: 89,
      deliveryScore: 92,
      responsivenessScore: 91,
      complianceScore: 94,
      innovationScore: 83,
      overallScore: 90,
      grade: 'A',
      trend: 'stable',
      comments: 'Consistent performance. Minor quality issues in November addressed promptly. Strong compliance record maintained.',
      issuedAt: '2024-01-15T10:00:00Z',
      issuedBy: 'Sarah Mitchell',
    },
    {
      scorecardId: generateId(),
      supplierId,
      period: '2023-Q3',
      periodType: 'quarterly',
      qualityScore: 87,
      deliveryScore: 90,
      responsivenessScore: 89,
      complianceScore: 93,
      innovationScore: 82,
      overallScore: 88,
      grade: 'B',
      trend: 'stable',
      comments: 'Good overall performance. Areas for improvement: response time to quality inquiries, innovation in process optimization.',
      issuedAt: '2023-10-12T10:00:00Z',
      issuedBy: 'David Chen',
    },
  ];
  await db.scorecards.bulkAdd(scorecards);

  // 20. Seed Quality Documents
  const qualityDocuments: DBQualityDocument[] = [
    {
      docId: generateId(),
      supplierId,
      title: 'Quality Manual',
      docNumber: 'QM-001',
      type: 'procedure',
      revision: 'Rev. 5',
      status: 'approved',
      owner: 'Hans Müller',
      approvedBy: 'Hans Müller',
      approvedAt: '2024-01-15T10:00:00Z',
      nextReviewDate: '2025-01-15',
      fileUrl: '/files/quality_manual_rev5.pdf',
      fileSize: 2_450_000,
      createdAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-01-15T10:00:00Z',
    },
    {
      docId: generateId(),
      supplierId,
      title: 'Incoming Inspection Procedure',
      docNumber: 'QP-012',
      type: 'procedure',
      revision: 'Rev. 3',
      status: 'approved',
      owner: 'Anna Weber',
      approvedBy: 'Hans Müller',
      approvedAt: '2024-02-01T10:00:00Z',
      nextReviewDate: '2025-02-01',
      fileUrl: '/files/incoming_inspection_rev3.pdf',
      fileSize: 890_000,
      createdAt: '2024-02-01T10:00:00Z',
      updatedAt: '2024-02-01T10:00:00Z',
    },
    {
      docId: generateId(),
      supplierId,
      title: 'CNC Machining Work Instruction',
      docNumber: 'WI-023',
      type: 'work_instruction',
      revision: 'Rev. 7',
      status: 'approved',
      owner: 'Klaus Fischer',
      approvedBy: 'Anna Weber',
      approvedAt: '2024-03-10T10:00:00Z',
      nextReviewDate: '2024-09-10',
      fileUrl: '/files/cnc_machining_wi_rev7.pdf',
      fileSize: 1_230_000,
      createdAt: '2024-03-10T10:00:00Z',
      updatedAt: '2024-03-10T10:00:00Z',
    },
    {
      docId: generateId(),
      supplierId,
      title: 'Non-Conformance Report Form',
      docNumber: 'QF-008',
      type: 'form',
      revision: 'Rev. 2',
      status: 'approved',
      owner: 'Anna Weber',
      approvedBy: 'Hans Müller',
      approvedAt: '2023-11-15T10:00:00Z',
      nextReviewDate: '2024-11-15',
      fileUrl: '/files/ncr_form_rev2.pdf',
      fileSize: 245_000,
      createdAt: '2023-11-15T10:00:00Z',
      updatedAt: '2023-11-15T10:00:00Z',
    },
    {
      docId: generateId(),
      supplierId,
      title: 'Rubber Seal Material Specification',
      docNumber: 'QS-045',
      type: 'specification',
      revision: 'Rev. 1',
      status: 'under_review',
      owner: 'Klaus Fischer',
      nextReviewDate: '2024-12-01',
      fileUrl: '/files/rubber_seal_spec_rev1.pdf',
      fileSize: 567_000,
      createdAt: '2024-03-15T10:00:00Z',
      updatedAt: '2024-03-20T14:00:00Z',
    },
  ];
  await db.qualityDocuments.bulkAdd(qualityDocuments);

  // ============================================================================
  // MANPOWER SOURCING DATA
  // ============================================================================

  // 21. Seed Expert Skills
  const expertSkills: DBExpertSkill[] = [
    { skillId: 'sk-001', name: 'CNC Programming', category: 'Manufacturing', description: 'CNC machine programming and operation' },
    { skillId: 'sk-002', name: 'Quality Management', category: 'Quality', description: 'ISO 9001, Six Sigma, quality systems' },
    { skillId: 'sk-003', name: 'Mechanical Design', category: 'Engineering', description: 'CAD/CAM, mechanical system design' },
    { skillId: 'sk-004', name: 'Supply Chain Management', category: 'Management', description: 'Logistics, procurement, inventory' },
    { skillId: 'sk-005', name: 'Welding Inspection', category: 'Quality', description: 'AWS, ASME welding standards' },
    { skillId: 'sk-006', name: 'Project Management', category: 'Management', description: 'PMP, agile, project planning' },
    { skillId: 'sk-007', name: 'Materials Engineering', category: 'Engineering', description: 'Metallurgy, material selection' },
    { skillId: 'sk-008', name: 'Lean Manufacturing', category: 'Manufacturing', description: 'Lean, Six Sigma, process optimization' },
    { skillId: 'sk-009', name: 'Automation', category: 'Engineering', description: 'PLC, robotics, industrial automation' },
    { skillId: 'sk-010', name: 'Technical Drawing', category: 'Engineering', description: 'GD&T, technical documentation' },
  ];
  await db.expertSkills.bulkAdd(expertSkills);

  // 22. Seed Technical Experts
  const experts: DBExpert[] = [
    {
      expertId: 'exp-001',
      firstName: 'Thomas',
      lastName: 'Weber',
      email: 'thomas.weber@experts.supplyhub.io',
      phone: '+49 171 234 5678',
      photoUrl: '/images/experts/weber.jpg',
      title: 'Senior CNC Programming Specialist',
      bio: '20+ years experience in CNC programming for aerospace and automotive industries. Expert in Siemens 840D and Fanuc controls. Certified applications engineer.',
      location: 'Munich, Germany',
      region: 'local',
      nationality: 'German',
      languages: JSON.stringify(['German', 'English']),
      hourlyRate: 125,
      currency: 'EUR',
      availability: 'available',
      yearsExperience: 22,
      education: JSON.stringify([
        { degree: 'M.Sc. Mechanical Engineering', institution: 'TU Munich', year: 2002 },
        { degree: 'B.Sc. Mechanical Engineering', institution: 'TU Munich', year: 2000 },
      ]),
      certifications: JSON.stringify(['Siemens Certified Applications Engineer', 'CNC Programming Level 3', 'ISO 9001 Lead Auditor']),
      skills: JSON.stringify(['sk-001', 'sk-003', 'sk-010']),
      rating: 4.9,
      totalAssignments: 47,
      verified: true,
      createdAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-03-01T10:00:00Z',
    },
    {
      expertId: 'exp-002',
      firstName: 'Maria',
      lastName: 'Rossi',
      email: 'maria.rossi@experts.supplyhub.io',
      phone: '+39 333 456 7890',
      photoUrl: '/images/experts/rossi.jpg',
      title: 'Quality Management Consultant',
      bio: 'ISO 9001, 14001, and IATF 16949 lead auditor with 15 years of experience across automotive and medical device industries. Specialized in quality system implementation and continuous improvement.',
      location: 'Milan, Italy',
      region: 'regional',
      nationality: 'Italian',
      languages: JSON.stringify(['Italian', 'English', 'German']),
      hourlyRate: 110,
      currency: 'EUR',
      availability: 'available',
      yearsExperience: 15,
      education: JSON.stringify([
        { degree: 'M.Sc. Industrial Engineering', institution: 'Politecnico di Milano', year: 2008 },
      ]),
      certifications: JSON.stringify(['ISO 9001 Lead Auditor', 'IATF 16949 Auditor', 'Six Sigma Black Belt', 'ASQ CQE']),
      skills: JSON.stringify(['sk-002', 'sk-008']),
      rating: 4.8,
      totalAssignments: 32,
      verified: true,
      createdAt: '2024-01-20T10:00:00Z',
      updatedAt: '2024-03-05T10:00:00Z',
    },
    {
      expertId: 'exp-003',
      firstName: 'James',
      lastName: 'Mitchell',
      email: 'james.mitchell@experts.supplyhub.io',
      phone: '+1 415 555 0123',
      photoUrl: '/images/experts/mitchell.jpg',
      title: 'Materials Engineering Specialist',
      bio: 'PhD in Materials Science with expertise in metallurgy and advanced materials for aerospace applications. Published researcher with 12 patents.',
      location: 'San Francisco, USA',
      region: 'international',
      nationality: 'American',
      languages: JSON.stringify(['English', 'French']),
      hourlyRate: 180,
      currency: 'USD',
      availability: 'engaged',
      yearsExperience: 18,
      education: JSON.stringify([
        { degree: 'PhD Materials Science', institution: 'MIT', year: 2005 },
        { degree: 'M.Sc. Metallurgical Engineering', institution: 'Stanford', year: 2001 },
      ]),
      certifications: JSON.stringify(['ASM International Fellow', 'AWS CWI', 'NACE Level 3']),
      skills: JSON.stringify(['sk-007', 'sk-005']),
      rating: 5.0,
      totalAssignments: 28,
      verified: true,
      createdAt: '2024-02-01T10:00:00Z',
      updatedAt: '2024-03-10T10:00:00Z',
    },
    {
      expertId: 'exp-004',
      firstName: 'Hiroshi',
      lastName: 'Tanaka',
      email: 'hiroshi.tanaka@experts.supplyhub.io',
      phone: '+81 90 1234 5678',
      photoUrl: '/images/experts/tanaka.jpg',
      title: 'Lean Manufacturing Expert',
      bio: 'Former Toyota Production System trainer with 25 years in automotive manufacturing. Implemented lean systems across 50+ facilities in Asia and Europe.',
      location: 'Tokyo, Japan',
      region: 'international',
      nationality: 'Japanese',
      languages: JSON.stringify(['Japanese', 'English']),
      hourlyRate: 160,
      currency: 'USD',
      availability: 'available',
      yearsExperience: 25,
      education: JSON.stringify([
        { degree: 'M.Sc. Industrial Engineering', institution: 'University of Tokyo', year: 1998 },
      ]),
      certifications: JSON.stringify(['TPS Master Trainer', 'Six Sigma Master Black Belt', 'Shingo Prize Examiner']),
      skills: JSON.stringify(['sk-008', 'sk-006']),
      rating: 4.9,
      totalAssignments: 63,
      verified: true,
      createdAt: '2024-02-10T10:00:00Z',
      updatedAt: '2024-03-15T10:00:00Z',
    },
    {
      expertId: 'exp-005',
      firstName: 'Sophie',
      lastName: 'Laurent',
      email: 'sophie.laurent@experts.supplyhub.io',
      phone: '+33 6 12 34 56 78',
      photoUrl: '/images/experts/laurent.jpg',
      title: 'Automation & Robotics Engineer',
      bio: 'Expert in industrial automation, PLC programming, and robotics integration. Specialized in Industry 4.0 implementations and smart factory solutions.',
      location: 'Lyon, France',
      region: 'regional',
      nationality: 'French',
      languages: JSON.stringify(['French', 'English', 'German']),
      hourlyRate: 135,
      currency: 'EUR',
      availability: 'available',
      yearsExperience: 12,
      education: JSON.stringify([
        { degree: 'M.Sc. Automation Engineering', institution: 'INSA Lyon', year: 2011 },
      ]),
      certifications: JSON.stringify(['Siemens TIA Portal Certified', 'ABB Robotics Programmer', 'Industry 4.0 Specialist']),
      skills: JSON.stringify(['sk-009', 'sk-001']),
      rating: 4.7,
      totalAssignments: 19,
      verified: true,
      createdAt: '2024-02-15T10:00:00Z',
      updatedAt: '2024-03-12T10:00:00Z',
    },
    {
      expertId: 'exp-006',
      firstName: 'Klaus',
      lastName: 'Bauer',
      email: 'klaus.bauer@experts.supplyhub.io',
      phone: '+49 151 987 6543',
      photoUrl: '/images/experts/bauer.jpg',
      title: 'Supply Chain Management Consultant',
      bio: '20 years in supply chain optimization for manufacturing companies. Expert in procurement strategies, vendor management, and logistics optimization.',
      location: 'Stuttgart, Germany',
      region: 'local',
      nationality: 'German',
      languages: JSON.stringify(['German', 'English']),
      hourlyRate: 140,
      currency: 'EUR',
      availability: 'on_leave',
      yearsExperience: 20,
      education: JSON.stringify([
        { degree: 'M.Sc. Business Administration', institution: 'University of Stuttgart', year: 2003 },
      ]),
      certifications: JSON.stringify(['CSCP - Certified Supply Chain Professional', 'CPIM', 'PMP']),
      skills: JSON.stringify(['sk-004', 'sk-006']),
      rating: 4.6,
      totalAssignments: 38,
      verified: true,
      createdAt: '2024-01-25T10:00:00Z',
      updatedAt: '2024-02-28T10:00:00Z',
    },
  ];
  await db.experts.bulkAdd(experts);

  // 23. Seed Sourcing Requests
  const sourcingRequests: DBSourcingRequest[] = [
    {
      requestId: 'sr-001',
      requestNumber: 'SR-2024-001',
      supplierId,
      title: 'CNC Programming Support for New Production Line',
      description: 'We are launching a new 5-axis CNC machining center and need an experienced programmer to set up the machine, develop initial programs, and train our operators. Must have Siemens 840D experience.',
      skillsRequired: JSON.stringify(['sk-001', 'sk-003']),
      experienceRequired: 10,
      region: 'local',
      duration: '3 months',
      startDate: '2024-04-15',
      urgency: 'high',
      budget: 45000,
      currency: 'EUR',
      status: 'shortlisted',
      candidatesShortlisted: 3,
      candidatesInterviewed: 2,
      createdBy: 'Hans Müller',
      createdAt: '2024-03-01T09:00:00Z',
      updatedAt: '2024-03-18T14:00:00Z',
    },
    {
      requestId: 'sr-002',
      requestNumber: 'SR-2024-002',
      supplierId,
      title: 'Quality Management System Implementation',
      description: 'Need a quality management consultant to help implement IATF 16949 across our automotive division. Must have experience with automotive suppliers and audit preparation.',
      skillsRequired: JSON.stringify(['sk-002']),
      experienceRequired: 8,
      region: 'regional',
      duration: '6 months',
      startDate: '2024-05-01',
      urgency: 'medium',
      budget: 65000,
      currency: 'EUR',
      status: 'open',
      candidatesShortlisted: 5,
      candidatesInterviewed: 0,
      createdBy: 'Anna Weber',
      createdAt: '2024-03-10T10:00:00Z',
      updatedAt: '2024-03-10T10:00:00Z',
    },
    {
      requestId: 'sr-003',
      requestNumber: 'SR-2024-003',
      supplierId,
      title: 'Lean Manufacturing Transformation',
      description: 'Seeking a lean manufacturing expert to lead our operational excellence initiative. Must have TPS experience and proven track record in reducing waste and improving productivity.',
      skillsRequired: JSON.stringify(['sk-008', 'sk-006']),
      experienceRequired: 15,
      region: 'any',
      duration: '12 months',
      startDate: '2024-06-01',
      urgency: 'medium',
      budget: 180000,
      currency: 'EUR',
      status: 'interview',
      candidatesShortlisted: 4,
      candidatesInterviewed: 2,
      createdBy: 'Hans Müller',
      createdAt: '2024-02-20T09:00:00Z',
      updatedAt: '2024-03-15T16:00:00Z',
    },
    {
      requestId: 'sr-004',
      requestNumber: 'SR-2024-004',
      supplierId,
      title: 'Materials Testing Lab Setup',
      description: 'Need a materials engineering specialist to help set up our new materials testing laboratory. Must have experience with metallurgical testing equipment and lab management.',
      skillsRequired: JSON.stringify(['sk-007']),
      experienceRequired: 12,
      region: 'international',
      duration: '4 months',
      startDate: '2024-07-01',
      urgency: 'low',
      budget: 72000,
      currency: 'USD',
      status: 'draft',
      candidatesShortlisted: 0,
      candidatesInterviewed: 0,
      createdBy: 'Klaus Fischer',
      createdAt: '2024-03-18T11:00:00Z',
      updatedAt: '2024-03-18T11:00:00Z',
    },
  ];
  await db.sourcingRequests.bulkAdd(sourcingRequests);

  // 24. Seed Expert Contracts
  const contracts: DBExpertContract[] = [
    {
      contractId: 'ctr-001',
      contractNumber: 'CTR-2024-001',
      supplierId,
      expertId: 'exp-002',
      requestId: 'sr-002',
      title: 'Quality Management Consulting Services',
      scope: 'IATF 16949 implementation consulting, audit preparation, and team training',
      startDate: '2024-01-15',
      endDate: '2024-04-15',
      hourlyRate: 110,
      currency: 'EUR',
      estimatedHours: 480,
      totalValue: 52800,
      status: 'active',
      workLocation: 'hybrid',
      signedByExpert: 'Maria Rossi',
      signedBySupplier: 'Hans Müller',
      signedAt: '2024-01-10T10:00:00Z',
      createdAt: '2024-01-10T10:00:00Z',
      updatedAt: '2024-01-15T10:00:00Z',
    },
    {
      contractId: 'ctr-002',
      contractNumber: 'CTR-2023-008',
      supplierId,
      expertId: 'exp-001',
      requestId: 'sr-001',
      title: 'CNC Programming Training Program',
      scope: 'Develop and deliver CNC programming training for 12 operators on new 5-axis machines',
      startDate: '2023-10-01',
      endDate: '2023-12-31',
      hourlyRate: 125,
      currency: 'EUR',
      estimatedHours: 320,
      totalValue: 40000,
      status: 'completed',
      workLocation: 'on-site',
      signedByExpert: 'Thomas Weber',
      signedBySupplier: 'Hans Müller',
      signedAt: '2023-09-25T10:00:00Z',
      createdAt: '2023-09-25T10:00:00Z',
      updatedAt: '2023-12-31T17:00:00Z',
    },
  ];
  await db.expertContracts.bulkAdd(contracts);

  // 25. Seed Expert Assignments
  const assignments: DBExpertAssignment[] = [
    {
      assignmentId: 'asg-001',
      expertId: 'exp-002',
      supplierId,
      contractId: 'ctr-001',
      title: 'IATF 16949 Implementation',
      startDate: '2024-01-15',
      endDate: '2024-04-15',
      status: 'active',
      hoursLogged: 156,
      createdAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-03-18T10:00:00Z',
    },
    {
      assignmentId: 'asg-002',
      expertId: 'exp-001',
      supplierId,
      contractId: 'ctr-002',
      title: 'CNC Training Program',
      startDate: '2023-10-01',
      endDate: '2023-12-31',
      status: 'completed',
      hoursLogged: 318,
      performanceRating: 5.0,
      feedback: 'Excellent training program. All operators achieved certification. Highly recommend for future projects.',
      createdAt: '2023-10-01T10:00:00Z',
      updatedAt: '2023-12-31T17:00:00Z',
    },
  ];
  await db.expertAssignments.bulkAdd(assignments);

  console.log('[DB] Database seeded successfully');
  console.log('[DB] Tables populated:', {
    suppliers: await db.suppliers.count(),
    users: await db.users.count(),
    products: await db.products.count(),
    certifications: await db.certifications.count(),
    messages: await db.messages.count(),
    pages: await db.pages.count(),
    banners: await db.banners.count(),
    menuItems: await db.menuItems.count(),
    emailTemplates: await db.emailTemplates.count(),
    sentEmails: await db.sentEmails.count(),
    siteConfigs: await db.siteConfigs.count(),
    apiKeys: await db.apiKeys.count(),
    subdomainRoutes: await db.subdomainRoutes.count(),
    activityLogs: await db.activityLogs.count(),
    qualityMetrics: await db.qualityMetrics.count(),
    inspections: await db.inspections.count(),
    ncrReports: await db.ncrReports.count(),
    capaActions: await db.capaActions.count(),
    scorecards: await db.scorecards.count(),
    qualityDocuments: await db.qualityDocuments.count(),
    experts: await db.experts.count(),
    expertSkills: await db.expertSkills.count(),
    sourcingRequests: await db.sourcingRequests.count(),
    expertContracts: await db.expertContracts.count(),
    expertAssignments: await db.expertAssignments.count(),
  });
}
