import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Supplier {
  id: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  industry: string;
  companySize: string;
  description: string;
  website: string;
  taxId: string;
  status: 'pending' | 'approved' | 'suspended';
  registeredAt: string;
  subdomain: string;
  brandColor: string;
  logoText: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  description: string;
  characteristics: string[];
  specifications: Record<string, string>;
  price: string;
  minOrderQuantity: string;
  leadTime: string;
  images: string[];
  status: 'draft' | 'active' | 'under_review';
  createdAt: string;
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  fileName: string;
  status: 'pending' | 'verified' | 'expired';
}

export interface Message {
  id: string;
  sender: 'supplier' | 'coordinator';
  senderName: string;
  content: string;
  timestamp: string;
  read: boolean;
}

// CMS Types
export interface CMSPage {
  id: string;
  title: string;
  slug: string;
  content: string;
  status: 'published' | 'draft';
  updatedAt: string;
  author: string;
}

export interface CMSBanner {
  id: string;
  title: string;
  subtitle: string;
  ctaText: string;
  ctaLink: string;
  active: boolean;
  position: 'hero' | 'sidebar' | 'footer';
}

export interface CMSMenuItem {
  id: string;
  label: string;
  link: string;
  type: 'page' | 'external' | 'product';
  order: number;
}

// Email Types
export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body: string;
  type: 'inquiry' | 'order' | 'newsletter' | 'custom';
  createdAt: string;
}

export interface SentEmail {
  id: string;
  to: string;
  subject: string;
  templateId?: string;
  status: 'sent' | 'delivered' | 'failed' | 'read';
  sentAt: string;
}

// Site Config
export interface SiteConfig {
  headerBg: string;
  headerText: string;
  footerBg: string;
  footerText: string;
  primaryColor: string;
  accentColor: string;
  showContactForm: boolean;
  showProductCatalog: boolean;
  showCertifications: boolean;
  companyName: string;
  tagline: string;
  socialLinks: { platform: string; url: string }[];
  contactEmail: string;
  contactPhone: string;
}

// User/Roles
export interface PortalUser {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'editor' | 'viewer';
  status: 'active' | 'invited' | 'suspended';
  lastActive: string;
}

interface AppState {
  supplier: Supplier | null;
  products: Product[];
  certifications: Certification[];
  messages: Message[];
  isRegistered: boolean;
  // CMS
  pages: CMSPage[];
  banners: CMSBanner[];
  menuItems: CMSMenuItem[];
  // Email
  emailTemplates: EmailTemplate[];
  sentEmails: SentEmail[];
  // Site
  siteConfig: SiteConfig;
  // Users
  portalUsers: PortalUser[];
  // Actions
  setSupplier: (supplier: Supplier) => void;
  addProduct: (product: Product) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addCertification: (cert: Certification) => void;
  deleteCertification: (id: string) => void;
  addMessage: (msg: Message) => void;
  markMessageRead: (id: string) => void;
  completeRegistration: () => void;
  // CMS actions
  addPage: (page: CMSPage) => void;
  updatePage: (id: string, page: Partial<CMSPage>) => void;
  deletePage: (id: string) => void;
  addBanner: (banner: CMSBanner) => void;
  updateBanner: (id: string, banner: Partial<CMSBanner>) => void;
  deleteBanner: (id: string) => void;
  setMenuItems: (items: CMSMenuItem[]) => void;
  // Email actions
  addEmailTemplate: (t: EmailTemplate) => void;
  deleteEmailTemplate: (id: string) => void;
  sendEmail: (email: SentEmail) => void;
  // Site actions
  updateSiteConfig: (config: Partial<SiteConfig>) => void;
  // User actions
  addPortalUser: (user: PortalUser) => void;
  updatePortalUser: (id: string, user: Partial<PortalUser>) => void;
  deletePortalUser: (id: string) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [supplier, setSupplierState] = useState<Supplier | null>(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [products, setProducts] = useState<Product[]>([
    {
      id: '1', name: 'Industrial Grade Steel Bearings', category: 'Mechanical Components',
      description: 'High-precision steel bearings designed for heavy-duty industrial applications. Manufactured with premium chrome steel for maximum durability and performance.',
      characteristics: ['High load capacity', 'Low friction coefficient', 'Corrosion resistant', 'Temperature resistant up to 150°C'],
      specifications: { 'Inner Diameter': '25mm', 'Outer Diameter': '52mm', 'Width': '15mm', 'Material': 'Chrome Steel GCr15', 'Precision Class': 'P6', 'Dynamic Load Rating': '16.8 kN' },
      price: '€12.50', minOrderQuantity: '100 units', leadTime: '2-3 weeks', images: [], status: 'active', createdAt: '2024-01-15',
    },
    {
      id: '2', name: 'Precision CNC Machining Service', category: 'Manufacturing Services',
      description: 'Full-service CNC machining including milling, turning, and multi-axis operations. ISO 9001 certified facility with tight tolerance capabilities.',
      characteristics: ['Multi-axis capability', 'Tight tolerances (±0.005mm)', 'Various material support', 'Rapid prototyping available'],
      specifications: { 'Max Part Size': '500x400x300mm', 'Tolerance': '±0.005mm', 'Surface Finish': 'Ra 0.8μm', 'Materials': 'Aluminum, Steel, Titanium, Brass', 'Certifications': 'ISO 9001, AS9100' },
      price: 'From €45/hour', minOrderQuantity: '1 piece', leadTime: '5-15 business days', images: [], status: 'active', createdAt: '2024-02-01',
    },
    {
      id: '3', name: 'Custom Rubber Seals & Gaskets', category: 'Sealing Solutions',
      description: 'Custom-manufactured rubber seals and gaskets for automotive, industrial, and marine applications.',
      characteristics: ['Custom profiles', 'Chemical resistant', 'UV stable options', 'Food-grade available'],
      specifications: { 'Materials': 'NBR, EPDM, Silicone, FKM', 'Hardness Range': '30-90 Shore A', 'Temperature Range': '-40°C to +250°C', 'Compliance': 'REACH, RoHS, FDA' },
      price: 'From €0.15/piece', minOrderQuantity: '500 pieces', leadTime: '3-4 weeks', images: [], status: 'under_review', createdAt: '2024-03-10',
    },
  ]);
  const [certifications, setCertifications] = useState<Certification[]>([
    { id: '1', name: 'ISO 9001:2015', issuer: 'TÜV Rheinland', issueDate: '2023-06-15', expiryDate: '2026-06-14', fileName: 'ISO_9001_Certificate.pdf', status: 'verified' },
    { id: '2', name: 'ISO 14001:2015', issuer: 'Bureau Veritas', issueDate: '2023-09-01', expiryDate: '2026-08-31', fileName: 'ISO_14001_Certificate.pdf', status: 'verified' },
    { id: '3', name: 'CE Marking - Machinery Directive', issuer: 'Self-declaration', issueDate: '2024-01-10', expiryDate: '2025-01-09', fileName: 'CE_Declaration.pdf', status: 'pending' },
  ]);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', sender: 'coordinator', senderName: 'Sarah Mitchell', content: 'Welcome to SupplyHub! Your account has been approved. Please complete your company profile and upload your certifications at your earliest convenience.', timestamp: '2024-01-10T09:30:00', read: true },
    { id: '2', sender: 'coordinator', senderName: 'Sarah Mitchell', content: 'We noticed your ISO 14001 certificate is about to expire. Please upload the renewed certificate before the expiry date to maintain your verified status.', timestamp: '2024-03-01T14:15:00', read: true },
    { id: '3', sender: 'coordinator', senderName: 'David Chen', content: 'Your new product listing "Custom Rubber Seals & Gaskets" is currently under review. We\'ll notify you once the review is complete.', timestamp: '2024-03-12T11:00:00', read: false },
  ]);

  // CMS state
  const [pages, setPages] = useState<CMSPage[]>([
    { id: '1', title: 'About Us', slug: 'about', content: 'Müller Components GmbH is a family-owned precision manufacturing company with over 25 years of experience serving the European industrial market. Our state-of-the-art facility in Munich combines traditional craftsmanship with cutting-edge CNC technology.\n\nWe are committed to quality, sustainability, and building long-term partnerships with our clients across automotive, aerospace, and general industrial sectors.', status: 'published', updatedAt: '2024-02-15', author: 'Hans Müller' },
    { id: '2', title: 'Quality Assurance', slug: 'quality', content: 'Quality is at the core of everything we do. Our facility is ISO 9001:2015 and ISO 14001:2015 certified, and we maintain rigorous quality control processes at every stage of production.\n\nAll products undergo comprehensive inspection including dimensional verification, material testing, and surface finish analysis before shipment.', status: 'published', updatedAt: '2024-03-01', author: 'Hans Müller' },
    { id: '3', title: 'Sustainability', slug: 'sustainability', content: 'We are committed to sustainable manufacturing practices. Our facility uses 100% renewable energy, and we have reduced our carbon footprint by 40% over the last five years.', status: 'draft', updatedAt: '2024-03-10', author: 'Hans Müller' },
  ]);
  const [banners, setBanners] = useState<CMSBanner[]>([
    { id: '1', title: 'New CNC Capabilities', subtitle: '5-axis machining now available for complex geometries', ctaText: 'Learn More', ctaLink: '/services', active: true, position: 'hero' },
    { id: '2', title: 'ISO 14001 Certified', subtitle: 'Committed to environmental excellence', ctaText: 'Read More', ctaLink: '/sustainability', active: true, position: 'sidebar' },
  ]);
  const [menuItems, setMenuItems] = useState<CMSMenuItem[]>([
    { id: '1', label: 'Home', link: '/', type: 'page', order: 1 },
    { id: '2', label: 'Products', link: '/products', type: 'product', order: 2 },
    { id: '3', label: 'Services', link: '/services', type: 'page', order: 3 },
    { id: '4', label: 'About', link: '/about', type: 'page', order: 4 },
    { id: '5', label: 'Quality', link: '/quality', type: 'page', order: 5 },
    { id: '6', label: 'Contact', link: '/contact', type: 'page', order: 6 },
  ]);

  // Email state
  const [emailTemplates, setEmailTemplates] = useState<EmailTemplate[]>([
    { id: '1', name: 'Product Inquiry Response', subject: 'Re: Inquiry about {{product_name}}', body: 'Dear {{customer_name}},\n\nThank you for your interest in {{product_name}}. We would be happy to provide you with a detailed quotation.\n\nPlease find attached our product datasheet. For custom requirements, our technical team is available to discuss your specific needs.\n\nBest regards,\n{{sender_name}}\nMüller Components GmbH', type: 'inquiry', createdAt: '2024-01-20' },
    { id: '2', name: 'Order Confirmation', subject: 'Order Confirmation #{{order_id}}', body: 'Dear {{customer_name}},\n\nWe are pleased to confirm your order #{{order_id}}.\n\nOrder Details:\n- Product: {{product_name}}\n- Quantity: {{quantity}}\n- Estimated Delivery: {{delivery_date}}\n\nYou will receive tracking information once your order ships.\n\nBest regards,\nMüller Components GmbH', type: 'order', createdAt: '2024-02-05' },
    { id: '3', name: 'Monthly Newsletter', subject: 'Müller Components - {{month}} Update', body: 'Dear valued partner,\n\nHere are the latest updates from Müller Components:\n\n• New product launches\n• Industry insights\n• Company news\n\nVisit our website for more information.\n\nBest regards,\nThe Müller Components Team', type: 'newsletter', createdAt: '2024-02-15' },
  ]);
  const [sentEmails, setSentEmails] = useState<SentEmail[]>([
    { id: '1', to: 'procurement@autoworks.de', subject: 'Re: Inquiry about Industrial Grade Steel Bearings', templateId: '1', status: 'read', sentAt: '2024-03-14T10:30:00' },
    { id: '2', to: 'orders@techfab.fr', subject: 'Order Confirmation #ORD-2024-0847', templateId: '2', status: 'delivered', sentAt: '2024-03-13T15:20:00' },
    { id: '3', to: 'newsletter@subscribers.com', subject: 'Müller Components - March Update', templateId: '3', status: 'sent', sentAt: '2024-03-01T09:00:00' },
    { id: '4', to: 'quality@medtech.it', subject: 'Re: Custom Gasket Specifications', status: 'read', sentAt: '2024-03-12T14:45:00' },
  ]);

  // Site config
  const [siteConfig, setSiteConfig] = useState<SiteConfig>({
    headerBg: '#1a1a1a',
    headerText: '#ffffff',
    footerBg: '#2a2420',
    footerText: '#f5e8d0',
    primaryColor: '#c06d23',
    accentColor: '#9f5320',
    showContactForm: true,
    showProductCatalog: true,
    showCertifications: true,
    companyName: 'Müller Components GmbH',
    tagline: 'Precision Industrial Components Since 1998',
    socialLinks: [
      { platform: 'LinkedIn', url: 'https://linkedin.com/company/mueller-components' },
      { platform: 'Twitter', url: 'https://twitter.com/mueller_comp' },
    ],
    contactEmail: 'info@mueller-components.de',
    contactPhone: '+49 89 1234 5678',
  });

  // Portal users
  const [portalUsers, setPortalUsers] = useState<PortalUser[]>([
    { id: '1', name: 'Hans Müller', email: 'hans.mueller@mueller-components.de', role: 'owner', status: 'active', lastActive: '2024-03-15T09:30:00' },
    { id: '2', name: 'Anna Weber', email: 'anna.weber@mueller-components.de', role: 'admin', status: 'active', lastActive: '2024-03-15T08:15:00' },
    { id: '3', name: 'Klaus Fischer', email: 'klaus.fischer@mueller-components.de', role: 'editor', status: 'active', lastActive: '2024-03-14T16:45:00' },
    { id: '4', name: 'Maria Schmidt', email: 'maria.s@mueller-components.de', role: 'viewer', status: 'invited', lastActive: '—' },
  ]);

  const setSupplier = (s: Supplier) => setSupplierState(s);
  const addProduct = (p: Product) => setProducts(prev => [p, ...prev]);
  const updateProduct = (id: string, updates: Partial<Product>) => setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  const deleteProduct = (id: string) => setProducts(prev => prev.filter(p => p.id !== id));
  const addCertification = (c: Certification) => setCertifications(prev => [c, ...prev]);
  const deleteCertification = (id: string) => setCertifications(prev => prev.filter(c => c.id !== id));
  const addMessage = (m: Message) => setMessages(prev => [m, ...prev]);
  const markMessageRead = (id: string) => setMessages(prev => prev.map(m => m.id === id ? { ...m, read: true } : m));
  const completeRegistration = () => setIsRegistered(true);

  const addPage = (p: CMSPage) => setPages(prev => [p, ...prev]);
  const updatePage = (id: string, updates: Partial<CMSPage>) => setPages(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  const deletePage = (id: string) => setPages(prev => prev.filter(p => p.id !== id));
  const addBanner = (b: CMSBanner) => setBanners(prev => [b, ...prev]);
  const updateBanner = (id: string, updates: Partial<CMSBanner>) => setBanners(prev => prev.map(b => b.id === id ? { ...b, ...updates } : b));
  const deleteBanner = (id: string) => setBanners(prev => prev.filter(b => b.id !== id));

  const addEmailTemplate = (t: EmailTemplate) => setEmailTemplates(prev => [t, ...prev]);
  const deleteEmailTemplate = (id: string) => setEmailTemplates(prev => prev.filter(t => t.id !== id));
  const sendEmail = (e: SentEmail) => setSentEmails(prev => [e, ...prev]);

  const updateSiteConfig = (c: Partial<SiteConfig>) => setSiteConfig(prev => ({ ...prev, ...c }));

  const addPortalUser = (u: PortalUser) => setPortalUsers(prev => [u, ...prev]);
  const updatePortalUser = (id: string, updates: Partial<PortalUser>) => setPortalUsers(prev => prev.map(u => u.id === id ? { ...u, ...updates } : u));
  const deletePortalUser = (id: string) => setPortalUsers(prev => prev.filter(u => u.id !== id));

  return (
    <AppContext.Provider value={{
      supplier, products, certifications, messages, isRegistered,
      pages, banners, menuItems, emailTemplates, sentEmails, siteConfig, portalUsers,
      setSupplier, addProduct, updateProduct, deleteProduct,
      addCertification, deleteCertification, addMessage, markMessageRead, completeRegistration,
      addPage, updatePage, deletePage, addBanner, updateBanner, deleteBanner, setMenuItems,
      addEmailTemplate, deleteEmailTemplate, sendEmail,
      updateSiteConfig, addPortalUser, updatePortalUser, deletePortalUser,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
