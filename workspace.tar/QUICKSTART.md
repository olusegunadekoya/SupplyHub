# Quick Start Guide - SupplyHub Demo

## 🚀 Get Started in 3 Steps

### Step 1: Install Node.js (if not already installed)

Download and install Node.js from: https://nodejs.org/

Choose the **LTS version** (18.x or higher)

Verify installation:
```bash
node --version
npm --version
```

### Step 2: Install Dependencies

Open a terminal in the project folder and run:
```bash
npm install
```

Wait for installation to complete (1-2 minutes).

### Step 3: Start the App

```bash
npm run dev
```

The app will open automatically at: **http://localhost:5173**

If it doesn't open, copy the URL from your terminal and paste it in your browser.

---

## ✅ That's It!

You're now running SupplyHub in demo mode.

### What to Try First:

1. **Dashboard** - See the overview with KPIs
2. **Products** - Browse the product catalog
3. **Quality Assurance** - Explore quality metrics and inspections
4. **Manpower Sourcing** - Browse technical experts
5. **Development Manual** - Read the complete documentation

---

## 🛑 Common Issues

### "npm: command not found"
**Solution:** Node.js is not installed. Download from https://nodejs.org/

### Port 5173 already in use
**Solution:** Close other terminals or use a different port:
```bash
npm run dev -- --port 3000
```

### Blank white page
**Solution:** 
1. Open browser DevTools (F12)
2. Check Console tab for errors
3. Clear browser cache and reload
4. Try a different browser

### "Cannot find module" errors
**Solution:** Reinstall dependencies:
```bash
rm -rf node_modules
npm install
```

---

## 📱 Access the App

Once running, access at:
- **Development:** http://localhost:5173
- **Production Build:** 
  ```bash
  npm run build
  npm run preview
  ```
  Then visit: http://localhost:4173

---

## 🎯 Demo Features

### Pre-loaded Data:
- ✅ 1 Supplier (Müller Components GmbH)
- ✅ 4 Users (different roles)
- ✅ 3 Products with specifications
- ✅ 6 Technical Experts (local & international)
- ✅ Quality metrics (12 months)
- ✅ Inspections, NCRs, CAPAs
- ✅ Sourcing requests and contracts

### Try These Actions:
- Browse products and view specifications
- Check quality scorecards and trends
- View expert profiles and skills
- Customize your subdomain site
- Read the Development Manual

---

## 💾 Data Storage

All data is stored in your **browser's IndexedDB**:
- ✅ Persists across page refreshes
- ✅ No server required
- ⚠️ Clearing browser data resets the demo
- ⚠️ Data is local to your browser

---

## 🆘 Need Help?

1. Check the **Development Manual** in the app (`/manual`)
2. Review the full **README.md**
3. Check browser console for errors (F12 → Console)
4. Ensure Node.js version is 18+: `node --version`

---

## 🎉 You're Ready!

Enjoy exploring SupplyHub! The demo showcases:
- Multi-tenant B2B platform
- Quality assurance management
- Technical expert sourcing
- Content management system
- Email services
- And much more...

**Happy exploring!** 🚀
