# SupplyHub - B2B Supplier Relationship Portal

A comprehensive multi-tenant B2B platform for managing supplier relationships, quality assurance, manpower sourcing, and more.

## 🚀 Quick Start (Demo Mode)

The application runs entirely in your browser using IndexedDB for data persistence. No backend server required!

### Prerequisites

- **Node.js** (v18 or higher) - [Download here](https://nodejs.org/)
- **npm** (comes with Node.js)

Verify installation:
```bash
node --version  # Should show v18.x.x or higher
npm --version   # Should show 9.x.x or higher
```

### Installation

1. **Navigate to the project directory:**
   ```bash
   cd supplyhub
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```
   This will install all required packages (React, Vite, Dexie, etc.)

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open your browser:**
   - The app will automatically open at: `http://localhost:5173`
   - If it doesn't open automatically, manually navigate to the URL shown in your terminal

### First Launch

On first launch, the application will:
- Initialize the IndexedDB database
- Seed demo data (suppliers, products, experts, etc.)
- Set up the default tenant (Müller Components GmbH)

You'll see a loading screen briefly, then be redirected to the Dashboard.

## 📖 What You Can Do in Demo Mode

### 1. **Dashboard** (`/`)
- View KPIs and recent activity
- Quick access to all modules
- System status overview

### 2. **Products & Services** (`/products`)
- Browse product catalog (3 sample products)
- View detailed specifications
- Add/edit/delete products
- Filter by status and category

### 3. **Quality Assurance** (`/quality`)
- **Overview**: Quality metrics, trends, scorecards
- **Inspections**: View scheduled and completed inspections
- **NCR Reports**: Non-conformance reports with severity tracking
- **CAPA**: Corrective and preventive actions
- **Scorecards**: Performance evaluations (Grade A-F)
- **Documents**: Quality document control

### 4. **Manpower Sourcing** (`/manpower`)
- **Expert Directory**: Browse 6 technical experts (local & international)
- Filter by region (local/regional/international) and availability
- View expert profiles with skills, certifications, ratings
- **Sourcing Requests**: Create and manage expert requests
- **Contracts**: Track active contracts
- **Assignments**: Monitor expert assignments

### 5. **Certifications** (`/certifications`)
- Upload and manage compliance certifications
- Track verification status
- View expiry dates

### 6. **Messages** (`/messages`)
- Real-time messaging with platform coordinator
- Threaded conversations
- Message history

### 7. **Company Profile** (`/profile`)
- Edit company information
- Update contact details
- Manage business details

### 8. **Subdomain Site Builder** (`/site-builder`)
- Customize your subdomain site (mueller-components.supplyhub.io)
- Edit header and footer
- Change branding colors
- Live preview (desktop/mobile)

### 9. **Content Manager** (`/content`)
- Create and edit CMS pages
- Manage promotional banners
- Configure navigation menu

### 10. **Email Services** (`/email`)
- Compose emails with templates
- Track delivery status
- View analytics

### 11. **Control Panel** (`/control-panel`)
- Manage portal users (4 sample users)
- View activity logs
- Configure security settings
- Manage API keys

### 12. **Database & Server** (`/database`)
- Live database statistics (26 tables)
- Interactive query console
- API endpoint documentation
- Server status monitoring

### 13. **Development Manual** (`/manual`)
- Comprehensive 8-chapter guide
- Architecture documentation
- Deployment instructions
- Extension guide with examples
- Print/export to PDF

## 🏗️ Production Build

To create an optimized production build:

```bash
npm run build
```

This creates a `dist/` folder with optimized assets.

### Serve Production Build

**Option 1: Using Vite preview**
```bash
npm run preview
```
Opens at `http://localhost:4173`

**Option 2: Using any static server**
```bash
# Install serve globally (one-time)
npm install -g serve

# Serve the dist folder
serve dist
```

## 🐳 Docker Deployment

Build and run with Docker:

```bash
# Build the image
docker build -t supplyhub .

# Run the container
docker run -p 8080:80 supplyhub
```

Access at `http://localhost:8080`

## 📊 Demo Data

The application comes pre-seeded with realistic demo data:

### Supplier
- **Müller Components GmbH** (Munich, Germany)
- Subdomain: `mueller-components.supplyhub.io`
- Status: Approved, Verified

### Users (4)
- Hans Müller (Owner)
- Anna Weber (Admin)
- Klaus Fischer (Editor)
- Maria Schmidt (Viewer - invited)

### Products (3)
- Industrial Grade Steel Bearings
- Precision CNC Machining Service
- Custom Rubber Seals & Gaskets

### Quality Data
- 12 months of quality metrics
- 4 inspections (various stages)
- 3 NCR reports
- 4 CAPA actions
- 3 scorecards (Grades A, A, B)
- 5 quality documents

### Technical Experts (6)
- Thomas Weber (CNC Specialist - Local, Germany)
- Maria Rossi (Quality Consultant - Regional, Italy)
- James Mitchell (Materials Engineer - International, USA)
- Hiroshi Tanaka (Lean Expert - International, Japan)
- Sophie Laurent (Automation Engineer - Regional, France)
- Klaus Bauer (Supply Chain - Local, Germany)

### Sourcing Requests (4)
- Various stages from draft to interview

### Contracts & Assignments
- 2 active contracts
- 2 assignments (1 active, 1 completed)

## 🔧 Troubleshooting

### Issue: "Cannot find module" errors
**Solution:** Delete `node_modules` and reinstall
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue: Port 5173 already in use
**Solution:** Vite will automatically try the next available port, or specify a port:
```bash
npm run dev -- --port 3000
```

### Issue: Database not initializing
**Solution:** Clear browser storage
1. Open DevTools (F12)
2. Go to Application tab
3. Clear IndexedDB, Local Storage, Session Storage
4. Refresh the page

### Issue: Build fails
**Solution:** Ensure Node.js version is 18+
```bash
node --version
# If < 18, update Node.js from https://nodejs.org/
```

### Issue: Blank page after build
**Solution:** Check browser console for errors. Ensure you're serving from the `dist/` folder, not the project root.

## 🌐 Browser Compatibility

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

**Note:** Requires IndexedDB support (all modern browsers)

## 📱 Responsive Design

The application is fully responsive and works on:
- Desktop (1920px+)
- Laptop (1366px - 1920px)
- Tablet (768px - 1366px)
- Mobile (320px - 768px)

## 🔐 Demo Credentials

No login required! The app automatically sets up a demo session for Müller Components GmbH.

In a production environment, you would implement:
- JWT authentication
- Role-based access control
- Multi-factor authentication

## 📚 Documentation

- **Development Manual**: Accessible at `/manual` in the app
- **API Documentation**: Available at `/database` in the app
- **Architecture Guide**: See Chapter 2 of the Development Manual

## 🛠️ Development

### Project Structure
```
supplyhub/
├── src/
│   ├── components/      # Reusable UI components
│   ├── context/         # React Context (global state)
│   ├── db/              # Database schema and seed data
│   ├── pages/           # Page components (routes)
│   ├── services/        # API services and event bus
│   ├── App.tsx          # Main app component
│   └── main.tsx         # Entry point
├── public/              # Static assets
├── index.html           # HTML template
├── package.json         # Dependencies
└── vite.config.ts       # Vite configuration
```

### Available Scripts

```bash
npm run dev       # Start development server
npm run build     # Build for production
npm run preview   # Preview production build
npm run typecheck # Run TypeScript type checking
```

### Adding New Features

See the **Extension Guide** (Chapter 6) in the Development Manual for step-by-step instructions on adding new modules.

## 📝 Notes

- **Data Persistence**: All data is stored in your browser's IndexedDB. Clearing browser data will reset the demo.
- **Multi-Tenancy**: The demo runs as a single tenant (Müller Components). Production would support multiple tenants.
- **Backend**: This is a frontend-only demo. Production requires a backend server (Node.js/Express recommended).
- **Email**: Email sending is simulated. Production requires integration with an email service (SendGrid, AWS SES, etc.).

## 🤝 Support

For issues or questions:
1. Check the Development Manual (`/manual`)
2. Review the troubleshooting section above
3. Check browser console for errors
4. Verify Node.js version (18+)

## 📄 License

This is a demonstration project. Contact the development team for licensing information.

---

**Ready to explore?** Run `npm run dev` and start discovering the platform! 🚀
