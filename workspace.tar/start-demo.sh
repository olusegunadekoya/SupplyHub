#!/bin/bash

echo "========================================"
echo "  SupplyHub - B2B Supplier Portal"
echo "  Starting Demo Mode..."
echo "========================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js is not installed!"
    echo ""
    echo "Please install Node.js from: https://nodejs.org/"
    echo "Choose the LTS version (18.x or higher)"
    echo ""
    echo "On macOS: brew install node"
    echo "On Ubuntu: sudo apt install nodejs npm"
    echo ""
    exit 1
fi

# Display Node.js version
echo "Node.js version: $(node --version)"
echo ""

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    echo "This may take 1-2 minutes..."
    echo ""
    npm install
    if [ $? -ne 0 ]; then
        echo ""
        echo "ERROR: Failed to install dependencies!"
        echo "Please check your internet connection and try again."
        exit 1
    fi
    echo ""
    echo "Dependencies installed successfully!"
    echo ""
fi

echo "Starting development server..."
echo ""
echo "The app will open at: http://localhost:5173"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
echo "========================================"
echo ""

# Start the dev server
npm run dev
